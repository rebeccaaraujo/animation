(function (cjs, an) {

var p; // shortcut to reference prototypes
var lib={};var ss={};var img={};
lib.ssMetadata = [];


// symbols:
// helper functions:

function mc_symbol_clone() {
	var clone = this._cloneProps(new this.constructor(this.mode, this.startPosition, this.loop));
	clone.gotoAndStop(this.currentFrame);
	clone.paused = this.paused;
	clone.framerate = this.framerate;
	return clone;
}

function getMCSymbolPrototype(symbol, nominalBounds, frameBounds) {
	var prototype = cjs.extend(symbol, cjs.MovieClip);
	prototype.clone = mc_symbol_clone;
	prototype.nominalBounds = nominalBounds;
	prototype.frameBounds = frameBounds;
	return prototype;
	}


(lib.youcanttakeitwithyou = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgYAYQgKgKAAgOQAAgNAKgLQALgKANAAQAOAAAKAKQALALAAANQAAAOgLAKQgKALgOAAQgNAAgLgLg");
	this.shape.setTransform(236.125,6.375);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AAVBSQgZAWgdAAQghAAgOgRQgMgRAAgmIAAhkIgWgNIAAgFIBcgRIAACPQAAAVADAIQAEAJAKAAQALAAAOgKIAAiIIgUgNIAAgFIBbgRIAACyIAYAMIAAAEIheANg");
	this.shape_1.setTransform(218.575,-0.575);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AhIBNQgcgcAAgxQAAgxAcgbQAbgbAtAAQAuAAAaAbQAcAbAAAxQAAAxgcAcQgaAbguAAQgtAAgbgbgAgThCQgFAVAAAtQAAAuAFAUQAFAZAOAAQAPAAAFgZQAFgUAAguQAAgtgFgVQgFgZgPAAQgOAAgFAZg");
	this.shape_2.setTransform(195.9,-0.525);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AhNB/QgKgKAAgOQAAgOAKgJQAJgKAOAAQAXAAAHAZQAMgQAIgPIhUi3IgXgMIAAgFIB5AAIAAAFIgXALIAmBtIAjhsIgYgMIAAgFIBMAAIAAAFIgXAMIhRDDQgXA8gkABQgQgBgKgJg");
	this.shape_3.setTransform(173.575,3.25);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AAFCOIAAgEIARgMIAAh7QAAgTgCgHQgEgKgLAAQgMAAgOAKIAACVIARAMIAAAEIhuAAIAAgEIAWgNIAAjnIgVgOIAAgEIBcgRIAABoQAagWAhAAQA2AAABBEIAAB0IAWANIAAAEg");
	this.shape_4.setTransform(141.75,-4.925);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgwA+IAAhxIgXAAIAAgHQBBgwAVgUIAGAAIAAA2IAtAAIAAAVIgtAAIAAB5QABAfARAAQAMAAASgFIADAJQgfAWgmAAQgzAAAAhBg");
	this.shape_5.setTransform(121.55,-2.875);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("Ag5CRIAAgFIAWgMIAAiWIgVgNIAAgFIBbgRIAAC5IAXAMIAAAFgAgehSQgMgKAAgQQAAgPAMgLQALgKARAAQAQAAAMAKQAMAKAAAQQAAAQgMAKQgMAKgQAAQgRAAgLgKg");
	this.shape_6.setTransform(107.25,-5.2);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AA0BlIgthrIguBrIgOAAIhJi4IgYgMIAAgFIB6AAIAAAFIgYALIAeBeIAlhoIARAAIAtBnIAYhcIgYgMIAAgFIBKAAIAAAFIgXAMIg+C4g");
	this.shape_7.setTransform(85.1,-0.35);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AgxA+IAAhxIgWAAIAAgHQBBgwAVgUIAGAAIAAA2IAtAAIAAAVIgtAAIAAB5QAAAfASAAQAMAAARgFIAEAJQgeAWgnAAQg0AAAAhBg");
	this.shape_8.setTransform(53.65,-2.875);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("Ag5CRIAAgFIAXgMIAAiWIgWgNIAAgFIBcgRIAAC5IAWAMIAAAFgAgehSQgMgKAAgQQAAgPAMgLQALgKAQAAQASAAALAKQAMAKAAAQQAAAQgMAKQgLAKgSAAQgQAAgLgKg");
	this.shape_9.setTransform(39.35,-5.2);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ag/BMQgbgbgBguQAAgwAagdQAbgdAsAAQBWAAAABpIhsAAQAAAhAIARQALAYAfAAQAZAAAbgJIABAHQgkAegtAAQgqAAgbgcgAgNhEQgDARAAAoIAhgEQAAgogDgQQgDgTgKAAQgKAAgEAWg");
	this.shape_10.setTransform(14.75,-0.525);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AAECOIAAgEIAUgMIgqhNIgIAAIAABNIAQAMIAAAEIhuAAIAAgEIAXgNIAAjnIgWgOIAAgEIBdgRIAACyIBGhKIgWgMIAAgFIBRAAIAAAFIgaAMIgyAsIBHB3IAXAMIAAAEg");
	this.shape_11.setTransform(-7.575,-4.95);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAGBSQgQAWggAAQgYAAgPgLQgRgNAAgZQAAgiAlgRQAUgIAsgIIAAgYQAAgYgEgLQgGgRgTAAQgPAAgLAIQAZAHAAAaQAAAOgJAIQgJAIgOAAQgOAAgJgJQgJgJAAgOQAAgbAcgPQAYgMAfAAQAoAAATAPQAXASAAAsIAABbQAAAQAPAAIAIAAIACAHQgaAQgeAAQgeAAgHgWgAgdAzQAAAeAQAAQAIAAAIgJIAAhJQggAMAAAog");
	this.shape_12.setTransform(-30.625,-0.525);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgwA+IAAhxIgXAAIAAgHQBCgwAUgUIAHAAIAAA2IAtAAIAAAVIgtAAIAAB5QAAAfARAAQANAAARgFIADAJQgfAWglAAQg0AAAAhBg");
	this.shape_13.setTransform(-49.35,-2.875);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgwA+IAAhxIgXAAIAAgHQBCgwAUgUIAHAAIAAA2IAtAAIAAAVIgtAAIAAB5QAAAfARAAQANAAARgFIADAJQgfAWglAAQg0AAAAhBg");
	this.shape_14.setTransform(-73.1,-2.875);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgdA4QAWgVAHgfQgOAAgKgJQgKgJAAgQQAAgNAKgKQALgKANAAQAPAAAKALQAKAMAAAQQAAAYgTAbQgQAXgXAOg");
	this.shape_15.setTransform(-85.7,-12.75);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AAFBlIAAgEIAQgMIAAh6QAAgUgCgGQgDgLgLAAQgMAAgOAKIAACVIAQAMIAAAEIhtAAIAAgEIAXgNIAAiVIgWgOIAAgEIBcgRIAAAWQAagVAhAAQA3AAgBBEIAABzIAXANIAAAEg");
	this.shape_16.setTransform(-103.2,-0.85);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAGBSQgQAWggAAQgYAAgPgLQgRgNAAgZQAAgiAlgRQAUgIAsgIIAAgYQAAgYgEgLQgGgRgTAAQgPAAgLAIQAZAHAAAaQAAAOgJAIQgJAIgOAAQgOAAgJgJQgJgJAAgOQAAgbAcgPQAYgMAfAAQAoAAATAPQAXASAAAsIAABbQAAAQAPAAIAIAAIACAHQgaAQgeAAQgeAAgHgWgAgdAzQAAAeAQAAQAIAAAIgJIAAhJQggAMAAAog");
	this.shape_17.setTransform(-125.675,-0.525);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ag7BNQgagaAAgtQAAg2AfgdQAdgaAvAAQAbAAARALQAUAMAAAWQAAAOgJAJQgKAKgPAAQgOAAgIgIQgJgJAAgOQgBgVATgHQgGgGgKAAQgTAAgIAfQgGAXgBAhQABAlAIASQALAYAdAAQARAAAdgJIACAHQgjAegtAAQgoAAgZgbg");
	this.shape_18.setTransform(-146,-0.525);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAVBSQgZAWgdAAQghAAgOgRQgMgRAAgmIAAhkIgWgNIAAgFIBcgRIAACPQAAAVADAIQAEAJAKAAQALAAAOgKIAAiIIgUgNIAAgFIBbgRIAACyIAYAMIAAAEIheANg");
	this.shape_19.setTransform(-175.475,-0.575);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AhHBNQgcgcAAgxQAAgxAcgbQAagbAtAAQAuAAAbAbQAbAbAAAxQAAAxgbAcQgbAbguAAQgtAAgagbgAgThCQgFAVAAAtQAAAuAFAUQAFAZAOAAQAPAAAFgZQAFgUAAguQAAgtgFgVQgFgZgPAAQgOAAgFAZg");
	this.shape_20.setTransform(-198.15,-0.525);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("Ag8CJIAAgEIAdgNIAAhlIhIiJIgbgOIAAgEICBAAIAAAEIgbAOIA4B2IAwh2IgbgOIAAgEIBRAAIAAAEIgcAPIg8CBIAABsIAeANIAAAEg");
	this.shape_21.setTransform(-222.3,-4.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.youcanttakeitwithyou, new cjs.Rectangle(-276.4,-29.1,558.4,49.400000000000006), null);


(lib.text3 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgKALQgEgFAAgGQAAgGAEgFQAFgEAFAAQAHAAAEAEQAEAFAAAGQAAAHgEAEQgEAFgHAAQgFAAgFgFg");
	this.shape.setTransform(192.075,20.325);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgcA0QgOgHgIgOQgHgNAAgSQAAgQAHgOQAIgOAOgHQANgIARAAQAcAAAOAQQAOAQAAAcIAAAJIhWAAQADAMAJAIQAJAHAMAAQAJAAAIgEQAIgDAGgGIAQAQQgJAJgNAGQgMAFgQAAQgRAAgNgIgAAggIQAAgNgJgIQgIgIgNAAQgMAAgIAIQgJAIgCANIA9AAIAAAAg");
	this.shape_1.setTransform(182.625,15.825);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AgjBLQgMgIgHgNQgHgOAAgSQAAgSAHgMQAHgOAMgIQANgHAQAAQANAAAKAFQAKAFAGALIAAhCIAdAAIAACjIgdAAIAAgTQgGAKgKAFQgKAFgMABQgRAAgNgIgAgXgDQgJAKAAAPQAAAQAJAKQAJALAOgBQAPABAJgLQAJgKAAgQQAAgPgJgKQgJgKgPAAQgOAAgJAKg");
	this.shape_2.setTransform(167.525,13.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgNBUIAAh0IAcAAIAAB0gAgLg2QgEgFAAgHQAAgHAEgFQAFgFAGAAQAHAAAFAFQAEAFAAAHQAAAHgEAFQgFAFgHAAQgGAAgFgFg");
	this.shape_3.setTransform(156.875,13.275);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgYA4QgNgFgKgHIALgUQAHAHALAEQAMADAIAAQAIAAAFgCQAEgDABgGQgBgGgFgDQgGgEgLgDIgTgHQgHgEgGgFQgFgHgBgMQAAgRANgJQAMgJATAAQALAAAMAEQALACAJAHIgKAUQgJgFgJgDQgJgCgIAAQgGgBgEADQgFADAAAFQAAAFAGADQAFADALAEQAMADAIAEQAIADAFAHQAHAHAAAMQAAARgNAJQgOAJgUAAQgNAAgMgEg");
	this.shape_4.setTransform(147.8,15.8);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AghA7IAAh0IAcAAIAAAXQAFgMAKgGQALgGANAAIAAAbQgSAAgLAJQgKAJAAAQIAAA4g");
	this.shape_5.setTransform(132.625,15.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AgsAvQgLgMAAgVIAAhIIAdAAIAABAQAAAMAGAHQAHAHAMAAQANAAAIgJQAHgKAAgNIAAg6IAdAAIAAB0IgdAAIAAgWQgLAXgdAAQgTAAgMgMg");
	this.shape_6.setTransform(119.525,15.875);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgfA0QgPgHgHgOQgIgNAAgSQAAgRAIgNQAHgOAPgHQAOgIARAAQATAAAOAIQAOAHAHAOQAIANAAARQAAASgIANQgHAOgOAHQgOAIgTAAQgRAAgOgIgAgXgYQgJAJAAAPQAAAQAJAKQAKAKANAAQAPAAAJgKQAKgKgBgQQABgPgKgJQgJgKgPAAQgNAAgKAKg");
	this.shape_7.setTransform(105.1,15.825);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AguBOQgHgCgHgGIAMgWIAIAFQAEABAEAAQALAAAGgMIADgHIgwhzIAdAAIAhBVIAehVIAdAAIg1CDQgFAPgJAHQgLAIgOAAQgIAAgHgDg");
	this.shape_8.setTransform(91.725,18.025);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AAcA7IAAg/QAAgNgGgHQgIgHgMAAQgNAAgJAJQgIAKAAAOIAAA5IgcAAIAAh0IAcAAIAAAWQANgXAdAAQAUAAALAMQAMAMAAAVIAABIg");
	this.shape_9.setTransform(72.25,15.75);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AggA0QgNgHgIgOQgIgNAAgSQAAgRAIgNQAIgOANgHQAPgIASAAQARAAAOAIQAOAHAJAOQAHANAAARQAAASgHANQgJAOgOAHQgOAIgRAAQgSAAgPgIgAgXgYQgJAJAAAPQAAAQAJAKQAJAKAPAAQAOAAAJgKQAKgKgBgQQABgPgKgJQgJgKgOAAQgPAAgJAKg");
	this.shape_10.setTransform(57.35,15.825);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AghA7IAAh0IAcAAIAAAXQAFgMAKgGQALgGANAAIAAAbQgSAAgLAJQgKAJAAAQIAAA4g");
	this.shape_11.setTransform(40.475,15.75);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AggA0QgOgHgHgOQgIgNAAgSQAAgRAIgNQAHgOAOgHQAPgIARAAQASAAAPAIQANAHAIAOQAIANAAARQAAASgIANQgIAOgNAHQgPAIgSAAQgRAAgPgIgAgXgYQgJAJAAAPQAAAQAJAKQAJAKAOAAQAPAAAJgKQAKgKAAgQQAAgPgKgJQgJgKgPAAQgOAAgJAKg");
	this.shape_12.setTransform(27.85,15.825);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgNBAQgKgJAAgRIAAg5IgQAAIAAgVIAQAAIAAggIAcAAIAAAgIAhAAIAAAVIghAAIAAA0QAAAIADADQADAEAGAAQAHAAAKgFIAGAVQgOAJgPAAQgOAAgKgJg");
	this.shape_13.setTransform(15.975,14.525);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AAdA7IAAg/QAAgNgIgHQgHgHgMAAQgNAAgJAJQgHAKgBAOIAAA5IgcAAIAAh0IAcAAIAAAWQAMgXAdAAQAVAAAMAMQALAMAAAVIAABIg");
	this.shape_14.setTransform(3.7,15.75);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AgcA0QgOgHgIgOQgHgNAAgSQAAgQAHgOQAIgOAOgHQANgIARAAQAcAAAOAQQAOAQAAAcIAAAJIhWAAQADAMAJAIQAJAHAMAAQAJAAAIgEQAIgDAGgGIAQAQQgJAJgNAGQgMAFgQAAQgRAAgNgIgAAggIQAAgNgJgIQgIgIgNAAQgMAAgIAIQgJAIgCANIA9AAIAAAAg");
	this.shape_15.setTransform(-10.775,15.825);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("ABFA7IAAg/QAAgNgGgHQgHgIgMABQgOAAgIAJQgIAKAAAOIAAA5IgcAAIAAg/QABgNgIgHQgGgIgMABQgOAAgIAJQgIAKAAAOIAAA5IgcAAIAAh0IAcAAIAAAVQALgWAfAAQAPAAAKAHQAJAIAFANQALgcAhAAQATAAAMAMQAMAMAAAVIAABIg");
	this.shape_16.setTransform(-29.05,15.75);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AghA3QgJgEgGgJQgFgIAAgKQAAgRAMgIQAMgKAVAAIAhAAIAAgDQAAgKgGgGQgHgGgMAAQgRAAgSALIgLgUQAOgHAMgEQALgDAOAAQAXAAANALQAMALABAUIAABMIgcAAIAAgPQgHAIgJAEQgKAEgLAAQgNAAgJgFgAgUALQgGADAAAIQAAAHAGAFQAGAEAJAAQAMAAAIgGQAJgGABgIIAAgLIgcAAQgMAAgFAEg");
	this.shape_17.setTransform(-53.825,15.825);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgjBLQgMgIgHgNQgHgOAAgSQAAgSAHgMQAHgOAMgIQANgHAQAAQANAAAKAFQAKAFAGALIAAhCIAdAAIAACjIgdAAIAAgTQgGAKgKAFQgKAFgMABQgRAAgNgIgAgXgDQgJAKAAAPQAAAQAJAKQAJALAOgBQAPABAJgLQAJgKAAgQQAAgPgJgKQgJgKgPAAQgOAAgJAKg");
	this.shape_18.setTransform(-74.425,13.6);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AgcA0QgOgHgIgOQgHgNAAgSQAAgQAHgOQAIgOAOgHQANgIARAAQAcAAAOAQQAOAQAAAcIAAAJIhWAAQADAMAJAIQAJAHAMAAQAJAAAIgEQAIgDAGgGIAQAQQgJAJgNAGQgMAFgQAAQgRAAgNgIgAAggIQAAgNgJgIQgIgIgNAAQgMAAgIAIQgJAIgCANIA9AAIAAAAg");
	this.shape_19.setTransform(-88.325,15.825);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgcA0QgOgHgIgOQgHgNAAgSQAAgQAHgOQAIgOAOgHQANgIARAAQAcAAAOAQQAOAQAAAcIAAAJIhWAAQADAMAJAIQAJAHAMAAQAJAAAIgEQAIgDAGgGIAQAQQgJAJgNAGQgMAFgQAAQgRAAgNgIgAAggIQAAgNgJgIQgIgIgNAAQgMAAgIAIQgJAIgCANIA9AAIAAAAg");
	this.shape_20.setTransform(-101.825,15.825);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAdA7IAAg/QAAgNgIgHQgHgHgMAAQgNAAgJAJQgHAKgBAOIAAA5IgcAAIAAh0IAcAAIAAAWQAMgXAdAAQAVAAAMAMQALAMAAAVIAABIg");
	this.shape_21.setTransform(-116,15.75);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgsAvQgLgMAAgVIAAhIIAdAAIAABAQAAAMAGAHQAHAHAMAAQANAAAIgJQAHgKAAgNIAAg6IAdAAIAAB0IgdAAIAAgWQgLAXgdAAQgTAAgMgMg");
	this.shape_22.setTransform(-137.225,15.875);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AgfA0QgOgHgIgOQgIgNAAgSQAAgRAIgNQAIgOAOgHQAOgIASAAQARAAAOAIQAOAHAJAOQAHANAAARQAAASgHANQgJAOgOAHQgOAIgRAAQgSAAgOgIgAgXgYQgJAJAAAPQAAAQAJAKQAJAKAPAAQAOAAAJgKQAJgKAAgQQAAgPgJgJQgJgKgOAAQgPAAgJAKg");
	this.shape_23.setTransform(-151.65,15.825);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AguBOQgHgCgHgGIAMgWIAIAFQAEABAEAAQALAAAGgMIADgHIgwhzIAdAAIAhBVIAehVIAdAAIg1CDQgFAPgJAHQgLAIgOAAQgIAAgHgDg");
	this.shape_24.setTransform(-165.025,18.025);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgPAbIAJgaQgHgDAAgJQAAgGAFgFQAEgEAFAAQAHAAADAEQAFAEAAAHIgBAGIgDAGIgNAag");
	this.shape_25.setTransform(212.7,-3.3);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgZA4QgMgEgJgJIAJgUQAIAIALADQALAEAJAAQAIAAAFgDQAFgDgBgFQABgGgGgDQgFgEgMgDIgTgHQgHgDgGgGQgGgHABgLQAAgSAMgJQANgJASAAQAMAAALADQALADAJAGIgLAVQgIgFgJgCQgKgEgHAAQgGAAgFADQgEACAAAFQAAAGAFADQAGADAKADQANAEAIAEQAIAEAGAFQAFAIAAALQAAARgNAKQgNAJgUAAQgNAAgNgEg");
	this.shape_26.setTransform(204.45,-9);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AAdA8IAAhBQgBgMgGgHQgIgHgMAAQgNAAgJAJQgHAKgBANIAAA7IgcAAIAAh1IAcAAIAAAWQANgXAdgBQAUAAALANQAMAMAAAVIAABJg");
	this.shape_27.setTransform(191.6,-9.05);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AggA0QgNgHgIgOQgIgNAAgSQAAgRAIgNQAIgOANgHQAPgIASAAQARAAAOAIQAOAHAJAOQAHANAAARQAAASgHANQgJAOgOAHQgOAIgRAAQgSAAgPgIgAgXgYQgJAJAAAPQAAAQAJAKQAJAKAPAAQAOAAAJgKQAKgKAAgQQAAgPgKgJQgJgKgOAAQgPAAgJAKg");
	this.shape_28.setTransform(176.7,-8.975);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgNBUIAAh0IAcAAIAAB0gAgLg2QgEgFAAgHQAAgHAEgFQAFgFAGAAQAHAAAFAFQAEAFAAAHQAAAHgEAFQgFAFgHAAQgGAAgFgFg");
	this.shape_29.setTransform(166.075,-11.525);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AgZA4QgNgEgIgJIAKgUQAHAIALADQALAEAJAAQAIAAAFgDQAEgDAAgFQAAgGgFgDQgFgEgMgDIgTgHQgIgDgFgGQgGgHAAgLQAAgSANgJQAMgJATAAQALAAAMADQALADAJAGIgKAVQgJgFgJgCQgJgEgIAAQgGAAgEADQgFACAAAFQAAAGAGADQAFADALADQAMAEAIAEQAIAEAGAFQAFAIAAALQABARgNAKQgOAJgUAAQgMAAgOgEg");
	this.shape_30.setTransform(157,-9);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgNBUIAAh0IAcAAIAAB0gAgLg2QgEgFAAgHQAAgHAEgFQAFgFAGAAQAHAAAFAFQAEAFAAAHQAAAHgEAFQgFAFgHAAQgGAAgFgFg");
	this.shape_31.setTransform(148.075,-11.525);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AgaA0QgNgHgIgOQgHgNAAgSQAAgRAHgNQAIgOAOgHQANgIARAAQAQAAAMAGQANAFAIALIgRAQQgMgNgTAAQgOAAgIAKQgJAKAAAOQAAAQAJAKQAIAJAOAAQAVAAAKgOIASAPQgIAMgNAGQgNAGgRAAQgQAAgOgIg");
	this.shape_32.setTransform(138.225,-8.975);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgcA0QgOgHgIgOQgHgNAAgSQAAgQAHgOQAIgOAOgHQANgIARAAQAcAAAOAQQAOAQAAAcIAAAJIhWAAQADAMAJAIQAJAHAMAAQAJAAAIgEQAIgDAGgGIAQAQQgJAJgNAGQgMAFgQAAQgRAAgNgIgAAggIQAAgNgJgIQgIgIgNAAQgMAAgIAIQgJAIgCANIA9AAIAAAAg");
	this.shape_33.setTransform(125.025,-8.975);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgjBLQgMgIgHgOQgHgOAAgRQAAgSAHgNQAHgNAMgHQANgIAQAAQANAAAKAFQAKAFAGAKIAAhAIAdAAIAACiIgdAAIAAgTQgGAKgKAFQgKAGgMgBQgRAAgNgHgAgXgCQgJAIAAARQAAAQAJAJQAJALAOAAQAPAAAJgLQAJgJAAgQQAAgRgJgIQgJgKgPAAQgOAAgJAKg");
	this.shape_34.setTransform(109.925,-11.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("AguBOQgHgCgHgGIAMgWIAIAFQAEABAEAAQALAAAGgMIADgHIgwhzIAdAAIAhBVIAehVIAdAAIg1CDQgFAPgJAHQgLAIgOAAQgIAAgHgDg");
	this.shape_35.setTransform(90.675,-6.775);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AgcA0QgOgHgIgOQgHgNAAgSQAAgQAHgOQAIgOAOgHQANgIARAAQAcAAAOAQQAOAQAAAcIAAAJIhWAAQADAMAJAIQAJAHAMAAQAJAAAIgEQAIgDAGgGIAQAQQgJAJgNAGQgMAFgQAAQgRAAgNgIgAAggIQAAgNgJgIQgIgIgNAAQgMAAgIAIQgJAIgCANIA9AAIAAAAg");
	this.shape_36.setTransform(77.725,-8.975);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAdA8IAAhBQAAgMgIgHQgHgHgMAAQgNAAgJAJQgHAKgBANIAAA7IgcAAIAAh1IAcAAIAAAWQAMgXAdgBQAVAAAMANQALAMAAAVIAABJg");
	this.shape_37.setTransform(63.55,-9.05);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AggA0QgOgHgHgOQgIgNAAgSQAAgRAIgNQAHgOAOgHQAPgIARAAQASAAAPAIQAOAHAHAOQAIANAAARQAAASgIANQgHAOgOAHQgPAIgSAAQgRAAgPgIgAgXgYQgJAJAAAPQAAAQAJAKQAKAKANAAQAPAAAJgKQAKgKAAgQQAAgPgKgJQgJgKgPAAQgNAAgKAKg");
	this.shape_38.setTransform(48.65,-8.975);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("ABGA8IAAhBQgBgMgGgIQgHgGgMgBQgOABgIAJQgIAKAAANIAAA7IgcAAIAAhBQABgMgIgIQgGgGgMgBQgOABgIAJQgIAKAAANIAAA7IgcAAIAAh1IAcAAIAAAWQALgXAfgBQAOAAALAIQAJAHAFAOQALgcAggBQAUAAAMANQAMAMAAAVIAABJg");
	this.shape_39.setTransform(30,-9.05);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgNBAQgKgJAAgRIAAg5IgQAAIAAgVIAQAAIAAggIAcAAIAAAgIAhAAIAAAVIghAAIAAA0QAAAIADADQADAEAGAAQAHAAAKgFIAGAVQgOAJgPAAQgOAAgKgJg");
	this.shape_40.setTransform(7.525,-10.275);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAdA8IAAhBQAAgMgIgHQgGgHgNAAQgNAAgJAJQgHAKAAANIAAA7IgdAAIAAh1IAdAAIAAAWQALgXAdgBQAVAAAMANQALAMAAAVIAABJg");
	this.shape_41.setTransform(-4.75,-9.05);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AghA3QgJgEgGgJQgFgIAAgKQAAgRAMgIQAMgKAVAAIAhAAIAAgDQAAgKgGgGQgHgGgMAAQgRAAgSALIgLgUQAOgHAMgEQALgDAOAAQAXAAANALQAMALABAUIAABMIgcAAIAAgPQgHAIgJAEQgKAEgLAAQgNAAgJgFgAgUALQgGADAAAIQAAAHAGAFQAGAEAJAAQAMAAAIgGQAJgGABgIIAAgLIgcAAQgMAAgFAEg");
	this.shape_42.setTransform(-19.525,-8.975);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AgNBAQgKgJAAgRIAAg5IgQAAIAAgVIAQAAIAAggIAcAAIAAAgIAhAAIAAAVIghAAIAAA0QAAAIADADQADAEAGAAQAHAAAKgFIAGAVQgOAJgPAAQgOAAgKgJg");
	this.shape_43.setTransform(-30.675,-10.275);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AghA8IAAh1IAcAAIAAAWQAFgLAKgGQALgGANgBIAAAcQgSgBgLAKQgKAKAAAPIAAA5g");
	this.shape_44.setTransform(-39.425,-9.05);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgfA0QgPgHgHgOQgIgNAAgSQAAgRAIgNQAHgOAPgHQAOgIARAAQATAAAOAIQAOAHAHAOQAIANAAARQAAASgIANQgHAOgOAHQgOAIgTAAQgRAAgOgIgAgXgYQgJAJAAAPQAAAQAJAKQAKAKANAAQAPAAAJgKQAKgKAAgQQAAgPgKgJQgJgKgPAAQgNAAgKAKg");
	this.shape_45.setTransform(-52.05,-8.975);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("Ag9BRIAAigIAcAAIAAATQAHgKAKgFQAKgEAMAAQAQAAANAHQANAIAHANQAHAOAAASQAAARgHAMQgHAOgMAHQgNAIgQAAQgMAAgLgFQgKgFgHgKIAAA+gAgYgtQgJAJAAAQQAAAQAJAIQAKAKAOAAQAPAAAIgKQAKgIAAgQQAAgQgKgJQgIgKgPAAQgOAAgKAKg");
	this.shape_46.setTransform(-66.3,-6.9);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("ABFA8IAAhBQABgMgIgIQgGgGgMgBQgOABgIAJQgIAKAAANIAAA7IgbAAIAAhBQgBgMgGgIQgIgGgLgBQgOABgIAJQgIAKAAANIAAA7IgdAAIAAh1IAdAAIAAAWQAMgXAdgBQAQAAAKAIQAKAHAEAOQALgcAggBQAVAAALANQALAMAAAVIAABJg");
	this.shape_47.setTransform(-86.15,-9.05);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgNBUIAAh0IAcAAIAAB0gAgLg2QgEgFAAgHQAAgHAEgFQAFgFAGAAQAHAAAFAFQAEAFAAAHQAAAHgEAFQgFAFgHAAQgGAAgFgFg");
	this.shape_48.setTransform(-101.525,-11.525);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgcA0QgOgHgIgOQgHgNAAgSQAAgQAHgOQAIgOAOgHQANgIARAAQAcAAAOAQQAOAQAAAcIAAAJIhWAAQADAMAJAIQAJAHAMAAQAJAAAIgEQAIgDAGgGIAQAQQgJAJgNAGQgMAFgQAAQgRAAgNgIgAAggIQAAgNgJgIQgIgIgNAAQgMAAgIAIQgJAIgCANIA9AAIAAAAg");
	this.shape_49.setTransform(-117.525,-8.975);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AAcBSIAAhBQAAgNgHgGQgHgHgMAAQgNAAgIAJQgJAJAAAPIAAA6IgcAAIAAijIAcAAIAABEQAMgXAeAAQAUAAAMAMQALAMAAAUIAABKg");
	this.shape_50.setTransform(-131.675,-11.275);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AgNBAQgKgJAAgRIAAg5IgQAAIAAgVIAQAAIAAggIAcAAIAAAgIAhAAIAAAVIghAAIAAA0QAAAIADADQADAEAGAAQAHAAAKgFIAGAVQgOAJgPAAQgOAAgKgJg");
	this.shape_51.setTransform(-144.275,-10.275);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AghA8IAAh1IAcAAIAAAWQAFgLAKgGQALgGANgBIAAAcQgSgBgLAKQgKAKAAAPIAAA5g");
	this.shape_52.setTransform(-158.875,-9.05);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AggA0QgOgHgHgOQgIgNAAgSQAAgRAIgNQAHgOAOgHQAPgIARAAQASAAAPAIQANAHAIAOQAIANAAARQAAASgIANQgIAOgNAHQgPAIgSAAQgRAAgPgIgAgXgYQgJAJAAAPQAAAQAJAKQAJAKAOAAQAPAAAJgKQAKgKAAgQQAAgPgKgJQgJgKgPAAQgOAAgJAKg");
	this.shape_53.setTransform(-171.5,-8.975);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("Ag0BNIAAiZIBpAAIAAAaIhLAAIAAApIBEAAIAAAZIhEAAIAAA9g");
	this.shape_54.setTransform(-184.5,-10.8);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text3, new cjs.Rectangle(-256.9,-26.4,537.9,55.599999999999994), null);


(lib.text2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// Layer_1
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AgLAMQgFgFAAgHQAAgGAFgFQAFgFAGAAQAHAAAFAFQAFAFAAAGQAAAHgFAFQgFAFgHAAQgGAAgFgFg");
	this.shape.setTransform(193.725,16.15);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AgjArQgOgQAAgZQAAgZANgRQAOgUAYAAQAZAAAMATQAKAPAAAaIhBAAQAAASAJAOQAJAPATAAQAOAAANgEIACADQgWAPgaAAQgWAAgPgSgAgNghQgDAMAAAQIAhgDQAAgsgQAAQgKAAgEATg");
	this.shape_1.setTransform(185.525,11.775);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#FFFFFF").s().p("AAGA7IAAgCIALgHIAAhGQAAgYgOAAQgIAAgKAHIAABXIALAHIAAACIg5AAIAAgCIAOgHIAAhYIgOgJIAAgCIAugJIAAAOQAPgOARAAQASAAAIAMQAFAKAAAUIAABCIAOAHIAAACg");
	this.shape_2.setTransform(173.35,11.6);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AgpArQgPgRAAgaQAAgZAPgRQAQgSAZAAQAaAAAPASQAQARAAAZQAAAagQARQgPASgaAAQgZAAgQgSgAgXAAQAAA2AXAAQAXAAAAg2QAAg0gXAAQgXAAAAA0g");
	this.shape_3.setTransform(160.425,11.775);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#FFFFFF").s().p("AgiBVQgVgGAAgOQAAgNAVgIQgLgGAAgLQAAgOAUgNQgWgJgBgYQAAgTAOgLQAOgLASAAQAMABAKAFIALgMQAIgIAGABQAEAAAEACQADAEAAAEQAAAFgEADQgDADgGgBIgSAAQASAMAAAWQAAASgOAKQgNAKgSgBQgKABgJgDIgFALQgBAJAWAAIARAAQAYAAAJAHQAKAIAAANQgBAUgTALQgQAHgVAAQgSAAgOgDgAghA7QAAALAKAGQAJAFAMAAQAkAAAAgVQgBgMgUAAIgTABQgQgBgIgCQgDAGAAAHgAgRghQAAAfAPAAQAOAAAAgfQAAgigOAAQgPAAAAAig");
	this.shape_4.setTransform(148.35,13.15);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AgjArQgOgQAAgZQAAgZANgRQAOgUAYAAQAZAAAMATQAKAPAAAaIhBAAQAAASAJAOQAJAPATAAQAOAAANgEIACADQgWAPgaAAQgWAAgPgSgAgNghQgDAMAAAQIAhgDQAAgsgQAAQgKAAgEATg");
	this.shape_5.setTransform(131.825,11.775);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#FFFFFF").s().p("AABA6IguhrIgNgGIAAgDIA8AAIAAADIgOAHIAaBBIAShBIgMgHIAAgDIAnAAIAAADIgMAHIgpBqg");
	this.shape_6.setTransform(120,11.9);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#FFFFFF").s().p("AgOAcQALgLADgPQgHgBgFgDQgEgFAAgHQAAgHAFgFQAFgFAGAAQAIAAAEAGQAFAGAAAIQAAAMgJAMQgIAMgMAHg");
	this.shape_7.setTransform(111.425,4.075);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#FFFFFF").s().p("AARAvQgPAOgSAAQgSAAgIgNQgFgIAAgVIAAg7IgOgIIAAgDIAtgJIAABUQAAAXAOAAQAJAAAKgGIAAhRIgOgIIAAgDIAtgJIAABpIAOAHIAAACIgtAHg");
	this.shape_8.setTransform(102.3,11.75);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AgpArQgPgRAAgaQAAgZAPgRQAQgSAZAAQAaAAAPASQAQARAAAZQAAAagQARQgPASgaAAQgZAAgQgSgAgXAAQAAA2AXAAQAXAAAAg2QAAg0gXAAQgXAAAAA0g");
	this.shape_9.setTransform(89.625,11.775);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("AgpBMQgFgFAAgHQAAgGAEgEQAFgFAGAAQALAAADAKIAPgVIgqhsIgMgGIAAgDIA5AAIAAADIgMAGIAXBEIAThDIgNgHIAAgDIAnAAIAAADIgMAHIgkBcIgJAYQgFAPgFAGQgJAMgJAAQgIAAgFgEg");
	this.shape_10.setTransform(77.35,14.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("AgrA7IAAgCIAOgHIAAhYIgOgJIAAgCIAtgJIAAAXQANgXAOAAQAHAAAEAEQAEAFAAAHQAAAGgEAFQgFAEgGAAQgKAAgGgKIgLAIIAABPIAQAHIAAACg");
	this.shape_11.setTransform(61.625,11.6);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AgjArQgOgQAAgZQAAgZANgRQAOgUAYAAQAZAAAMATQAKAPAAAaIhBAAQAAASAJAOQAJAPATAAQAOAAANgEIACADQgWAPgaAAQgWAAgPgSgAgNghQgDAMAAAQIAhgDQAAgsgQAAQgKAAgEATg");
	this.shape_12.setTransform(51.125,11.775);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AgSA/QgEgIAAgTIAAhEIgRAAIAAgCIArgnIAEAAIAAAeIAdAAIAAALIgdAAIAABMQAAAIACAEQACAFAIABQAIAAALgCIABADQgSALgSAAQgQAAgGgLg");
	this.shape_13.setTransform(41.275,10.4);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("AgpBTIAAgCIANgHIAAheIgTAAIAAgEIATgHQAAgXAMgOQAMgPAVAAQAMAAAIAFQALAFAAALQAAAGgFAFQgEADgGAAQgPAAAAgOQAAgIAHgEIgGgBQgQAAAAAaIAAASIAaAAIAAALIgaAAIAABeIAQAHIAAACg");
	this.shape_14.setTransform(33.225,9.2);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("AAHAyQgNALgPAAQgOAAgIgHQgJgHAAgNQAAgfA6gJIAAgOQgBgQgBgFQgDgLgLAAQgKAAgIAFQAMAEAAAMQAAAGgFAEQgEAEgGAAQgIAAgEgFQgFgEABgHQgBgNARgIQANgGAPAAQAUAAAKAKQAKAKAAAYIAAA3QAAAKAHAAIAIgBIABAEQgNAJgOAAQgPAAgEgLgAgVAgQAAARAPAAQAFAAAHgEIAAgtQgbAHAAAZg");
	this.shape_15.setTransform(22.65,11.775);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AgpBMQgFgFAAgHQAAgGAEgEQAFgFAGAAQALAAAEAKIANgVIgphsIgNgGIAAgDIA6AAIAAADIgNAGIAYBEIAThDIgMgHIAAgDIAmAAIAAADIgMAHIgjBcIgKAYQgGAPgEAGQgJAMgJAAQgIAAgFgEg");
	this.shape_16.setTransform(5.7,14.025);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgdBTIAAgCIAOgIIAAiHIgOgJIAAgCIAtgJIAACbIANAIIAAACg");
	this.shape_17.setTransform(-3.85,9.225);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AgcBUIAAgDIANgHIAAhYIgNgIIAAgDIAsgJIAABsIANAHIAAADgAgNgzQgEgGAAgHQAAgIAEgFQAGgGAHAAQAHAAAFAGQAGAFAAAIQAAAHgGAGQgFAFgHAAQgHAAgGgFg");
	this.shape_18.setTransform(-10.85,9.175);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("AAlA7IAAgCIALgHIAAhGQAAgYgOAAQgHABgNAIQABAHAAAMIAABCIAMAHIAAACIg1AAIAAgCIALgHIAAhGQAAgYgOAAQgHAAgLAIIAABWIALAHIAAACIg5AAIAAgCIAPgHIAAhYIgPgJIAAgCIAugJIAAAQQASgQAPAAQAVAAAFASQATgSASAAQARAAAIAMQAGAIgBAWIAABCIAOAHIAAACg");
	this.shape_19.setTransform(-24.2,11.6);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AAHAyQgNALgPAAQgNAAgJgHQgJgHAAgNQAAgfA5gJIAAgOQAAgQgBgFQgDgLgMAAQgJAAgIAFQAMAEAAAMQAAAGgFAEQgFAEgFAAQgIAAgEgFQgEgEgBgHQABgNAQgIQANgGAPAAQAUAAAKAKQAKAKAAAYIAAA3QAAAKAGAAIAJgBIABAEQgOAJgNAAQgPAAgEgLgAgVAgQAAARAPAAQAGAAAFgEIAAgtQgaAHAAAZg");
	this.shape_20.setTransform(-39.7,11.775);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AgpBTIAAgCIANgHIAAheIgTAAIAAgEIATgHQAAgXAMgOQAMgPAVAAQAMAAAIAFQALAFAAALQAAAGgFAFQgEADgGAAQgPAAAAgOQAAgIAHgEIgGgBQgQAAAAAaIAAASIAaAAIAAALIgaAAIAABeIAQAHIAAACg");
	this.shape_21.setTransform(-49.425,9.2);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AgrA7IAAgCIAOgHIAAhYIgOgJIAAgCIAtgJIAAAXQANgXAOAAQAHAAAEAEQAEAFAAAHQAAAGgEAFQgFAEgGAAQgKAAgGgKIgLAIIAABPIAQAHIAAACg");
	this.shape_22.setTransform(-64.075,11.6);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AARAvQgQAOgQAAQgTAAgHgNQgGgIAAgVIAAg7IgOgIIAAgDIAugJIAABUQAAAXANAAQAIAAALgGIAAhRIgOgIIAAgDIAtgJIAABpIAOAHIAAACIgtAHg");
	this.shape_23.setTransform(-75.7,11.75);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgpArQgPgRAAgaQAAgZAPgRQAQgSAZAAQAaAAAPASQAQARAAAZQAAAagQARQgPASgaAAQgZAAgQgSgAgXAAQAAA2AXAAQAXAAAAg2QAAg0gXAAQgXAAAAA0g");
	this.shape_24.setTransform(-88.375,11.775);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgoBMQgGgFAAgHQAAgGAEgEQAFgFAHAAQAJAAAEAKIAPgVIgqhsIgMgGIAAgDIA4AAIAAADIgLAGIAXBEIAThDIgNgHIAAgDIAoAAIAAADIgOAHIgjBcIgJAYQgFAPgFAGQgIAMgKAAQgIAAgEgEg");
	this.shape_25.setTransform(-100.65,14.025);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AgrA8IAAgDIAOgHIAAhYIgOgIIAAgDIAtgKIAAAYQANgXAOAAQAHAAAEAEQAEAFAAAGQAAAHgEAEQgFAFgGAAQgKAAgGgKIgLAIIAABPIAQAHIAAADg");
	this.shape_26.setTransform(223.775,-11.2);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AgpArQgPgRAAgaQAAgZAPgRQAQgSAZAAQAaAAAPASQAQARAAAZQAAAagQARQgPASgaAAQgZAAgQgSgAgXAAQAAA2AXAAQAXAAAAg2QAAg0gXAAQgXAAAAA0g");
	this.shape_27.setTransform(212.675,-11.025);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("AgpBUIAAgDIANgHIAAheIgTAAIAAgEIATgGQAAgYAMgNQAMgPAVgBQAMABAIAEQALAGAAAKQAAAGgFAFQgEADgGAAQgPAAAAgOQAAgJAHgDIgGgBQgQAAAAAbIAAASIAaAAIAAAKIgaAAIAABeIAQAHIAAADg");
	this.shape_28.setTransform(202.725,-13.6);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#FFFFFF").s().p("AgjArQgOgQAAgZQAAgZANgRQAOgUAYAAQAZAAAMATQAKAPAAAaIhBAAQAAASAJAOQAJAPATAAQAOAAANgEIACADQgWAPgaAAQgWAAgPgSgAgNghQgDAMAAAQIAhgDQAAgsgQAAQgKAAgEATg");
	this.shape_29.setTransform(187.275,-11.025);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AANBGQgMAPgRAAQgVAAgLgTQgJgPAAgXQAAgcANgRQAPgTAcAAQAIAAAGACIAAgeIgNgIIAAgCIAsgKIAACZIAOAHIAAACIgtAHgAgYAbQAAAvATAAQAHAAALgLIAAhSQgIgKgHAAQgWAAAAA4g");
	this.shape_30.setTransform(175.525,-13.425);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("AgcBUIAAgDIANgHIAAhYIgNgIIAAgDIAsgJIAABsIANAHIAAADgAgMgzQgGgGAAgHQAAgIAGgFQAFgGAHAAQAIAAAFAGQAFAFAAAIQAAAHgFAGQgFAFgIAAQgHAAgFgFg");
	this.shape_31.setTransform(165.75,-13.625);

	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#FFFFFF").s().p("AAAA7IguhrIgMgHIAAgCIA8AAIAAACIgNAHIAaBAIAShAIgNgHIAAgCIAnAAIAAACIgNAHIgoBrg");
	this.shape_32.setTransform(155.85,-10.9);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AgpArQgPgRAAgaQAAgZAPgRQAQgSAZAAQAaAAAPASQAQARAAAZQAAAagQARQgPASgaAAQgZAAgQgSgAgXAAQAAA2AXAAQAXAAAAg2QAAg0gXAAQgXAAAAA0g");
	this.shape_33.setTransform(143.575,-11.025);

	this.shape_34 = new cjs.Shape();
	this.shape_34.graphics.f("#FFFFFF").s().p("AgrA8IAAgDIAOgHIAAhYIgOgIIAAgDIAtgKIAAAYQANgXAOAAQAHAAAEAEQAEAFAAAGQAAAHgEAEQgFAFgGAAQgKAAgGgKIgLAIIAABPIAQAHIAAADg");
	this.shape_34.setTransform(132.675,-11.2);

	this.shape_35 = new cjs.Shape();
	this.shape_35.graphics.f("#FFFFFF").s().p("Ag5BQIAAgDIAOgHIAAiBIgOgIIAAgDIAtgJIAAAPQALgPASAAQAVAAALATQAJAQAAAWQAAAbgNASQgPATgbAAQgHAAgIgCIAAAeIAPAHIAAADgAgMg4IAABQQAFALAJAAQAWAAAAg3QAAgvgSAAQgHAAgLALg");
	this.shape_35.setTransform(121.425,-9.125);

	this.shape_36 = new cjs.Shape();
	this.shape_36.graphics.f("#FFFFFF").s().p("AAGA8IAAgDIALgHIAAhGQAAgYgOAAQgIABgKAGIAABXIALAHIAAADIg5AAIAAgDIAOgHIAAhYIgOgIIAAgDIAugKIAAAPQAPgOARAAQASAAAIANQAFAJABAUIAABCIANAHIAAADg");
	this.shape_36.setTransform(103.5,-11.2);

	this.shape_37 = new cjs.Shape();
	this.shape_37.graphics.f("#FFFFFF").s().p("AAHAyQgNALgPAAQgNAAgJgHQgJgHAAgNQAAgfA6gJIAAgOQgBgQgBgFQgDgLgMAAQgJAAgIAFQAMAEAAAMQAAAGgFAEQgFAEgFAAQgIAAgEgFQgEgEAAgHQgBgNARgIQANgGAPAAQAUAAAKAKQAKAKAAAYIAAA3QAAAKAGAAIAJgBIABAEQgNAJgOAAQgPAAgEgLgAgVAgQAAARAPAAQAFAAAHgEIAAgtQgbAHAAAZg");
	this.shape_37.setTransform(91.15,-11.025);

	this.shape_38 = new cjs.Shape();
	this.shape_38.graphics.f("#FFFFFF").s().p("AgiAsQgOgQAAgYQAAgZAQgTQARgUAZAAQANAAALAGQANAGAAAMQAAAHgEAEQgFAFgHAAQgGAAgFgEQgFgEAAgHQAAgLAJgDQgEgDgHAAQgPAAgIATQgFAPAAASQAAATAIANQAJAPASAAQAOAAANgEIACADQgWAPgYAAQgWAAgPgRg");
	this.shape_38.setTransform(79.725,-11.025);

	this.shape_39 = new cjs.Shape();
	this.shape_39.graphics.f("#FFFFFF").s().p("AgmA4IAAgkIAEAAIAQAVQAKAMAJAAQAHAAAEgEQAGgEgBgGQABgJgKgGIgSgLQgOgHgFgGQgJgKAAgPQAAgQAMgKQALgJAQAAQASAAAPAFIAAAjIgEAAIgNgUQgLgNgIAAQgHAAgEAEQgEAEAAAHQAAAJAJAHIATAMQAOAHAFAFQAJAJAAANQAAARgMAKQgMAKgRAAQgVAAgPgFg");
	this.shape_39.setTransform(64.85,-11.025);

	this.shape_40 = new cjs.Shape();
	this.shape_40.graphics.f("#FFFFFF").s().p("AgiBVQgVgHAAgOQAAgNAVgHQgMgGAAgLQAAgNAVgOQgXgKABgYQgBgSAOgLQANgLATAAQAMAAALAGIALgNQAHgGAGgBQAEABADADQAEADAAAEQAAAFgEADQgEACgFABIgSAAQASALAAAVQAAATgOALQgMAIgTABQgKgBgJgCIgFAMQAAAIAVAAIARAAQAYgBAIAIQAKAIAAAOQABATgVAKQgPAJgVgBQgSAAgOgDgAghA8QAAALALAFQAIAFAMgBQAjAAAAgUQABgMgVAAIgTABQgQAAgIgEQgDAHAAAIgAgRgiQAAAhAPgBQAPABAAghQAAghgPAAQgPAAAAAhg");
	this.shape_40.setTransform(53.8,-9.65);

	this.shape_41 = new cjs.Shape();
	this.shape_41.graphics.f("#FFFFFF").s().p("AAGA8IAAgDIALgHIAAhGQAAgYgOAAQgIABgLAGIAABXIALAHIAAADIg4AAIAAgDIAOgHIAAhYIgOgIIAAgDIAtgKIAAAPQAQgOARAAQATAAAHANQAGAJgBAUIAABCIAOAHIAAADg");
	this.shape_41.setTransform(41,-11.2);

	this.shape_42 = new cjs.Shape();
	this.shape_42.graphics.f("#FFFFFF").s().p("AgcBUIAAgDIANgHIAAhYIgNgIIAAgDIAsgJIAABsIANAHIAAADgAgMgzQgGgGAAgHQAAgIAGgFQAFgGAHAAQAIAAAFAGQAFAFAAAIQAAAHgFAGQgFAFgIAAQgHAAgFgFg");
	this.shape_42.setTransform(30.75,-13.625);

	this.shape_43 = new cjs.Shape();
	this.shape_43.graphics.f("#FFFFFF").s().p("AAAA7IguhrIgMgHIAAgCIA8AAIAAACIgNAHIAaBAIAShAIgNgHIAAgCIAnAAIAAACIgNAHIgoBrg");
	this.shape_43.setTransform(20.85,-10.9);

	this.shape_44 = new cjs.Shape();
	this.shape_44.graphics.f("#FFFFFF").s().p("AAHAyQgNALgPAAQgOAAgIgHQgJgHAAgNQAAgfA6gJIAAgOQgBgQgBgFQgDgLgLAAQgKAAgIAFQAMAEAAAMQAAAGgFAEQgEAEgGAAQgIAAgEgFQgFgEABgHQgBgNARgIQANgGAPAAQAUAAAKAKQAKAKAAAYIAAA3QAAAKAHAAIAIgBIABAEQgNAJgOAAQgPAAgEgLgAgVAgQAAARAPAAQAFAAAHgEIAAgtQgbAHAAAZg");
	this.shape_44.setTransform(9.15,-11.025);

	this.shape_45 = new cjs.Shape();
	this.shape_45.graphics.f("#FFFFFF").s().p("AgmA4IAAgkIAEAAIAQAVQAKAMAJAAQAHAAAEgEQAGgEAAgGQAAgJgJgGIgTgLQgOgHgFgGQgJgKAAgPQAAgQAMgKQALgJAQAAQASAAAPAFIAAAjIgEAAIgNgUQgLgNgIAAQgHAAgEAEQgEAEAAAHQAAAJAJAHIATAMQAOAHAFAFQAJAJAAANQAAARgMAKQgMAKgRAAQgVAAgPgFg");
	this.shape_45.setTransform(-1.4,-11.025);

	this.shape_46 = new cjs.Shape();
	this.shape_46.graphics.f("#FFFFFF").s().p("AgjArQgOgQAAgZQAAgZANgRQAOgUAYAAQAZAAAMATQAKAPAAAaIhBAAQAAASAJAOQAJAPATAAQAOAAANgEIACADQgWAPgaAAQgWAAgPgSgAgNghQgDAMAAAQIAhgDQAAgsgQAAQgKAAgEATg");
	this.shape_46.setTransform(-16.975,-11.025);

	this.shape_47 = new cjs.Shape();
	this.shape_47.graphics.f("#FFFFFF").s().p("AgpBUIAAgDIANgHIAAheIgTAAIAAgEIATgGQAAgYAMgNQAMgPAVgBQAMABAIAEQALAGAAAKQAAAGgFAFQgEADgGAAQgPAAAAgOQAAgJAHgDIgGgBQgQAAAAAbIAAASIAaAAIAAAKIgaAAIAABeIAQAHIAAADg");
	this.shape_47.setTransform(-26.225,-13.6);

	this.shape_48 = new cjs.Shape();
	this.shape_48.graphics.f("#FFFFFF").s().p("AgcBUIAAgDIANgHIAAhYIgNgIIAAgDIAsgJIAABsIANAHIAAADgAgNgzQgEgGAAgHQAAgIAEgFQAGgGAHAAQAHAAAFAGQAGAFAAAIQAAAHgGAGQgFAFgHAAQgHAAgGgFg");
	this.shape_48.setTransform(-34.7,-13.625);

	this.shape_49 = new cjs.Shape();
	this.shape_49.graphics.f("#FFFFFF").s().p("AgcBTIAAgCIANgIIAAiHIgNgJIAAgCIAsgJIAACbIANAIIAAACg");
	this.shape_49.setTransform(-41.7,-13.575);

	this.shape_50 = new cjs.Shape();
	this.shape_50.graphics.f("#FFFFFF").s().p("AgrA8IAAgDIAOgHIAAhYIgOgIIAAgDIAtgKIAAAYQANgXAOAAQAHAAAEAEQAEAFAAAGQAAAHgEAEQgFAFgGAAQgKAAgGgKIgLAIIAABPIAQAHIAAADg");
	this.shape_50.setTransform(-54.875,-11.2);

	this.shape_51 = new cjs.Shape();
	this.shape_51.graphics.f("#FFFFFF").s().p("AASAvQgRAOgQAAQgTAAgHgNQgGgJAAgUIAAg7IgOgIIAAgDIAugJIAABTQAAAYANAAQAIAAALgGIAAhRIgOgIIAAgDIAtgJIAABqIAOAGIAAADIgsAGg");
	this.shape_51.setTransform(-66.5,-11.05);

	this.shape_52 = new cjs.Shape();
	this.shape_52.graphics.f("#FFFFFF").s().p("AgpArQgPgRAAgaQAAgZAPgRQAQgSAZAAQAaAAAPASQAQARAAAZQAAAagQARQgPASgaAAQgZAAgQgSgAgXAAQAAA2AXAAQAXAAAAg2QAAg0gXAAQgXAAAAA0g");
	this.shape_52.setTransform(-79.175,-11.025);

	this.shape_53 = new cjs.Shape();
	this.shape_53.graphics.f("#FFFFFF").s().p("AgoBMQgGgFAAgHQAAgGAFgEQAEgFAHAAQAKAAADAKIAOgVIgphsIgNgGIAAgDIA5AAIAAADIgMAGIAYBEIAThDIgNgHIAAgDIAoAAIAAADIgOAHIgjBcIgJAYQgGAPgEAGQgIAMgLAAQgHAAgEgEg");
	this.shape_53.setTransform(-91.45,-8.775);

	this.shape_54 = new cjs.Shape();
	this.shape_54.graphics.f("#FFFFFF").s().p("AgSBAQgEgJAAgSIAAhFIgRAAIAAgCIArgoIAEAAIAAAgIAdAAIAAAKIgdAAIAABMQAAAIACAEQACAGAIAAQAIgBALgCIABAEQgSALgSAAQgQABgGgLg");
	this.shape_54.setTransform(-106.825,-12.4);

	this.shape_55 = new cjs.Shape();
	this.shape_55.graphics.f("#FFFFFF").s().p("AARAvQgPAOgSAAQgSAAgIgNQgFgJAAgUIAAg7IgOgIIAAgDIAtgJIAABTQAAAYAOAAQAJAAAKgGIAAhRIgOgIIAAgDIAtgJIAABqIAOAGIAAADIgtAGg");
	this.shape_55.setTransform(-117.75,-11.05);

	this.shape_56 = new cjs.Shape();
	this.shape_56.graphics.f("#FFFFFF").s().p("AhBBRIAAgDIAQgHIAAiMIgQgIIAAgCIA8AAQA+gBABAmQAAARgPAKQgKAJgTADQAWACANAHQARALAAAUQAAAVgVANQgRAJgXABgAgQBKIAQgBQAOgBAJgKQAHgJABgPQgBgjgjgCIgLAAgAgQgFIAHgBQAOAAAIgJQAJgJAAgPQAAgggagBIgMAAg");
	this.shape_56.setTransform(-131.6,-13.3);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_56},{t:this.shape_55},{t:this.shape_54},{t:this.shape_53},{t:this.shape_52},{t:this.shape_51},{t:this.shape_50},{t:this.shape_49},{t:this.shape_48},{t:this.shape_47},{t:this.shape_46},{t:this.shape_45},{t:this.shape_44},{t:this.shape_43},{t:this.shape_42},{t:this.shape_41},{t:this.shape_40},{t:this.shape_39},{t:this.shape_38},{t:this.shape_37},{t:this.shape_36},{t:this.shape_35},{t:this.shape_34},{t:this.shape_33},{t:this.shape_32},{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.text2, new cjs.Rectangle(-234.4,-27.8,558.9,52.6), null);


(lib.logo_2 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#FFFFFF").s().p("AhRCeIAAgEIAvgWIAAkSIgBAAQgNAAgNACQgPAHgIAHQgKAIgyA0IgFgCIAHhaIEbAAIAJBaIgFACQgyg0gKgIQgIgIgPgGQgIgCgIAAIgHAAIAAESIAvAWIABAEg");
	this.shape.setTransform(-100.1353,0.7846,0.5226,0.5226);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AjvFfQgdAAgYgNQgdgPgQgdQgDgGgFgOQgGgTAAgOIAAngQABguAgghQAhggAugBQB3ABB4BDIAAgBIAAABQB5hDB4gBQAuABAgAgQAgAhAAAuIAAHgQAAAtggAhQggAhgugBgAkykyQgbAcAAAnIAAHgQAAANAEAOIAHARQAOAaAYAMQAUALAZAAIHgAAQAmAAAcgbQAcgcgBgmIAAngQABgngcgcQgcgbgmAAQh5AAh4BGQh3hGh4AAQgnAAgcAbg");
	this.shape_1.setTransform(-100.2694,-4.1699,0.5229,0.5229);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#5493C0").s().p("AjvErQgnAAgcgbQgbgcAAgmQAAiIBgiPQBgiQCNhRQCOBRBgCQQBgCPAACIQAAAmgbAcQgcAbgnAAg");
	this.shape_2.setTransform(-100.266,-2.3512,0.5226,0.5226);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#4CABA1").s().p("AjvFOQgnAAgcgbQgbgcAAgnIAAnfQAAgnAbgcQAcgbAnAAQBoAABrA2QBjAyBUBXQBSBWAwBjQAxBnAABeQAAAngbAcQgcAbgnAAg");
	this.shape_3.setTransform(-100.266,-4.1674,0.5226,0.5226);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#63BBEA").s().p("AjvFOQgnAAgcgbQgbgcAAgnQAAheAxhnQAwhjBShWQBUhXBjgyQBrg2BoAAQAnAAAcAbQAbAcAAAnIAAHfQAAAngbAcQgcAbgnAAg");
	this.shape_4.setTransform(-100.2563,-4.1568,0.5229,0.5229);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AhSCeIAAgEIAwgWIAAkTIgBAAQgOAAgNAEQgNAEgJAJIg8A8IgFgCIAHhZIEbAAIAJBZIgFACQgygzgKgJQgJgJgOgEIgRgDIgHAAIAAESIAwAWIAAAEg");
	this.shape_5.setTransform(-100.1216,0.7809,0.5223,0.5223);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#65A5CF").s().p("AjvErQgnAAgbgbQgdgcAAgmQABiIBgiPQBgiQCNhRQCOBRBgCQQBhCPAACIQgBAmgbAcQgcAbgnAAg");
	this.shape_6.setTransform(-100.2653,-2.3659,0.5223,0.5223);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#58B2AF").s().p("AjvFOQgnAAgbgbQgdgcAAgnIAAnfQAAgnAdgcQAbgbAnAAQBoAABrA2QBjAyBUBXQBSBWAwBjQAxBnABBeQgBAngbAcQgcAbgnAAg");
	this.shape_7.setTransform(-100.2653,-4.1809,0.5223,0.5223);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#72C1E9").s().p("AjvFOQgnAAgbgbQgdgcAAgnQABheAxhnQAwhjBShWQBUhXBjgyQBrg2BoAAQAnAAAcAbQAbAcABAnIAAHfQgBAngbAcQgcAbgnAAg");
	this.shape_8.setTransform(-100.2529,-4.1674,0.5226,0.5226);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#FFFFFF").s().p("AiRCmIAAgHIAlgVIAAj2IgjgWIAAgGICXgdIAAA8QASgeASgOQATgPAYAAQAaAAAQAQQARAQAAAYQAAAagPAPQgPAQgbAAQgVAAgPgNQgPgMgHgVIgXAPIAADcIApAVIAAAHg");
	this.shape_9.setTransform(127.9335,4.5869,0.5226,0.5226);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#FFFFFF").s().p("Ah2B/QguguAAhRQAAhQAugtQAsgsBKAAQBLAAAsAsQAuAtAABQQAABRguAuQgsArhLAAQhKAAgsgrgAgghsQgIAhAABLQAABMAIAhQAJApAXAAQAYAAAKgpQAHgiAAhLQAAhKgHgiQgKgpgYAAQgXAAgJApg");
	this.shape_10.setTransform(111.64,4.8482,0.5226,0.5226);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#FFFFFF").s().p("Ag3C7QgZgZAAg8IAAi6IglAAIAAgLQBthRAhggIAKAAIAABaIBKAAIAAAiIhKAAIAADGQAAAYAFAMQAHAQARAAQAUAAAdgIIAFAOQgyAlg+AAQgoAAgVgWg");
	this.shape_11.setTransform(97.607,2.836,0.5226,0.5226);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("AAJCmIAAgHIAagUIAAjIQAAgggEgLQgFgSgSAAQgUAAgXAQIAAD1IAbAUIAAAHIizAAIAAgHIAkgVIAAj2IgkgWIAAgGICYgdIAAAlQArgkA2AAQAuAAAWAbQAVAbABA6IAAC+IAlAVIAAAHg");
	this.shape_12.setTransform(82.4112,4.5869,0.5226,0.5226);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#FFFFFF").s().p("AhoB+QgtguAAhLQAAhPArgvQAsgwBHAAQBIAAAkAvQAhAsAABRIixAAQAAA3ANAbQASAoA0AAQAnAAAtgPIAEAMQg9AwhKAAQhEAAgtgsgAgXhvQgEAbAABBIA3gHQgBhBgDgZQgGgggQAAQgSAAgHAlg");
	this.shape_13.setTransform(64.5367,4.8482,0.5226,0.5226);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#FFFFFF").s().p("ABlCmIAAgHIAagUIAAjIQAAgggEgMQgHgRgUAAQgSAAgaATQAFAWAAAdIAAC/IAaAUIAAAHIinAAIAAgHIAagUIAAjIQAAgfgEgMQgHgSgRAAQgRAAgXAQIAAD1IAaAUIAAAHIizAAIAAgHIAlgVIAAj2IgkgWIAAgGICYgdIAAAlQArgkAyAAQA6AAAUAqQAxgqA1AAQA0AAAXAbQAVAaAAA7IAAC+IAlAVIAAAHg");
	this.shape_14.setTransform(42.5465,4.5869,0.5226,0.5226);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#FFFFFF").s().p("Ah/DPQgPgPAAgXQAAgXAPgPQAQgPAWAAQARAAANAKQANALAGATQAVgcALgXIiJktIglgTIAAgIIDHAAIAAAIIgmASIA+CyIA6ixIgngTIAAgIIB7AAIAAAIIglATIiFFAQgnBjg7AAQgaABgQgRg");
	this.shape_15.setTransform(12.8864,8.1017,0.5226,0.5226);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AhoB+QgtguAAhLQAAhPArgvQArgwBJAAQBHAAAkAvQAhAsAABRIixAAQAAA3ANAbQASAoA1AAQAnAAArgPIAFAMQg9AwhJAAQhGAAgsgsgAgXhvQgEAbAABBIA3gHQAAhBgFgZQgFgggQAAQgSAAgHAlg");
	this.shape_16.setTransform(-3.0673,4.8482,0.5226,0.5226);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AAJCmIAAgHIAagUIAAjIQAAgggDgLQgGgSgSAAQgTAAgYAQIAAD1IAbAUIAAAHIi0AAIAAgHIAlgVIAAj2IgjgWIAAgGICXgdIAAAlQArgkA1AAQAwAAAVAbQAWAbgBA6IAAC+IAlAVIAAAHg");
	this.shape_17.setTransform(-20.2623,4.5869,0.5226,0.5226);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("Ah2B/QguguAAhRQAAhQAugtQAsgsBKAAQBLAAAsAsQAuAtAABQQAABRguAuQgsArhLAAQhKAAgsgrgAgghsQgIAhAABLQAABMAIAhQAJApAXAAQAZAAAJgpQAHghAAhMQAAhLgHghQgJgpgZAAQgXAAgJApg");
	this.shape_18.setTransform(-38.6201,4.8482,0.5226,0.5226);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("ABlCmIAAgHIAagUIAAjIQAAgggEgMQgHgRgUAAQgSAAgaATQAFAWAAAdIAAC/IAaAUIAAAHIinAAIAAgHIAagUIAAjIQAAgfgEgMQgHgSgRAAQgRAAgXAQIAAD1IAaAUIAAAHIizAAIAAgHIAlgVIAAj2IgkgWIAAgGICYgdIAAAlQArgkAyAAQA6AAAUAqQAwgqA2AAQA0AAAXAbQAVAaAAA7IAAC+IAlAVIAAAHg");
	this.shape_19.setTransform(-61.3813,4.5869,0.5226,0.5226);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgkBnIgcgGIgEg1IAEAAIAUAVQAVAXAIADQAdALAOgTQAIgKgEgOQgDgMgKgGIgagRIgcgRQgcgRgEgfQgCgUAKgQQAKgQAQgGQATgIAeACQAOABAWAFIAEAzIgDAAIgngpQgFgEgHgCQgMgDgMAIIgHAJQgGALAHAOQAHANAUAOQAKAHAOAIQAUALAIAHQAVAVgEAaQgDAagUAPQgNAJgSAEQgIABgJAAQgPAAgSgDg");
	this.shape_20.setTransform(42.2593,-16.4751,0.5226,0.5226);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AAoBnIAAgDIAZgPIAAiQIhJCfIgJAAIhOijIAACUIAZAPIAAADIhCAAIAAgDIAagPIAAiqIgagOIAAgDIBKAAIBECMIA/iMIBEAAIAAADIgZAOIAACqIAZAPIAAADg");
	this.shape_21.setTransform(20.8306,-16.4887,0.5226,0.5226);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("AhYBnIAAgDIAZgPIAAiqIgZgOIAAgDICnAAIAEA2IgDABIghgiQgFgFgKgDIgvgDIAABXIAjgBQAHgBAGgIIAPgRIADAAIAABDIgDAAIgSgZIgEgEQgEgBgGAAIgfgBIAABZIAggBIATgDQAHgBAHgGQAJgJAagdIAEABIgEA6g");
	this.shape_22.setTransform(33.0997,-16.4887,0.5226,0.5226);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhYBnIAAgDIAZgPIAAiqIgZgOIAAgDICnAAIAEA2IgDABIghgiQgFgFgKgDIgMgCIgjgBIAABXIAjgBIAGgCIAIgHIANgRIAEAAIAABDIgEAAIgSgZIgDgEQgEgBgGAAIgfgBIAABZIAggBIASgDQAIgBAHgGQAJgJAagdIAEABIgDA6g");
	this.shape_23.setTransform(-48.2498,-16.4887,0.5226,0.5226);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AgbCKIgHgCIgJgBIgDgFIAAgGQgDgKABgCIADgCIABgBIgEgFIgGgHIACAMQgCALgFAEQgKAHgGgMQgEgIgRgFQgFgBgOAFIgLAEIgDgFIAHgEQAKgEAKgCQAQgDAPAPQADADADgCQACgDgDgCQgMgMgGgCQgKgDgHABQgMACgqAOQgsAOgVADIgpACQgVABgsgEIgqgEIgEgLIASADIAmADQAzAEAfgCQAcgCBSgcQAhgLANAKQAMAKAKAJIgCgIIgQgRIgKgKQAAABgBAAQAAAAAAABQAAAAgBAAQAAAAAAAAIgEAAQAAgBAAgBQAAAAAAgBQgBAAAAgBQAAAAgBAAIgDABQAAABgBAAQAAAAAAAAQAAABgBAAQAAAAgBAAIgDgBIgBgBIgBAAIgDACQgBADgFAAIgDgBIgCgBIgBgCIgCABIAAABIgFABIAAgEQAAgBAAgBQAAgBAAAAQgBgBAAAAQgBAAAAAAQgBAAAAAAQgBABAAAAQAAAAgBABQAAAAAAABIgDAMQAAAAAAABQAAAAABAAQAAAAAAAAQABAAABAAIACgBIAAACIgTAGIAAgCQADAAABgDIAEgNQAAgBgBAAQAAgBAAAAQAAAAAAAAQgBAAAAAAIgJAKIACgKIASgFQAFgCgCgCQAAgBgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAIg/AUQgaAJgQACQgJABgZgBIgVgBQgCAHgDABIgGACIACAFIgOAHIgDgKIALgDQAAAAABgBQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAIgJACIgCgBQgBAAAAgBQgBAAAAAAQAAgBAAAAQAAAAAAgBIAAgDQgBAAgBAAQgBAAAAAAQgBAAAAgBQAAAAgBAAIgDgEIgIgBIgEADQAAABAAAAQAAAAgBAAQAAAAAAAAQAAAAgBAAIgBgCIgCABIgBgBQgBAAAAABQgBAAAAAAQAAAAgBABQAAAAgBAAIgCgCQAAAAgBABQgBAAAAAAQgBAAAAgBQAAAAAAAAIAAgDIgGgCIABgBIgBgCIAAgCIABgDIAFAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAgBQAAAAABAAQAAAAABAAQAAAAABABQAAAAAAAAIACgBIAFABQAFAAABgCIgDgBIgFgBQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAgBAAAAIACgFIABgCIgIACQgDAAgBgCIgCgCIgEgBQAAAAAAAAQgBAAAAgBQAAAAABAAQAAAAAAAAIAAgCIgDgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAIgFgBIgCgDQAAgBgBAAQAAgBAAAAQAAAAgBgBQAAAAAAAAIgBgBIAAgBIAEABIAAgBQAAgBAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIAEAAIANgDIACAAIADgBIABgCQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAAAAAIgEABQgEACgDAAIgCABIAAgCIgFABIgBgBIAAgBIgDAAQAAAAgBgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIAAgCIgDgCIgBgDIgDgDIABgBQAAAAgBgBQAAAAgBAAQAAAAgBgBQAAAAAAgBIgCgFIgCgFIAFACQAAAAABAAQAAAAAAAAQAAAAAAgBQAAAAAAgBIAHAEIACABIAAgCIAEABQAAABABAAQAAAAAAAAQAAAAABAAQAAAAAAgBIADACQABAAAAAAQAAABAAgBQABAAAAAAQAAAAAAgBIADACQAAAAABAAQABAAAAABQABAAAAAAQAAABAAAAIADAGQAAABAAABQAAABABABQAAAAAAAAQAAABABAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAAAgBIgCgGIgDgGIgBgEIACAAIgBgDIACAAIgBgDIACAAIACgCIAAgEQAAgBABABQAAAAAAAAQABAAAAABQAAABAAABQACADAFADQAEADAAAEIgBACIACgBIADAAIADADIABgCQAAgBAAAAQABgBAAAAQAAAAABAAQAAgBABAAQAFAAgCgDQgFgEAAgEIADgGQgBgHgEAAIgLAAQgCAAgFgFIgCgHIADgBIAIACIAHgBIAKgEQAFAAAFAEIADADIAEAAQAEgBABABQAFADAAAGQAAABAAAAQAAABAAABQAAAAAAAAQAAABAAAAIARgDQAOgBAGACQAPAFADARQADAQgFADIABADIACACIAFABIgCgEQAAgBAIgBQABgBAAAAQABAAAAgBQABAAAAgBQAAAAABgBIgLgFQAAgBAEgDIAJgDIAFgCQADAAADgDQAAAAABAAQAAAAAAAAQAAgBAAAAQgBAAAAAAIgEgBIgIADQgHADgDgCIgDgCIAEgBQAEAAAGgFQACgCAHgBQAJgEgEAAIgEgBIgCgDIAAgIQACgEgDADIgFADQACAIgCABQAAAAAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAIgCgDIgHgDIgDgEQgEgDAAgBIACgHIgBgCQABgBAAgBQAAAAAAgBQABAAgBAAQAAgBAAAAQgCAAgDgEQgBgBAAgBQAAAAgBgBQAAAAAAgBQAAAAABgBIAGgOIAFgKIgCAAIgBgBIAAgBIgDgBQAAAAAAABQAAAAgBAAQAAAAAAAAQgBAAgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBIAAgCIgCgBQgBAAgBAAQgBAAAAAAQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBQABAAAAgBIADgCIAAgDIgDgBQgBAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQABgBAAAAQABgBAAAAQABAAAAgBQABAAAAAAIACABQAAAAAAAAQABAAAAAAQAAAAAAABQAAAAAAAAIADgBIgBgBQAAgBABAAQAAAAAAgBQAAAAABAAQAAgBABAAQABAAABAAQAAAAABAAQAAAAABABQAAAAAAABIADAAIgDgFIAEAAIAEABIABgEIgIgEIATgJIgEAJIACABIAEgFIACgBIACAJIACAAIgBgCQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAABAAQAAgBAAAAQABAAAAAAIABAAIACgBIgCgDQAAgBAAAAQAAgBABAAQAAgBAAAAQAAAAABAAQABgBABAAQAAAAABAAQAAAAABABQAAAAAAABIAEgCIABgCQAAAAAAgBQAAAAABAAQAAgBABAAQAAAAABAAQADABAAAFIADgBQAAgBABAAQAAAAABAAQAAAAABABQAAAAABAAQACADgDAEIAAACIADAAQABAAAAAAQABAAAAAAQAAAAABABQAAAAAAAAQABADgBACIADADIACAEIgBAFIABADIAEgCQAAAAAAgBQABAAAAAAQAAAAAAAAQAAgBAAAAIAEAAIAJABIAHAAIAEgDIACADIgCAFIADADIAFAAIAGgDIACABQAAAHgDABIgGAAIgBABIABABQACACAGABIAEABIgCAEIgDADIAGAFIADACQgCABgEAAIgHAAQAAAAAAAAQAAAAAAAAQAAABAAAAQABABABAAIAGAEIAGADIgCAFIAFAGIAAADQAAABAAAAQAAABAAAAQAAABAAAAQAAABAAAAIADAFQgEgBgDgEIgCgEIgEgDQAAgBAAAAQgBAAAAAAQgBAAAAABQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABAAAAQABABAAAAIAEAHIACAGIAJAHIADAIQABABAAAAQABABAAAAQABABAAAAQABAAAAAAIAHgDIAFgDIADgJIACgGIgLgMIAJgCQgFgJgDgCIgDgGIAKACIAGADIgFgLIgCgIIAEACIAJAHIAAgQIACgDIADAFIAJAJQAFAEgCgEQAAgBAAAAQAAgBABAAQAAAAAAgBQABAAABgBIACgBIAAgDIABgDIgFgFQgEABAAgCIAAgFQgGACgCgEQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAIADAAIgBgCQgGABABgGQAAAAAAgBQAAAAAAgBQAAAAABAAQAAgBABAAIACAAIABgBIgCgCQAAAAAAgBQgBgBABAAQAAgBAAAAQAAgBABAAQAEgEABAEIABgBIgBgCQAAAAABgBQAAgBAAAAQAAAAABgBQAAAAAAAAQAEgCADADIAAAAIAAgCQAAgBAAAAQAAgBABAAQAAgBABAAQAAAAABAAQAFgBABAGIABAAIAAgCQABgBAAAAQAAgBABAAQAAAAABAAQAAgBAAAAQAGAAAAAEIABABIAGgHIAIAGIAAgRIAEABIgBgFIAcABIgBAFIAFgBIAAASIAKgIIABAEIABABIABgBQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQABAAABAAQAAAAABAAQAAABAAAAQABABAAABIAAAAIABgCQAAgBABAAQAAgBABAAQAAgBABAAQAAAAABAAQABAAAAAAQABAAAAAAQABAAAAABQAAAAABABIAAADIABgDQABAAAAgBQABAAAAAAQABAAAAAAQABAAABAAQAAAAABABQAAAAABAAQAAABAAAAQAAABABAAIgBADIAAAAIABABIACgCQADgBACACQAEADgEAEIABACIACgBQABAAABAAQAAABABAAQAAAAAAABQAAAAAAABQABAHgGgBIgBABQAEACgBADQgCAEgFgCIgBABQABABAAAAQABAAAAABQABAAgBABQAAABAAAAQgBADgEgCIgGAEIACADQABAAAAAAQAAABAAAAQAAABAAAAQgBABAAABIAKAHIANgRIACARQAAABAAAAQABAAAAAAQAAAAABgBQAAAAABgBIAIgKIgDARIAHgDIAIgDIgHANIgFAHIANAAIgPAPIAHATIAYAJQAMACAKgBIgEgDIABgOIABgKIAHAAIADAGIADAGIAGgFIADgDIAFgBIgBgGQgEgBgCgDIgBgFIgFgEQgCgCgDAEQgEAEgFgCQgBgBgFABQgBABgDALIgDAEQgCACgFgBQgJAAgBADIgCAFIgEABQgCgIABgDQABgIAFgCQAGgCABgEIgFgIQgBAAAAAAQAAgBAAAAQAAAAAAgBQABAAAAAAIACgDIgCgFQgBgFADgBIAEgBIAEgBIAFgDIAGgFIAHAAIAGADQACAAABAAQABgBAAAAQABAAAAAAQAAgBAAAAIgFgIQAAAAAAAAQAAAAAAgBQAAAAAAAAQABAAAAAAIABgBIAHADIADABIgEgGIgCgDIALABIABgCQgEgBAAgBIgEgEQgBAAAAAAQgBgBAAAAQgBAAAAAAQgBgBAAAAQgCgFgBAAQgDAAgCgCQAAgBAAAAQAAgBAAgBQgBAAAAgBQgBAAAAAAIgDgBIgCgCIgDgEQgDAAgBgCIgDgEQgEAAAAgCIgBgHQAAgBAAgBQAAAAABAAQAAAAAAAAQABAAAAABIACADIAFABIACADIABAAIADABIACADIAEABIACAEIADgBQAAAAABAAQAAAAABAAQAAABAAAAQAAAAABAAIAEAFIAFACIADAEIAEACIAHAFIACgEIAEgGIABgDIAFACIABAEIAAAIIgBAHIADAEIABgIIAJgMIAGACIAAAHQAAAEACADQAEAEAAAEQAAABAAABQABABAAAAQAAAAAAAAQABAAAAAAIAGgDIAFgDIAJACQABAAAAAAQABAAABAAQAAAAABAAQAAgBAAAAQAAgFADgBIALgDIAAABIgIADQgCABAAAEQAAAFgEAAIgNgCIgMAHIgDADIgBACIAGAHIAHAMQAKAYgFARIgFAQIAAACIACAAIgDAGQAAABAAAAQAAAAAAAAQABABAAgBQAAAAABAAIAIgCIAEACQAEAAAEgCQAHgEAFAAQAGAAAHAFIABABIABAAIACADIAGALIABABIABgBIABgJQAAgJgCgCIgBgEIAEgCIALAJQAAABABAAQAAAAAAgBQAAAAAAAAQABgBAAgBIABgMIABgFIADAFIAAALQAAABABAAQAAABAAgBQAAAAABAAQAAgBABgBIALgJIAFgCIAEABIgJANIACAAQABAAABAAQABAAAAAAQABABAAAAQAAAAABAAIACACIABABIADAAIAAgFIgCgHIADgCIACAFIAEADIAEgLIAEgCIACAHIAJgIIAFACIgEAJIgBAHIAJgBQAHgBAHACQAAAAABABQAAAAAAAAQAAAAAAAAQAAABAAAAIgDABIgXAJIALgBIAKAAQABAAABAAQAAABAAAAQAAAAAAAAQAAABAAAAIgFACIgKAEIgHAEIANADIAEACQAAABABAAQAAABAAAAQAAABAAAAQAAABAAAAIgLgCIgNABIgHACIABAKIATgIIgCAOIAHgCIALgEIgDAHIgJAKIADABQAAABAAAAQABAAAAAAQABAAAAAAQAAAAABAAIAPgHIgFAPIgdARIgOgEIAYgPIgLgDIABAGQAAAAAAABQAAAAAAAAQAAAAgBAAQAAABAAAAIgEgBIgBABIgDgBQABABAAABQAAABgBAAQAAABAAAAQAAAAAAAAIgMgBIADAGIgBACIAFAFIgGAHIgJgHIAEgEIgHgHIgEgDIgHAAIAAADIAHAAIAFAKIgDABIgCgEIgFgBIgDAFIACAGIAFACIgRABIADgCIgBgCQgEABgCgCIgGgEIABAFQAAABAAAAQAAAAABAAQABABAAAAQABAAABAAIAAABIgPABIAAgCQABAAAAAAQABAAAAAAQABgBAAAAQAAgBAAAAQgEgNgCAAIgFgCIAAgBIACgBIAAgDIgCgBIgTgBQgVgDgRgEIhQgWQgegFgGAEQgFADgBAJIgJAVIgIALIgCAHIgBAGIAFgIQAHgKAIgEQAMgHAJgBQAMgBATAHQA+AVA0AGQArAFA6gHIAfgFIgLAOQg8AJgkgDQg6gFgegIQg/gVgPgDQgPgDgUATQgFADAFACQAEACABgCQAHgKAVgEQAJgBAVALIgFAIQgIgFgNgDQgJgCgJAGIgMAKQgDACgGgBQgGgBgCgCQgEgDAAgGIAAgNIgDAEIAAAHIgGAHIgGgBIgNAHIABAFQgCAFgEABQgNAAgKgCIgTgGIgEAFQACADgGADIgFABIgCAAgAgtB2IADAMIAOABQAGAAABgDQABgCgFgDQgEgCgEADIgEADIgCgBIgBgCIADgGQABgDgFgCIgCAAQgDAAABAFgAg1BZIAJANQAJALAjANQAHACAKABIAJABIACgCQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAIgHgBIAPgIIAAgCQAAgBAAAAQAAAAgBAAQAAAAgBAAQAAAAAAABIgRAIIgGgBIAPgIQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAIgCAAIgPAIIgEgCIANgHQABAAAAAAQAAgBgBAAQAAAAgBAAQgBAAgBAAIgNAHIgFgCIAOgIQAAAAAAAAQAAAAAAgBQgBAAAAAAQgBAAgBAAIgPAIIgCgCIARgJIASAFQAKACARAAQACgBACgCQAAgBABAAQAAAAAAgBQAAAAgBAAQAAAAgBAAQgEACgTgCQgMgCgQgHQgIgEgMgKIgMgKQAAgBAAAAQAAAAAAAAQgBABAAAAQgBAAAAABQAAAAAAAAQgBAAAAABQAAAAABABQAAABAAABIABADIgDACIgDgCIgCABIgBABQAAAAAAABQAAAAABAAQAAAAABAAQABABABAAIACADQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAgBIAEgCIACACIgFADIgMAGIgCgCIADgCQAAgBAAAAQAAAAAAAAQAAgBgBAAQAAAAgBgBIgDADIgCgCIgCgBQAAAAgBAAQAAAAAAAAQgBABAAAAQAAAAAAAAgAEoBnIgGgPQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAAAABAAIABABIAEAFIAFAGQACABAAgDIgKgRIgBgGQgGgEgBgCIgGgLQgFgLAAgDQgFgXgCgBIgHgEQgFgCgEACQgIACgEAEIgCADIgDACQABABAAAAQAAAAAAAAQABAAAAAAQAAAAABAAIAGgDIACADQAAAAABABQAAAAABABQAAAAABAAQAAAAABAAIANgBIABACIgIAFIgBADQAAAAAAAAQAAABAAAAQAAAAAAAAQABAAAAAAIAIgDIABACIgHAGQAAAAAAABQgBAAABAAQAAABAAAAQABAAAAAAIAIAAIABADIgGADQAAAAAAAAQAAABAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQABABAAAAQAAAAAAAAQABAAAAAAIAEAAIABAFIgEACQAAAAAAAAQgBABAAAAQAAAAAAAAQAAAAABABIACABIAFABIABAEIgDACQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQAAABAAAAQABAAAAAAQAEAAABABQABAAAAABQAAAAAAABQAAAAAAAAQAAAAAAAAIgEABQAAAAAAAAQgBAAAAABQAAAAAAAAQAAABgBAAQAAABABAAQAAAAAAABQAAAAABAAQAAABABAAQAEAAAHgCIABACIgGADQgCADAEAEQAJAJAEAAIACAAgAAYBSIAAACIAMAPIACAAIABgBIgNgSIgCACgAANgvQANABAIAHQAcAWgBAdQAAAkgRAQIgPAOIAPAUIADgBIgOgTIACgBIAQAUQAAAAABAAQAAAAAAAAQAAgBABAAQAAAAAAgBIgPgTIABgBIARATQAQgNAGgOQAJgXABgLQAFgdgPgkQgFgNgNgLIgLgIIgDABIgLgGQgOgGgOAAQgMAAgOAEQgNAEgGAFQgBABAAAAQgBAAAAAAQgBAAAAAAQgBAAAAAAIgCgBQgPAPgGANQgIASgEAUQgBAJABANQAAABAAAAQAAABABAAQAAAAABAAQAAAAABAAQABAAABAAQAAAAABAAQAAAAABgBQAAAAAAAAIACgCIAFgBIABABIAMgDQAAAAAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBIAAgGQAAgOAGgOQAIgSARgHQAOgGAMAAIAGAAgAExBRIALAHIAJAJIACAAIgEgIIgGgGIALADIAFAAIgDgDIgKgHIADgEIgBgBgAARBcQAAAAgBAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAABAHACIACAAIgBgCIgFgEIAAAAIgCABgAksBNIgBAGIgDAEQgBACAAADQACAFAGgGQACgBABgDQAAgBAAgBQAAAAAAgBQAAAAgBgBQAAAAgBgBQAAAAAAAAQgBgBAAAAQAAgBAAAAQAAgBgBAAIAAgCgAkvBOQAAAAAAAAQgBAAAAABQgBAAAAAAQgBAAgBAAQgHABgDAFQAAABAAABQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAABQABAAAAAAQABAAAAAAQABAAAAAAQADAAAEgFQAFgDAAgGgAgnBYQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgBgBIgBABgAgJBNIARABIgFAMIAbgaQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBAAAAAAQAAAAgBAAIgHAEIgSAAIgCAFIAQAAIgBACIgQAAIgCACIAQABIgBACIgSAAgAFcBJQgBABgBAAQgBABAAAAQAAABAAAAQABAAABABIAJAEIAJAEQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAIgMgHIAIgGQAFgEAAgDgAFWBUIgBgEIgHgEIAOgLQADgEABgFIgOAHIgFADIgDgQIgDATIgCAIIAIADIAJAEgAgFBUIADAAIACgCIgLgBIAGADgAgkA5IABAEIAAADQgCACgEAAIgYAJQgEACABADQACAFAIgCIARgGQAMgGAAgEQAAgJgCgFQgHgEABgBQABgQgEgEQgFgEgHABIgIADIgBADIACADQAAAAAAAAQABAAAAAAQABABAAAAQABAAAAAAIALgDQABAAAAAAQAAABABAAQAAABAAAAQAAABAAABIAAAIIACADIgCABIAAACQAAAAABAAQAAABAAAAQABAAAAAAQABAAABAAgAECBNQgBAAAAABQAAAAAAAAQAAAAAAAAQAAABAAAAIABAEIACABQABAAAAAAQAAAAAAgBQAAAAAAAAQAAAAAAgBIgCgEIgBgBIAAAAgAklBNIACADQACADADAAQABAAABAAQAAAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAAAAAQAAAAAAgBQgBAAAAAAIgIgEIgDgBIAAABgAD4BEIgGAFQgCAEADAEQAAAAABABQAAAAABAAQAAABABgBQAAAAABAAIACgCIgBgEQgBgBAAgBQAAAAABgBQAAAAAAgBQAAAAABgBIACgCIgBgBIgBgBIgBABgAlWBRIABABQACAAADgFQAAABABAAQAAAAAAAAQABAAAAAAQAAAAAAgBIABgDQABAAAAAAQAAABABAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBAAAAQAAgBgBgBIAEgDIgBgBIgCAAIgWANQAAABAAAAQAAABAAAAQAAABABAAQAAAAAAAAIAGgBIAAABQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQAAAAAAAAgAjkBKIgIAHIAPgCIAVgGQgKgGgHgDQgFgCgHgLQgGgKgDgKQgCgHgHAAQgEAAgDACIgRAPQgJAJgIgBQgFAAAAgHIAAgHIgDAFQgCAGAFAEQAHAHAPgKQAHgEALgFIABADIgNAIQgHAFgFAHQgBACAMgHIAUgLIACACIgUANQgEADgEAHQgHALAFgGQACgDAQgKQAFgDAMgFIABADQgPAHgEAEIgJAMIAPgJQAEgDANgEIAAACIgQANQgDADAHgCIARgIgAlBBDIgEAEQgBACAEAEQADADADgBIAMgGIgIgCIgEgDIgBgCIgBAAIgDABgAgMBBQgGAKgBACQAAABAAAAQAAAAAAAAQAAAAABAAQAAAAABAAIAHgGIAHgHQACgEgEgBIAAAAQgDAAgEAFgADWBGQAAAAAAAAQAAAAAAABQAAAAAAAAQgBABAAAAIgFABIADADIAGACIAEgCIAHgEQACgDgHgKQgDgDgEAAIgGACIgJAAIgRgFQgFgDgCgBQgEgFgFgBQgEAAgFACIgFADIgDgCIgBgCIADgCQAEgCAAgDIgBgDIADgCIAAAIIACAAIABgCIAAgEIgBgDIAFgCIAAABIABADIABAGIABAAIABgDIgCgJIACgBIADABIABAEIAAAHIACAAIAAgBIABgHIABABIADACIAAACIgCAFIACABIAJgRIgCgBIgBABIgBACIgBAAIACgFIgCgCIgDAFIgBgBIAAgCIABgGIgDgBIgCAIIgBgBIAAgEIABgEIgCgBIgDAIIgBgBIABgHIgDAAIgBAGIgCABIgEACIgJgBIAAAGIgOAIIgFgBQAAADgCACIgPAHIgDACIADABIARgHIADABIgOAGIADABIANgFIACABIgJAEIADABIAHgEIABACIgEADIACACIAFgDIABACIgDACIA0AQQADAAAFgBIAGgCIAEADgAEnBCIACAKIAGgBIAJgEQAHgDAFgHIgEAAIgJAAIABgHIAAgKIAAgBIgBABIgGALIgFAIIgDgDIgEgDgAD8BEQACAEgEACQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIACABIAFgDQACgCgCgFIgFgJIgEgBIgEACIAAACQAAAAABABQAAAAAAAAQABAAAAAAQABgBABAAgAkdBAQgBADgLAGIAFABQAGABAEgBQADgBABgEQAAAAAAgBQABgBAAAAQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAAAgBQgBAAAAAAQgBAAAAAAIgCAAIgCABgAhNAxQgEALAGAHQABACAGACIAEACQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBgBAAAAIAUgJIAGACIgBgEIgHgKIgBgNQAAgBAAgBQAAAAAAAAQgBAAAAABQAAABAAABIgBALIgZAJIAAgDIgCgFIAAAAgAhwBAIgBAGQAAAAABAAQAAAAABAAQAAAAAAAAQAAAAABgBQABgCAAgEIgGgLIAAgDIAFACIAGACIAAACIgBADIADgCQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAIAAACQAAAAgBABQAAAAAAABQAAAAgBABQAAABAAAAIACgBIABgCIgBAFIAAACQAAABAAgBIADgEQACgEgEgFQgBgEgFgCQAAAAAAgBQAAAAAAAAQAAAAAAAAQAAgBAAAAIADAAQACABACACIADABIAAAEIADgCQAAgBAAAAQAAAAAAABQAAAAAAABQAAABAAABIgCADQAAAAABAAQAAAAABgBQAAAAAAAAQAAAAABgBIAAAAIABACIgBADQgBABAAABQAAAAABABQAAAAAAAAQAAAAAAgBIADgEIgDgMQgBgDgIgDIgLgEIgigGIgCgFQgCgDgDAAIgCAGIgCAEIgDADIgDAFIgCAFIgEAAIgBgGQAAgEgCgBIgEAEIgOAKQgBABAAAAQgBABAAABQAAAAABABQAAAAABABQAEACACgBIAMgIIABAAIAAABIgFAEIgGAGQgEADAAACQgBACAGgBQADgBAGgEIAIgGIAHgGQAIgFgFAFIgJAIQgGAFADgBIAGgCIANgIQAHgFADAAIADABIgGAFQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAQAAAAABAAIAKgEIAJgBIgDADQAAABAAAAQAAAAAAAAQAAABAAAAQAAAAAAAAIACABQAAABAAAAQAAABAAAAQAAAAABAAQAAAAABAAQAAAAAAAAQAAAAABABQAAAAAAAAQAAABAAABIgCAEIACgBIACgCIABADIgBADIABAAQABAAABAAQAAgBAAAAQABgBAAAAQAAgBAAAAIABgBIAAADgAk0A+IABABIAAAHIAFAAQAAgBAAAAQAAAAAAgBQAAAAAAgBQAAgBAAgBQgCgHgHgBQgDAAgCACQAAABgBAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABgBIABgBQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABIAAAGIACgBIABgFIAAgBIABABgAksA9QAAAGACADIABAAIAAgDIAAgBIABABIABACIACAAIAAgHQAAgBABAAQAAAAAAAAQABAAAAAAQAAAAAAAAIAAADQAAABAAAAQAAABAAAAQABAAAAAAQABAAAAAAIADgFQABgBAAAAQAAgBgBAAQAAgBAAgBQgBAAgBgBQgDgDgFAAQgFAAABAIgADtAxIgFADQAAACACAJQACAHADgCIAHgCQAAAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIgDgBQAAAAgBAAQAAAAgBAAQAAgBAAAAQgBAAAAgBIgDgJIABgBIACgBIAAgBIAAgBgAjHA5IgCAHQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAgBAAAAIADgGIAAgDIAAAAQgBAAAAAAQAAAAgBAAQAAAAAAABQAAAAgBABgAi/A9IgCACIABACQAAAAAAAAQABAAAAAAQAAAAAAgBQAAgBAAAAIAAgCIAAAAgAlSA0IgGAHQgBABAAAAQAAAAABABQAAAAABAAQABAAABAAIAIgBIAJgBIAFgBQAIgDAAgCQAAAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAAAIgCgDQABgBAAAAQAAAAgBgBQAAAAAAAAQAAgBgBAAIgDgCIgCgBIgDADIADAFIgEACIAAgFIgCAAIgBACIABAGIgDAAIAAgDIgDAAIgBADIgEACIACgFgAjOA0IgDAHQAAAAAAABQAAAAAAAAQAAAAAAAAQABAAAAAAIABgCQAAgBAFgEQAAgBAAAAQABgBAAAAQAAgBgBAAQAAgBgBAAIAAAAIgDADgAglAVQgBABAAAAQAAABAAABQAAAAAAABQABAAAAABIAFAGQABAAAAAFIAJAUIABADQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAAAIAJgFIACgFIAIgZQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAgBABQAAAAAAAAQgBAAAAgBQAAAAAAgBQAAgBAAgBQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAIgFABIgcAAgAAQA2IgCAEQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAgBABAAQAAAAAAAAQABAAAAAAIAFgBIACgBIADAAQABAAABAAQAAABAAAAQAAAAAAAAQAAAAgBAAIgEABIgBABIACAAIAFAAIABgCIABgBIABAAIgBACQABAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAAAIABgDIgCgBQAAABAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAIAAgBQAAgBABAAQAAAAAAAAQABgBAAAAQAAAAAAgBQAAgBgIAAQAAAAgBAAQAAAAAAAAQAAAAAAABQAAAAABAAIAFABQAAAAAAAAQAAAAAAAAQAAAAAAABQgBAAAAAAIgGABQAAgBAAgBQAAAAAAgBQgBAAAAgBQAAAAAAAAIgCAAIgBAAIgCgBQAAAAAAAAQgBAAAAABQAAAAAAAAQAAABAAAAIACACIgBABIgHAAIgCACIABAAIADAAgAjVAxIgDAFIABABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAIADgEQAAAAAAAAQABAAAAgBQAAAAAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQAAAAAAAAQgBAAgBAAQgBAAAAAAQgBAAAAABQAAAAAAAAgAEkAxIgEAGIAFgDIAGAAIABgDIADgDIACABQABAAABAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQgCgGgMgBQgFgBgEADIgFAEIAGAAIgBAGIABACIADgFgADuAmIAFAMIAAACIgCABIABABIACgBQAEgBgBgEQgCgHgDgEQgCgDgDACIgGACIgBABIACABIAEgCgAjIAyIAAAEQAEgIgCgBIAAAAQAAAAAAAAQAAABgBAAQAAABAAABQAAABgBABgAAEATIAAAgQAAABAAAAQAAABAAAAQAAAAABAAQAAAAAAAAIALgIIABgCIABgJQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAAAAAIAFAAIAAgNIgBgBIgRAAQgBAAAAAAQAAAAgBAAQAAAAAAABQAAAAAAAAgAjZArIgDAIIAAACIACgBIAEgIQABgBAAAAQAAAAAAgBQAAAAAAAAQAAgBgBAAIgDACgADLA0IACABIADgGIACgHIgDgBgAlcAlQAAABABAAQAAABAAABQAAAAAAABQgBAAAAABIgDADIgCAEQAAABAAAAQAAABAAAAQAAABAAAAQAAAAABAAQAEABAFgDIAEgCIAAgCIACgCQAAAAgBAAQAAgBAAAAQAAAAAAgBQAAAAAAAAIABgCIgEgDIABgEIgGAAQgBAAgBABQAAAAAAABQAAAAAAABQAAAAAAABgAAbATIgBANIAFABQAAAAABAAQAAAAAAAAQAAAAAAABQABAAAAAAIAAALIADAEIAFADQACAAAGgOIADgKIAAgJQAAAAAAAAQAAgBAAAAQgBAAAAAAQgBAAgBAAIgWAAgAlPAtQgBAAAAABQAAAAgBAAQAAAAAAABQAAAAAAABQgBAAAAABQABAAAAAAQAAABAAAAQABAAABAAQAAAAABAAQAAAAABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAAAIgBAAgAhkAaQgBAAAAAJQABACAJAHIADAFQAAAAABABQAAAAAAAAQABAAAAAAQABAAABAAIgBgIIABgFIgCgJIgDgDIgDgBIgBADQgBABgBABQAAAAgBAAQAAABAAAAQgBAAAAgBIgCgDIgBAAgADFAoIgEAIIAEACIAHgPIgDgDgAhDAvQAAAAAAAAQAAABAAAAQAAAAABABQAAAAABAAQACABAEgBQAGgCgDgHQAAAEgFACQgBAAAAABQgBAAAAAAQgBAAAAgBQgBAAAAAAIgBgDQAAAAgBAAQAAABAAAAQAAABAAAAQAAABAAABgAlnAxIAHgHIAAgBIgDgBIgQgBIACABIgBACIAIACIgBAAIABABIADAAgAiwAJIgDAFQgEACgBAFIgKASIAAAHQAAABAAAAQAAABAAAAQAAAAABAAQAAAAABAAIAEgHIALgIQAGgEgBgJIAAgJQACgGgDAAgABnAmIgGABQgBAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABIAAAFQABACAGgEQAIgDgBgGIgBgEIgBgBQAAAFgFACgAFMAnIgEADIgDAEIADABIAGgFQABAAAAgBQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAAAQAAgBAAAAQgBAAAAgBQAAAAAAAAQgBAAAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAIAAgDQAAAAAAgBQgBAAAAgBQgBAAAAAAQgBAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBAAAAAAIgGgBQABgBAAAAQAAgBgBgBQAAAAAAgBQAAAAgBAAIgGAAQgBgFgCAAIgFABQgDgGgEABQgDACAAAEIgBAIIgEAHIAGABIAEgIIABgEIADABIgGALIACABIAEgFIADgGIACABIgGAMIACABIAGgGIADgFIACAAQgCAFgBACIgDAGIACAAIAFgFIACgEIAEACIgDADIgGAGIACACIAGgFIADgDgAk9ApIAJAFIADABQAEAAAFgQQAEgHgFgDQgBgBgGAFIgGADIgCACIADgBIAHgCQAAAAAAAAQAAAAAAABQAAAAAAABQgBABAAABIgJABIgBADIAIAAQABAAAAAAQAAAAAAAAQAAABgBAAQAAABgBABIgJAAgAlJArQgBAAAAAAQgBABAAAAQAAAAgBAAQAAABAAAAQAAABAAAAQAAAAABAAQAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAAAAAIAAAAgADgAeQgEACAAAEQAAAIAFACQAIABgBgDQgGgBAAgFQAAgFAFAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAABAAAAQACgFgEAAIgCAAIgFABgAAVAkIAAAFIABADIADABQABABADgEIAAgGQAAAAAAAAQAAAAAAgBQgBAAAAAAQAAAAgBAAIgFAAgAhKAfQgHADgBACQgCAEABADIABACIAGgEQAIgEAAgBIgCgFIgBAAIgDAAgAlHAqQgBABAAAAQABABAAAAQAAABABAAQAAAAABAAQABgBAAAAQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAgBgBAAIgBAAQAAAAgBAAQAAAAAAABQAAAAAAAAQAAABAAAAgAjbAkIgFAFQAAABAAAAQAAAAAAABQAAAAAAAAQAAAAAAABIACAAIAFgFIADgDIgCAAIgDAAgAhBAlIABAHQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQABgBABAAQAAAAAAgBQABAAAAAAQAAgBAAAAIgFgIIgDgFQgBABACAIgAC5ArIACABIAFgGIADgKIgCgCgAkbAbIgGAIQgDAEAEADQAFADACgCIARgOIgLgDIgEAAQgCAAgCABgAlPAoQAAAAAAAAQgBABAAAAQAAAAABABQAAAAAAAAQAAABABAAQAAAAABAAQAAAAAAgBQABAAAAAAQABgBAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAIgBAAIgCABgAimAKIgEAIQAAACACAKQABACAAAKQAIgPAAgCQAAgCgCgIIgCgJIgCAAgAi/AUIgPAQQgGAGACAAIAIgCQACgBAIgJQAEgGAAgEIgBgBIgCABgAlDAkQAAAAAAAAQAAABAAAAQAAAAAAAAQAAABAAAAQAAABABAAQAAAAAAABQAAAAABAAQAAAAABAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAgBAAAAIgBgCIgCABgABwAcQgBABABAFQABAFACAAQAKAAAEgDQAAgBABAAQAAgBABAAQAAgBAAAAQAAgBABAAIgBgFQgBAAAAgBQAAAAgBAAQAAgBgBAAQAAAAgBAAIgBgBIABADQADAEgHACQgHABgCgCQAAgBAAgBQAAAAgBgBQAAAAAAgBQgBAAAAAAIAAAAgAlKAlQAAABAAAAQAAAAAAAAQABABAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAgBAAAAQABAAAAgBQAAAAgBgBQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAAAQAAABAAAAgAjkAjQAAABgBAAQAAAAAAABQAAAAAAAAQAAABABAAQABgBAAgBQABgBAAAAQAAgBAAAAQAAAAAAAAIAAAAIgCABgAlSAiQAAAAgBAAQAAAAAAAAQAAAAAAABQgBAAAAABQABAAAAABQAAAAAAAAQAAAAABABQAAAAAAAAQAAAAABAAQAAgBAAAAQAAAAAAAAQABgBAAAAQAAgBAAAAQAAgBgBAAQAAAAAAAAQAAAAAAAAIgBAAgAlPAjQAAAAAAAAQAAABAAAAQAAAAABABQAAAAAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAgBQABAAAAgBQAAAAAAAAQAAAAgBAAQAAAAgBAAIgCAAgAFkAdIgLACIAAADQAAABAAAAQAAABABAAQAAABAAAAQAAAAABAAIAJgFIAKgEgAk+AhQgBAAAAABQAAAAAAABQAAAAABAAQAAABABAAQAAAAAAAAQABAAAAAAQABgBAAAAQAAAAAAgBQABAAAAgBQAAAAAAgBQAAAAgBAAQAAgBgBAAIAAAAIgCACgABmAVQgFACAAAEIADAIIACAAIAAgDQgBgBAAgBQgBAAAAgBQAAAAABAAQAAgBABAAQACgCAJgCQADAAAAAFIACgBQgBgEgDgDQgBgCgFAAQgEAAgCACgAlHAgQAAABABABQAAAAABAAQAAABAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAAAQAAAAgBAAIgBAAIgBAAgAhwAhIADABIACgFIgEgCgAlLAeIAAADQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAABgBQAAAAAAAAQAAgBAAAAQAAAAAAAAQgBgBAAAAIgBAAIgBAAgADZAaIgDAFIADACIADgEIABAAIADgDIAIgHIgDgCIgMAEIgDgDIADgKIgEgBIgKACIgCgCIADgJIgFgDIgLAGIgCgBIgCgNIgEgBIgEAEIgGADIgCgBIAAgGIAAgFIgDgCIgGAHIgEACQgBAAAAAAQgBAAAAABQgBAAAAAAQAAgBAAAAIgJgLIAAATIADgHIACACIAAAHIACgFIACABIgBAEIACgCIAAgCIAEgBIAAADIAEgDIABADIgDACQgDACgCACQgBADAEABIABgEQABgCAGAAQAGAAgEAHIAAABQgBAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAFAAgBgEIAAgFIADABQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAIADAGQAJADAEAEIAMAIIAFgEIACACIgGADIACACIAEgDQAAgBABAAQAAAAABAAQAAAAAAAAQAAAAAAAAIgDAFIADABIACgDgAlDAeQAAABAAAAQAAABABAAQAAAAAAAAQABABAAAAQAAAAABAAQAAgBAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAQgBABAAAAQAAAAAAABQgBAAAAAAgAEXAOIADAOIAAADQAAAAAAAAQAAABAAAAQAAAAAAAAQABAAAAAAQAFAAACgCQABgCgCgFQgDgKgCgCIgFgDgAkcATIgGADIgDACIABAIIACgEQAEgEAEgCQACgBAQADIABAAQgFgEgDgBIgGgBIgHABgAjMAVIgNAEIgGADQgCAAgBAAQgBAAAAAAQgBAAAAABQABAAAAAAIAJADQAHABADgCQAFgBAEgFQAEgEABgCIAAgEgAlPAdQAAAAgBABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAgBQAAAAAAAAIgBgBIgBAAgACEAaQABAAAAABQAAABABAAQAAABAAAAQABAAAAAAIADABIAFgDIAGgEQAAgBABAAQAAgBAAgBQAAAAAAgBQgBgBAAAAIgCgDIgCgBIABADQABACgFADQgGADgCAAIgDgDIABAEgAlHAbQgBABAAAAQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQABAAAAgBQAAAAAAAAQABgBAAAAQAAgBAAAAQAAAAAAgBQAAAAgBAAIAAAAIgCABgAk+AZQgBABAAAAQAAAAAAABQAAAAAAAAQAAABABAAQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQABAAAAgBQAAAAAAAAQAAgBAAAAQAAAAgBgBIgBgBIgBABgAlPAQIgHAEQAAABgBAAQAAABgBAAQAAABAAAAQAAABAAABQAAAAAAABQAAABAAAAQABABAAAAQAAAAAAABQACABAFgDIgDgCIAEgBIADAEIADgBIAAgCIgDgCIAAgCIAFACQABABABgHQABgEgFgCIgBAAQgCAAgDAFgAiXAOIAHALQADAFACgBQAAAAAAgBQABAAAAgBQAAAAAAgBQAAgBAAgBIgBgFQgFgHgDgCIgHgEIADAIgAFIAPQAAADAGAHQADAEADAAQADAAAJgHIAIgEIgNABIADgJIACgLIgMASIgMgHgAl7ALQACADADACIAAABQAAAAAAABQAAAAAAAAQAAAAABAAQAAABABAAIgBACIACAAIADABIgDACIADABIAGABIgCACIADAAIAJgDIgFgEIgFgCIgCgCIgFgBQgCAAgDgDIgGgFgAhtATIADAHQABABABAAQAAAAAAgBQAAAAAAgBQAAgBAAgBIgBgGIgDgFQgBADAAAEgAiIAFIACAKQACAEAAAGIABABIACgBIAEgPQAAgCgEgBIgIgFgAB4AQQgDACADAEIACAEIACgBIgBgCIABgDIAGgDQABAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAIACADIAEgBIgEgFQgBgCgEAAQgFAAgEAEgAh1AYIAAABIACAAQAEgRgBAAIgHgEIgDgBgAkzARIAAACIgFAFIACABIAJgGQAEgCgDgEIgHgFQgEgCgGABQgFACgBAGIABAJIADgBIAAgFIACgCIAAAHIAAgBIABgDIABgEIAEgBIgEAJQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIAFgHgAhiAOIgDAHQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAQAAAAAAgBIACgGQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAgBAAAAgAhcAPIgBAFQAAAAAAABQABAAAAAAQAAAAABAAQAAAAAAAAIABgFQABgBAAgBQAAgBAAAAQAAgBAAAAQAAgBgBAAgAkTAPIAVAFQAIAAABgKQAAgMgMgDQgFgBgLADIgLADIgDACIgEAGQgCACgDAAIgDAAIADAFQABABAAAAQAAAAgBABQAAAAAAAAQAAAAgBABIAFACIADgDIANgCIABAAgACPADQgHADAAAGIADAGIACAAIgBgDQAAgBAAgBQAAAAAAgBQAAAAABgBQAAAAABgBIAGgDQAAAAABAAQAAAAABAAQAAAAAAABQABAAAAABIABgBIAAgBQgBgFgEAAIgEABgACVAMIAEAEQACACAEgBQAAAAABAAQAAAAABgBQAAAAABAAQAAgBAAAAQACgEABgFQAAAAAAgBQAAAAAAAAQgBgBAAAAQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAAAQgBAAAAABIgHAIIgEgCgAjbAQIAFABIAJgBQAFgBAEgIIgDgBQAAAAgBAAQAAAAgBAAQAAAAgBAAQAAAAAAABIgFACQgEAEgEAAIgGACIAAAAgABiAQIAEgBIAAgSIgFgDgAkBgKQAKABADAJQAEAJgCAFQAAABAAAAQAAABAAAAQABAAAAAAQAAgBABAAIADgEQAAgEgCgHQgDgIgEgDQgJgFgPABQgPACgDACQgBABgBAAQgBABAAAAQgBAAAAAAQAAAAAAgBIgCgKQgBgDgDgBIgCgBIACAFIADAMIgDABIgDgMQgCgIgLgCIgNADIAAAAIAHAAQAGABABACQADAEgBAIQgCAFAEAFQAEAEAFgBQAGgCAIgHIANgCIANgBIADAAgAAYAOIAAACIABAAIAAgDIgJAAIAAADIABAAIAAgCIACAAIAAACIADAAIAAgCgAlbAGQAAADACAEQAAAAAAABQABABAAAAQABAAAAABQABAAAAAAQADgBgCgGIgDgOgAgRggQgFADgJAJQgGAHgDAOIgBAOIAqAAIAAg0QgKABgIAEgAi6gJQgDAEAAAFIACAIQACAFgCACQAFgCABgDIABgDIgBgEQAAgEACgEIAEgLQgGACgFAFgAAbADQAAAAgBABQAAAAAAAAQAAAAgBABQAAAAAAABIgBACIABAAIAFAAQABABAAAGIADgCQADgBgCgGQgBgDgEAAIgDAAgAAHAAIgBAAQAAAAAAABQgBAAAAAAQAAABAAAAQAAABAAABQgBAJAEACQABAAAAAAQABAAAAAAQAAgBAAAAQAAAAgBAAIAAgDQAAgBAAAAQAAgBABAAQAAgBAAAAQABgBAAAAQACgBADACQACgBgEgGQgBAAAAgBQgBAAAAAAQgBAAAAAAQgBAAgBAAIgCAAgABrAOIAFAAIAEgMQAAgBAAAAQAAgBgBAAQAAAAgBAAQgBAAAAAAIgGgBgAibgIQABAGAFADIAHAJIADAEIAAgGIgEgJIgBgFIgEgDIgHgEgAB4ACIgDALIAHgDIADgHQAAAAAAgBQAAAAAAAAQAAgBgBAAQAAAAgBAAgAAuAJIAAACIACAAIAAgEIgJAAIAAAEIACAAIAAgCIABAAIAAACIADAAIAAgCgAAQAKIABABIAHAAQAAAAABAAQAAAAAAgBQAAAAAAAAQgBAAAAAAIgHAAIgBAAIAAAAgAhugDQACADAFAEQADADACABQABAAABAAQABAAAAAAQABAAAAAAQABAAAAAAQAAgCgDgDIgHgKIgDgEQgBgCgDAAIAAAAQgCAAACAKgAASgDIgCAEQABAHADAAQAEAAAAgHQgBgFgDgCQAAAAAAAAQgBABAAAAQAAAAAAABQgBAAAAABgACEADIgCAFIADAAIADgGgAhbACQAAABAAABQAAAAABAAQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQABAAAAgBQAAgBAAgBIABgBIgCgBIgCgBgAAnADIgBABIABABIAIAAQAAgBABAAQAAgBAAAAQAAAAAAgBQgBAAAAAAgAitgYQAFAGgCACQgGAKADAEQAEAFAHAAQAIACABgCQgDgCgBgCQgFgGABgEQACgGgCgEQgCgFgEgCIgFgBgAA0ADQAIgJgJgCQgGgBgBAFIAAAFIACAAIAAgBQABgBAAAAQAAgBAAAAQABAAAAAAQABAAABAAQADAAgBAFgADOgGIACAHQABABAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIALgXQABgBAAAAQAAgBgBAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQgBAAAAAAQAAAAAAAAQgBABAAAAIgGAOIgCgGIAHgRQAAgBAAAAQAAgBAAAAQAAgBgBAAQgBAAgBgBIgGALIgBgFIAFgMQABgBAAAAQAAgBgBAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAAAQgBAAAAABIgFAJIgCgFQAFgJAAgDQABgJgFgBIgJAAQgFAAgCgEQgEgFgBAAIgTABIgCABIgCgBQAAABAAAAQAAAAAAABQgBAAAAAAQgBABAAAAQgDABACgDQAAAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAABQAAAAgBAAIgEAEQgCABgFgBIgJgBIgDAAQgCAFgCABQgCABgHAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAABAAABQABAEADACQACABAFgBIAGAAIAEgDIACABIABACIAAAEQAAAAAAABQAAAAAAAAQAAAAABAAQAAAAABAAQABAAACgEIAAAFIgCADQAAABAAAAQAAAAAAAAQABABAAgBQABAAAAAAQADAAAAgGIAAgMIADgBIABAFIAAAGQACgBACgEQAAgBABAAQAAgBAAAAQAAgBAAAAQAAgBAAAAIADABIAAALQAAACAEADQAFADAEgBQAMAAADgFIAFgHIADABQgEAIgEADQgGAEgLAAQAAAAAAAAQAAABgBAAQAAAAAAAAQAAAAAAABIABABIAHABQAFgBAEgCIAMgMIgDAKQgHAGgFABIgMACIAAADIAOAAQADgBAIgFIAAAEIgKAGIgKACIAAACIARACIAAADIgEABIAAAIIAKgEgAjHgDIgHADQAAAAAAAAQAAAAAAAAQAAAAAAAAQABAAAAAAIAEABQACABAEgCQAEAAAAgDIABgDIgHgBQAAABAAAAQAAABAAAAQgBABAAAAQAAABgBAAgAAlgPQgBACACAFQABACACAHIABAAIABgEIACgGQACgDABgFIgEgEIgDgCgAAlABIACAAQgBgLgFABQgDAAgCACQAAABgBAAQAAABAAAAQAAABAAAAQAAABAAAAQACAEADAAIAAgBQAAgBAAAAQAAgBABAAQAAAAAAAAQABAAAAAAIABAAQAAAAABAAQAAAAAAABQABAAAAABQAAAAAAABgAiUgbIAJAOQAAADAFAHIAFAEIAAgMIgCgDIgDgCIgCgFQgKgGgCAAIAAAAgAk+gTQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABIgBALIADAFIACgBIgCgDQgBgFAAgCQADgKgEgCQgCgCgEAAIgLgBIgFgCIgBABIABACIAEACQAEABAJAAIABAAQAAAAABAAQAAAAABAAQAAABAAAAQABAAAAABgAh+gNQADAGAFAFQAFAEgCgHQgEgLgDgCIgLgDQABACAGAGgAAXgKIAAADIACAAIAAgEIgKAAIAAAEIACAAIAAgCIACAAIAAACIACAAIAAgDgAAHgbIgCADQgCADABADQABAHACABQAAAAAAAAQABAAAAAAQAAAAAAgBQAAAAAAgBIABgEQABAAAAgBQABAAAAAAQABAAAAAAQAAAAABAAIABACIACAAQAAgMgGAAIgDAAgAAggLQABAAACgHQADgKgGAAQgFABgCAGIgCAGIAHgBQACABAAAEgAisgmIAAAEIAIADIAFAFIAEAGQACAFACABQAEACADAAQADAAgFgGQgFgFgBgCQgCgKgGgDIgGgCgAAPgNIABABIAJAAQAAAAAAAAQABgBAAAAQAAAAgBAAQAAAAAAgBIgJAAIgBABgAjNgRQAAAAAAABQAAAAAAABQAAAAABABQAAAAABAAQACABAEgBQAFgBADgDIAIgJQAFgIAAgDQgBgEgEgHIgHgJQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAIAEABIAFAGIAFAHIABAEIACgBIAEgBQACgBADACIAOAJQAFACAAgBIgDgCIgIgKQgHgHgDgBIgGABIgBgDIAKAAIAPAKQAEACADgBIAAgBIgBgBIgEgDQgEgDgCgEQgHgOgIACQgEABgEADIgDACIgBgEIALgGQAGgEACgEIAAgGQgCgGgCADQgCAHgCAAIgIAEIgJAHIgDgDIANgIIACgDQACgGgCAAIgDADIgJADQgFACgBADIgCADIgBAAIAFgIQAAgKgBgCQAAgBAAAAQgBAAAAAAQAAAAAAAAQgBAAAAAAIgBACQABAGgBACIgHAJIgBAAIADgGQAAgKgCgBQgEgDAAABIABADQAAAAAAABQAAAAAAABQABABAAAAQAAABgBAAIgCALIgDAAQACgEAAgDQgBgEgEgCQgFgDAAACIAEAHQABAEgBADIgBACIgBAAQAAAAAAgBQAAAAgBgBQAAAAAAgBQgBgBAAAAIgGgDIABAEIABAFIgEAGIAAABIgGAGIgHANIAJgEQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAABIgBACIgCAFIgBAIIACgDIAFgDIAMgDIgDgBIgGgBIAAgBIAGgBQAIACAAABQAAAEgDABQgEABgBACQgFAFACAEIAEADQADABACgCQAMgHABgEQACgEgCgEQgBgBAAAAQAAgBAAAAQABAAAAAAQAAgBABAAQAAAAABAAQAAAAABAAQAAAAAAAAQABAAAAABIADAFQACAFAAACQgCAIgHAFQgJAFgBgBIgBAAQAAAAAAAAQgBAAAAABQAAAAAAABQAAAAAAABgAARgmQgCADAAADQgBACABAEIACAGIABAFIADAAIABgEIADgNQAAgCgBgDIgDgDIgEACgAiHgqQAAAAAAABQAAAAAAABQAAAAAAABQAAABAAABQABAFABABIALAFQADACACAEQAAABAAAAQABAAAAAAQAAgBAAAAQAAgBAAAAQAAgBAAgBQAAAAAAgBQAAAAAAgBQAAAAgBgBIgFgIIgEgDQgGgFgCAAIgBAAgAjkgfQgDAEAFAEQAHAFACgDQACgFgDgCQgBgBgBAAQAAgBgBAAQAAAAgBAAQAAAAgBAAIgFgBIAAAAgAB7gmIgBADIgDADIgIAEQgDACgBACQAAABAAAAQABABAAAAQAAAAABgBQAAAAABAAQADgCAHAAQAFAAACgDIADgGIACgFgAjGgfIAEAGIAAgJgAhTgiIACADIAHgCIACgDgABVgiIAGAAIADgCIgLAAgABQgoIAQACIACgDIgTgBgAhSgqIAKADIACgCIgNgEgABzgwQABACADADQAAABABABQAAAAAAAAQABAAABAAQAAgBABAAQACgCAHAAQABAAAAAAQABAAABgBQAAAAABAAQAAAAAAAAQAAgCgFgCQgBAAAAAAQgBAAAAAAQgBAAgBAAQAAAAgBAAIgGACIgEgEgAhVgxIARAGIACgCIgWgHgAiQg4QAFAGAIADQAGAEAHgBIAEgBQAAgBABAAQAAAAAAgBQAAAAgBAAQAAAAgBAAQgEAAgDgEIgEgEIgEgDIgTgFgABLhIIACAbIACgEIgCgbgABUgwIgBACIAHgCIAEgEgAhEgyIADABIACgSIgEgGgABUg0IAAACIAMgGIADgFgAg+g0IADgDIABgHIgDgDgABFhCIAAAIIACACIABgMgAiLhMIgPADQAAAAgBABQAAAAgBAAQAAAAAAABQAAAAAAAAQAAACALAAIAOADQAGAAAEgCQABgBABAAQABgBABAAQAAAAAAgBQAAAAgBAAIgJgCQgHgDgEAAIgBAAgAgdhOIgOAGQAAABAAAAQgBAAAAABQAAAAAAABQABABAAAAQACADAEgDIAPgHQAMgEANAAQAdgBAOAMQABAAAAAAQAAAAABAAQAAAAABgBQAAAAABAAQAAgBAAgBQAAAAAAgBQgBAAAAgBQAAAAgBgBQgRgKgcAAIgCAAQgPAAgPAGgADFhhIgCAFQAAAJgBACIgFAHQAAACADACQAFAEADgCQACgCACgFQABgCgBgEIgEgPIABgCIAAgCIAAgCgACYhLQAEABAFgBIAQgCIAJAAIgCgCIgDgCIgEgDQgHgCgEADQgIAFgCAAQgDABgEgCgAjhhLIgIgGQAAgBAAAAQgBgBAAAAQAAgBAAAAQAAgBAAgBQABgDADgBQAEgBAJACIAAgDQgFgDgEAAIgGABQgDABgCAGQgDAFAHAEIAIADgAiZhVIgBAFQAAABAAABQAAAAAAABQAAAAAAAAQAAABAAAAQACAAAIgDIAIgBQAFgBgEgCQgFgDgCAAQgKAAgBABgAgzhqQgFAGAAAHQABAJAQAIIACgBQgKgHgBgFQgEgJAMgFQAKgEAOAJIABgBIgHgIQgGgEgKAAQgHAAgGAFgAA2hkQAEAEgBAEQgDAGgJAHIACABQALgHACgDQAJgLgKgJQgGgFgKACQgHACgEADIgFAGIAAABIARgFIACAAQAFAAADAEgAjmhWQgBADACADQABAAAAABQABAAAAAAQABAAAAAAQABAAAAAAQAFgCgBgDIAAgCIACAAQgFgDgDAAQgBAAAAAAQgBABAAAAQgBAAAAABQAAAAAAABgAgehjQgHACgBAEQgCADABADQABADADACQAFACADgBIAMgFQgGgNgIAAIgBAAgAAhhiIgJALIAMAFQAEABADgCQAEgDgBgGQAAgFgFgCIgEAAQgBAAAAAAQgBAAAAAAQgBAAAAABQgBAAAAAAgAC0hXQAAAAAAAAQAAABAAAAQABAAAAABQAAAAAAAAQABAAAAABQABAAAAgBQAAAAAAAAQAAAAABgBIgBgDIgFgBQAAgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAAAIgDgBIgFgGQgCgBgEAAIgEgGIgHAAIgCgHQgBAAAAAAQAAAAgBAAQAAgBgBABQAAAAgBAAIgCAAIgCgEIgEgBIgCgDQAAgBgBAAQAAAAAAAAQgBAAAAAAQgBAAAAAAIgBABIgDgEIgCgBIgBAAIgCgDQAAAAAAAAQAAAAAAAAQAAAAgBAAQAAABAAAAIABAFQAAAAAAAAQABABAAAAQAAAAABAAQAAgBAAAAIABgBIADAEIACACIACgCIABAEQABABAAAAQAAABABAAQAAAAAAAAQABAAAAgBIAAgBIACACIADAFQAAABAAAAQABAAAAAAQAAAAABAAQAAAAAAgBIAAgCIACADIACAFQAAABAAAAQABAAAAABQABAAABAAQAAAAABAAIAAgDQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAABIAEAIQAAAAAAAAQAAAAABAAQAAAAAAAAQAAAAABAAIAAgBIAAgFIACACIAFAJQAAABABAAQAAAAAAAAQAAABABAAQAAAAAAAAIABAAIAAgFIADACQAAAAABABQAAAAAAABQAAAAAAABQAAAAAAABIAEABQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAAAAAIABgBIABABgAgThvQADACACAEIAIASIACAAQgCgNgEgHIgHgIIgEgDIgEAGIAAACIACAAIACgBgAAShpQgDAEgBAIIAAAGIABAAIAGgOQADgGAHgFIABACQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBIgCgHQgHAFgGAIgAgChbIABAEIALAAQADgIgKAAQgEAAgBAEgAiwhiQgDADgDAAIAAADIAAAEIAEgCQADgBACgEIACgCQAAAAABAAQAAAAAAAAQAAAAAAAAQAAAAAAABIAAADQAAAAAAAAQAAABAAAAQAAAAABAAQAAABAAAAIADgBIACgCQAAgBAAAAQAAAAAAgBQgBAAAAgBQgBgBAAAAQgEgEgCAAQgBAAgDAEgAC0hqIgBACIgCAFIACADQABABAAAAQAAAAAAABQAAAAABAAQAAAAAAAAIADABQABAAgBgJIgCgFgAjWhqQgFADADAFQACAEAGgCQAEgDgDgEQgDgEgCAAIgCABgAg/hjQAAABAAAAQAAAAAAAAQAAABABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAABgBQAAAAAAAAQAAgBAAAAQAAAAgBgBQAAAAAAAAQAAgBgBAAQAAAAgBAAQAAAAAAABQAAAAgBAAQAAABAAAAgAi6hhIADgDQAEgHgEgCQgDgBgFAIIgBAEIABABIADgDQAAAAABAAQAAABAAAAQAAAAABABQAAAAAAABgAAGhkIAAACIADAAIACgDQAAgBAAgBQAAgBAAAAQAAgBgBAAQgBAAgBAAIgKAAIAAABIAAADIABADIADAAIABgCQAAgBAAAAQAAAAAAAAQAAgBABAAQAAAAABAAIABACgABFhmQgBAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAABAAAAQAAAAABABQAAAAABAAQAAAAABAAQAAgBABAAQAAAAAAgBQAAAAAAgBQAAAAAAgBQAAAAAAAAQAAAAgBAAQAAAAAAAAIgBAAgAjFhtIABADIgCAEQAAAAAAABQAAAAABABQAAAAAAABQABAAAAAAIACgEIAEgGQAHgEACAAQAAAAABABQAAAAAAAAQABABAAAAQAAABAAAAIABAEIgCADIAFgCQAFABAAgCQAAgBAAAAQAAAAAAAAQgBAAAAgBQAAAAgBAAIgCAAIAAgCIgCgCQABgBABAAQAAgBAAAAQABgBAAAAQgBgBAAAAQAAgBgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAIgCABIgDgBQABgBAAgBQAAAAAAgBQAAAAAAgBQgBAAgBAAQAAAAAAAAQgBAAAAAAQAAABgBAAQAAABAAAAIAAACIgFACQAAgBgBgBQAAAAgBgBQAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAQAAABAAAAQAAABABAAIABACIgDADIgCAAIgBABgAg7htQgBAAAAAAQAAABAAAAQgBABABAAQAAAAAAABQAAAAABABQAAAAABAAQAAABABgBQAAAAABAAQAAAAABAAQAAgBAAAAQAAgBAAAAQAAgBgBAAIgCgCIgBABgAA+hsQABAAAAAAQABABAAAAQAAAAABAAQAAAAABgBQAAAAAAgBQAAAAAAgBQgBAAAAgBQgBAAgCAAQAAAAAAAAQAAABAAAAQAAAAAAABQAAAAAAABgAgChvIgBADIAPAAQAAgHgIAAQgEAAgCAEgAg0hyQgBAAAAAAQAAAAAAABQgBAAABABQAAAAAAABQAAAAABABQAAAAABAAQAAABABgBQAAAAABAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAgBQgBAAAAgBQAAAAgBAAQAAAAAAAAQgBAAAAAAIgBAAgAAlhzQAAAAAAAAQgBAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABQABAAAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAgBQABAAAAAAQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAIgBAAgAgih1QAAABAAAAQAAABAAAAQAAABAAAAQAAAAAAABQABAAAAAAQABAAAAAAQABAAAAgBQAAAAABgBQAAAAAAgBQAAAAgBgBQAAAAAAAAQgBAAAAAAIgCAAgAA2hyQABABAAAAQAAAAABAAQAAAAAAAAQABAAAAgBQADgCgGgBQAAABAAAAQAAAAAAABQAAAAAAAAQAAABAAAAgAgrh2QAAAAgBAAQAAABAAAAQgBAAAAAAQAAABAAAAQAAABAAAAQABABAAAAQAAABABAAQAAAAABAAQABAAAAgBQAAAAABAAQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAIgBAAgAAuh1QAAAAAAAAQgBAAAAAAQAAAAAAABQgBAAAAAAQABABAAAAQAAABAAAAQABAAAAABQABAAAAAAQAAAAABgBQAAAAAAAAQABgBAAAAQAAAAAAgBQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAAAgBAAIgBAAgAAJh4IgBABIAIAEIABgLgAADh6QgBAAgBAAQAAABgBAAQAAAAAAABQAAAAAAABQAAABAAAAQAAABAAAAQABAAABABQABAAABAAQABAAAAAAQABgBAAAAQABAAAAgBQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAgBgBAAQgBAAAAAAIgBAAgAgKh0IAIgDIAAgCIgHgGgAAHh8IAGgIIgSgBIAFAJIADgBgAgTBvIAEgCIAAgBIgCAAIgEACIgBgBIADgCQAAAAAAgBQAAAAAAgBQgBAAAAAAQAAAAAAAAIgFADIgCgCIARgJIACABIgDADQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAABAAAAIACAAIAEgCIADABIgEACIgBACIACAAIAFgCIACABIgQAJgAgMBpQAAABAAAAQABAAAAABQAAAAAAABQgBAAAAABQAAAAABAAQAAAAAAAAQABAAAAAAQAAAAAAAAQADgCgDgDQgDgDgDACQgBAAAAAAQAAAAgBABQAAAAAAAAQAAABAAAAIACAAIACAAIACAAgADyBjQgDgHAMAAQANAAADAGIADAHQACAGgLAAQgOAAgFgMgAD6BeQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIAEAJQADAEADAAIADgBIgBgDIgDgIQgCgDgEgBIgCABgAkfBsIgOgBQAFgBABgCIAFgKQABAAAAAAQgBgBAAAAQAAAAAAAAQgBAAAAAAIgBgBIACAAIAMABIAMACQAEACgEAHQgCAEgJABIgEAAIgGgBgAkeBqIAHABQAFgBAAgEQABgGAAgBIgHgBgADrBrIgEgGIgHgDIACAFIADABIABABIgQgCIAAgBQABAAABAAQAAAAABAAQAAAAAAgBQAAAAAAAAIgEgNIgDgDIgCgBIAaAFQADABACADQABABgFAEIAEACQABAFACABIAEABIAAACgADgBfIAGABQABAAAAgBQAAAAABAAQAAAAAAgBQAAgBAAAAQgCgDgCgBIgGAAgAj3BrQAEAAAAgCIAEgIQAAgBAAAAQAAAAAAgBQgBAAAAAAQAAgBgBAAIgBAAIAAgBIAYgDIgBAFQAAgBgBAAQAAgBAAAAQAAgBgBAAQAAAAgBAAIgHABIgBAFIAEAAIAEgEIgDAIIgCgCIgEAAIgDAGIALgDIADgDIABABIgBAEIgHACIgUABgAkKBsIABgBIAEgBQACgBABgDIACgGQAAAAAAAAQAAgBgBAAQAAAAAAAAQgBAAAAAAIgCgBIAAgBIAQgBIAAACIgDAAIgGAMIAEABIAAABgAggBnIASgIIACABIgSAJgAlpBdIgLgGIgFgPIAXANIAcAMIgPAFIgUgJgAjTBeQAAgBAAgBQAAgBAAAAQAAgBAAAAQgBAAAAAAIgEAAIAAgCIALgCIAGgCIAAACIgCACQgCABgBAJQAAABAAAAQAAABABAAQAAAAABAAQABAAABgBQAEgBAAgEIACgKIgDABIAAgBIAMgEIAAACIgEABIgBAFQACAKgMADIgGABQgHAAACgIgAglBkIAIgDIAKgGIACACIgSAIgADBBiIgJgCIAAgBQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAgBIgCgMIgFgEIABAAIAVAFQAFABADAGIABAHIgCACIgFABIAAAAIgLgCgADCBUIACAMIABABIAFABQAAAAABAAQAAAAAAAAQAAgBAAAAQABgBAAAAIgBgEQgDgGgCgBIgEgCgAgoBhIASgJIABABIgSAJgAi0BfQAEgBABgCQADgGAAgHQAAgBgBAAQAAAAAAAAQAAAAgBgBQAAAAAAAAIgCAAIAAAAIAYgJIgBAHIgCABQAAgBAAAAQAAgBAAAAQgBgBAAAAQAAAAgBAAIgGACIgBAFIADgBIACgCIgCAIIgBgDIgDAAIgCAIIAGgBQADgBAEgFIgBAGIgZAHgACwBXIADgEIAGAGIgEAFgAi7BZIAFgFIADAEIgEAGgACoBbIgMgQIABAJIACACIAAACIgLgEIAAgBQAAAAABAAQABAAAAAAQABAAAAgBQAAAAAAgBIgCgJIgEgEIAAgCIACABIALAEIAKAOIgBgIIgDgDIgBgBIANAEIAAABIgEAAIADAPgAA0BSIABgBIACABQAFgCAAgCIABgBIgFgEIgCADIAAACIgBAAIgEgDIABgBIACAAIACgCIgDgEIgFAEIAAADIAAAAIgDgDIAJgKIAAABIAAADIAKAIQABAAAAAAQAAAAABAAQAAAAABAAQAAAAABAAIAAAAIgKALgAEdBSIACgCIABACIgCABgACKBSQgFAAgEgGQgEgFAAgCQAAgHALABQAHADACAEQADAGAAACQAAAEgIAAIgCAAgACFBEIABAHQABAEADABQAAAAABAAQAAAAABAAQAAAAAAgBQABAAAAgBIgCgIQAAgEgEgBIAAAAQAAAAgBAAQAAAAAAABQAAAAAAABQgBAAAAABgAEhBPIACgBIABACIgBABgABbBPQACAAABAAQABgBAAAAQABAAAAgBQAAAAAAgBIgEgLIgCgBIgBAAIAAgBIALgDIAJAIIAEgJIALABIAAABIgDACIACAKQAAACADABIABACIgIgBIgFAAIgBgCQAAAAABAAQAAAAAAAAQABAAAAgBQAAgBAAAAIgBgKIgFANIgDAAIgKgKIACAJQABAAAAAAQAAABABAAQAAAAABAAQAAAAABAAIABABIgLAEgAA+BFIABgBIADABIADgCQAAAAABgBQAAAAAAgBQAAAAAAgBQAAAAAAgBQgCgCgEADQgFABgCgBQgBgBAAAAQgBAAAAgBQAAAAAAAAQgBgBAAAAIABgDIAEgCIgBgCIABAAIAHADIgBACIgDgBQgBgBgDADQgBAAAAAAQAAAAAAABQAAAAAAAAQAAAAABABIACAAIAGgCQACgCADADQACABAAAEQAAABgFAEIABABIgBABgAhFBCIAVgJIABACIgSAHIgCAAIgCAAgAhKA7IAYgIIABADIgWAHgABLA8IgBgDIgOgHIAAgBIAPgFIgKgDIgCACIgBgBIACgDIAAgBIABABIACABIANAEQAAAAAAAAQABgBAAAAQAAAAAAAAQAAgBAAAAIABAAIgBADIgRAGIAKAEIACAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABgBAAAAIAAAAIgCAGgAgYAxIgFgNIABgCIAIATIABADIgBABgAgcAgIAAgCIgBgBQAAAAABAAIAKAAIALgDIADgBIgBADIgBgBIgCAAIABAEIgBADIgCgFIgCABIACAIIgBADIgDgKIgDAAIAFANIAAACIgHgPIgCAAIAHASIAAACIgJgUIgDAAIAKAWIgBABgAAkAoIAAgKIgBgCIgEAAIgDgBQAAAAAAAAQAAAAAAgBQABAAAAAAQAAAAABAAQABAAABAAQABAAAAAAQABAAAAAAQAAgBAAAAIgCgBQgBAAAAAAQAAAAAAAAQAAgBABAAQAAAAABAAIADABIACAAQAAAAAAAAQAAAAAAAAQAAAAAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIAHAAIABgBIABABIABACIgCADIgCAEIAAAGIABgBIACgGIADgFQAAAAABgBQAAAAAAAAQABAAAAAAQAAAAAAAAIgDAGIgCAHIgDAEIgCACIgBADQgBAAAAgBQgBAAAAgBQAAAAAAgBQgBAAAAgBgAAKArIAAgEIAAgDIACgBIgDgEIABgJIAEAAQABAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABIgBAFIAAACQABAAAAAAQABAAAAAAQABAAAAgBQAAAAgBAAIAAgFQAAAAABgBQAAAAAAAAQAAgBABAAQAAAAAAABQABAAAAAAQAAAAAAAAQAAABgBAAQAAAAgBABIAAAFIgCACIgBAFQAAABAAAAQAAABAAABQAAAAAAABQgBAAAAABIgDACIgBgBgABOAnIAAgCIACAAIABgDIABgCIgGgBIAAADIABABIAAABIgFgBIAAgBIACgBIABgCIgHgBIgBAEIACACIAAABIgFgCIADgHIAAgEIABAAIABADIAMACIACgCIABAAIgCAMgABLAZQgBAAAAAAQgBAAAAgBQAAAAAAgBQgBAAAAgBIAAgEIgDAAIgBACIgBAAIAAgGIABAAIABABIAMAAIABgBIACAAIAAAHQAAAEgEABgABMAWQAAAAAAAAQAAAAAAAAQAAABABAAQAAAAABAAIADAAQABgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAAAIAAgDIgHAAgAghAYIgBgBIAdgBIAAABIgRACgAg5ARIgBgCIgMAAIgBACIgCAAIABgHIABAAIABADIAEAAIAAgJIgEAAIgBACIgBAAIAAgDIABgDIABAAIABABIAMABIABgBIABAAIgBADIAAADIgBABIAAgCQAAAAAAAAQAAgBAAAAQgBAAAAAAQAAAAAAAAIgFgBIgBAIIAGABQAAAAAAAAQAAgBAAAAQABAAAAgBQAAAAAAgBIABAAIAAAEIAAADgAglAMIAEgDIgEABIAAAAQAAgBAAAAQABAAAAAAQAAAAAAgBQAAAAgBAAQAAAAAAAAQAAgBAAAAQAAAAAAgBQAAAAAAgBIABgBIAFAAIADABIAFAAQAAgBAAAAQABAAgBAAQAAAAAAAAQgBAAgBAAIgEgCIACABIAGAAIABACIAAAEIAAACIgJABIACgCIACgBQABAAgBAAIgEABQgBAAAAAAQAAABgBAAQAAAAgBABQAAAAgBAAgABRAJIgGgFIgHABIgBABIAAACIgBgBIAAgDIgBgDIABAAIACABIAGgBIACgBIADgFIABgCIABAAIAAAAIABAGIgBAAIgCgBIgDAFIAEADQABAAAAABQAAAAABAAQAAAAAAAAQAAgBAAAAIAAgBIABAAIAAADIgBADIgBABQABgBAAAAQAAgBAAAAQAAAAgBAAQAAgBAAAAgAgOALIADgBIAAgBQgBAAABAAIAGgBQAAgBABAAQAAgBAAAAQAAAAAAAAQAAgBAAAAQgEgCgBgBQAAgCAAAAQgBAAAAgBQAAAAgBAAQAAgBAAABIAAAEIACADQAAAAAAAAQAAAAAAAAQAAABAAAAQAAAAgBAAQgHACADgDQAAAAAAAAQABAAAAgBQAAAAAAAAQABAAAAgBIgBgEQgBgBAAgBQAAAAAAgBQAAgBAAAAQAAAAABAAQAAgBAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAABABQAAAAAAAAQABAAAAAAQAAgBAAAAQAAgDgDgDQAAAAgBAAQAAAAAAAAQAAAAAAAAQAAAAAAABIABACQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAAAAAQgBAAgBAAQAAgBAAAAQgBAAAAgBQAAgBAAAAIAAgPIAAgCIAAgCIACAAIAAACIgBACIACABIABABIABgCQAAAAAAAAQAAgBgBAAQAAAAAAAAQAAAAAAgBIgBgCQAAAAABgBQAAAAAAgBQAAAAAAAAQAAAAAAAAIABgBIABACIADAAIABgCIABgBIABACIgCAFQgBABAAAGIAAAGIACAFIgBgQIACgCQAAAAAAAAQAAAAAAAAQAAABAAAAQAAABAAAAIAAAEIAAAOIgCACIACAEIAAAFQAAABAAAAQAAABAAABQAAAAAAABQgBAAAAAAQgDACgEAAgAgNgQQAAAAAAAAQAAABAAAAQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAgBQAAAAAAAAQAAgBAAAAIgBgDIAAAAgADgAJIABgFIADADIAIAEQgJAAgDgCgABHAKQAAgBABAAQAAAAAAAAQAAgBAAAAQAAAAAAAAQABAAAAAAQAAAAABAAQAAAAAAABQAAAAABAAQAAAAAAABQAAAAgBAAQAAAAAAAAQAAABgBAAQAAAAgBAAQAAAAAAgBQAAAAAAAAQgBAAAAAAgADyAIIgIgCIgIgEIACgEIABgHIAIAAIAKACQABAAABABQAAAAABAAQAAAAABAAQAAAAAAAAQAFgCAEAAIAPgCIAAAEIgHAAIgIAAIgMAFIgIgCIgJABIgDABIADABIAGADQADADADAAIAFAAIAHgEIAEgCIAGAAIABAEQgIAAgBABIgKAEIgBAAIgEgBgAgdABIAAAAIAAABIAAgBgABFgBQAAAAAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAABQAAAAAAAAQAAABAAAAQAAAAgBAAQAAAAgBAAQAAAAAAAAQAAAAgBAAQAAAAAAAAQAAgBAAAAgAggAAQAAAAABgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAAAgBAAQAAgBAAABQgBAAAAAAQAAAAAAAAIgCABIAAgBIABgBIgBgDIABgBIACgCIAEACIAFABQAAAAAAAAQAAAAABgBQAAAAAAAAQAAAAAAAAIgGgCIAAAAIABAAIAEABQABAAAAAAQABAAAAAAQABAAAAAAQAAAAAAABIgBACIAAAEIgFAAIgCABIAFgCQAAAAAAgBQAAAAgBAAQAAAAgBAAQAAAAgBABIgDABIgDABgAhBgBQgHgCACgGQABgDAEAAIAFgBQAJADgCAFQgBAFgGAAIgFgBgAhDgJQgCAFAEABQAEABAFgBQAAAAAAAAQAAAAABgBQAAAAAAgBQAAAAAAgBQAAgBAAAAQAAAAgBgBQAAAAgBAAQAAgBgBAAIgGgBIgBAAQgBAAAAAAQAAAAgBAAQAAAAAAABQAAAAAAAAgAA9gNIABgBIACACIAMgEQAAAAAAgBQAAAAAAAAQAAgBAAAAQAAAAAAgBIACAAIABAFIgBAAIgBAAIgMAEQAAAAAAAAQgBAAAAABQAAAAAAAAQAAAAAAABIABACIAEABIAAABIgFABgAD/gMIgFgCIgKgCIgKgFIgBgHQAEgCAHAAIAHABQAGABABgBIAFgEIAFgEIAEgCIAJAAIAAADIgKABIgKAKQgCACgGgBIgPgBIgBACIABABIAHADIAMACIAHgFQAFgDADAAIAJABQABAAAAAAQAAAAAAABQAAAAAAABQAAAAAAABIgFgBIgIABQgDAAgBADIgFAEIAEgBIAIAAIAHACIAAACgAg1gLIgBgCIgLgEIgCAAIACgDIAQgCIgKgEIgEABIgBAAIAEgGIABAAIAAABIAAABIAMAGIAAACIgPACIAJADIACgBIABAAIgDAGgAgdgOQAAAAAAgBQgBAAAAAAQAAAAABAAQAAAAAAAAIACgBIAAgBIAAgCIACgBQABAAAAAAQABAAAAABQAAAAAAAAQAAAAABABIADAAIgBgCQAAAAgBAAQAAgBAAAAQgBAAAAgBQAAAAAAgBIADgCIABABIgCABQAAAAAAAAQAAAAAAAAQgBAAAAAAQAAAAABABQAAAAAAABQAAAAAAAAQAAABABAAQAAAAAAAAQABABAAAAQAAABAAAAQAAAAAAABQAAAAgBAAQAAAAAAAAQgBAAAAAAQAAAAAAABQABAAAAAAQAAABABAAQAAAAAAAAQAAABAAAAQAAAAgBAAIgCAAIAAgCIgGABIgBABIgBAAgAA6gUIABgBIABACIABgBIAAgCIgBgEIAAAAIgCAAIgBABIAAACIAAAAIgEgEIABgBIADABIAQgDIAAABIgMAMIAAACIgBAAgAA9gaIACAEIAGgGgAgugZIAAgBIgBgBIgJgGIgCAAIgBAAIADgGIACABIgBAAIAAACIAIAGIACAAIACgCIABABIgEAGgAi2gmQAAgEgHgKIgDgFIAAgBIALAOQAEAFgFAKQgBAAAAAAQAAABgBAAQAAAAgBAAQgBABgBAAQAFgEAAgHgAAyghIABgBIABABIABAAIAIgHIgPAEIAFgQIgBAAIgGALIAAABIgBABIgDgEIAAAAIABAAIACAAIAGgKIAAgCIgBgBIABgBIAEAEIgDANIAOgDIACAEIAAAAIgCgBIgKAJIAAABIgCABgAgsgnIAAAAIAFABQAAAAABAAQAAgBABAAQAAAAAAAAQAAAAAAgBQABAAAAAAQAAgBAAAAQAAAAAAAAQAAgBgBAAQgBgBgGAAQgGAAAAgDQgBgDAEgCIAEgBIAAgBIAAgBIAFAFIgBABIgFgCIgDACQgBAAAAAAQAAABgBAAQAAAAAAABQABAAAAAAIALABQAAAAABAAQAAAAABAAQAAABAAAAQABABAAAAQAAABAAAAQABAAAAABQAAAAAAABQAAABgBAAQAAABAAAAQAAAAAAABQAAAAAAAAQgBAAAAAAIgDACIgBACgAD4giIgMgGQgFgDgCAAIgEAAIgBgEIAIgBQALAAAEgDIALgJIAMgBIABAFIgKAAQgGAIgDAAIgNADQgBAAgBAAQAAAAAAAAQAAAAAAABQAAAAABAAIAIADIADACQAAAAABAAQABABAAAAQABAAAAAAQABAAAAAAQAFAAACgEIACgDIAMABIAAADIgIAAIgJAGQgCABgDAAIgEAAgAjKgjQgBAAAAgBQAAAAAAAAQAAAAABgBQAAAAAAAAQABAAABAAQAAABAAAAQABAAgBAAQAAABAAAAIgCABIAAgBgAgxgkIgBgDIADAAIABAEgAjNgmQAAgBAAAAQAAAAAAAAQAAgBAAAAQAAAAAAgBIABgBIAAAEIgBAAgAjIgoQAAAAAAgBQgBAAAAAAQAAgBABAAQAAAAAAgBQAAAAAAAAQABgBAAAAQAAAAABABQAAAAAAAAQABAAAAABQABAAAAAAQAAABAAAAQgBAAAAABIgCABIgBgBgAgjgxQgCgDAAgEQABgDACgCQAHgEAEAHQACAEAAAEQgBAEgCACIgDABQgEAAgEgGgAggg6QgFADAFAFQAEAGADgDQADgCgDgFQgDgFgCAAIgCABgAAggvIABgBIABABQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAAAgBIAGgKIAAgCIgBgBIAAgBIAGADIgBABIgBAAIgCAAIgFAKIAAACIABABIgBABgAjJguIABABIgBABQgBAAAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAgAClguQgDgBgBgDIAAgDIAGADQABABAHAAQADgBAEgEIACAAIABABQgBAEgEACQgDACgEAAIgIgBgAjHgvQAAAAABAAQAAgBAAAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQABAAAAABQAAAAgBAAIgCACQAAAAAAAAQAAAAgBgBQAAAAAAAAQAAAAAAgBgAgSgxIABgCIgEgMIgCAAIAAgCIADgBIABABIgBABIAGANIACAAIAAABIgFACgAAYgxQgFgDACgEIADgKIgCgBIAAgCIAFACIgBABIAAABIgDAKIABADIADAAIADgCIADgHIAAgCIgBgBIAAgBIADACIADABIgBABIgCAAIgFALIgDABIgBAAIgCAAgAAqgxQgBgBAAAAQAAAAAAAAQAAgBAAAAQAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAQABAAAAABQAAAAAAAAQABAAAAABQAAAAgBAAQAAAAAAABIgBAAIgBAAgAANg0IgBgBIgDABQgEAAgBgFIABgKQABgEAFAAIAEABQACACgBADIAAAIIgCADIADADIAEABIgEABQgBAAgDgDgAAHhCQgBAEABAFQAAAFAEgCIgBgBQAAgBAAAAQAAAAAAgBQAAAAABAAQAAAAAAAAQAAAAAAAAQABAAAAAAQAAAAAAAAQAAAAABABIABgHQAAgFgEgBQAAAAgBAAQgBABAAAAQgBAAAAABQAAAAAAABgAjIg0QAAAAABAAQAAgBAAAAQAAAAABAAQAAAAAAAAQABAAAAAAQABAAAAAAQAAAAAAAAQAAABAAAAQAAABAAAAQAAAAAAAAQgBABAAAAQAAAAgBAAQAAAAAAAAQgBAAAAgBQAAAAAAAAQAAAAgBgBgAjRg0IgIgBIAAgMIAJgCIABACIgGACIgBAHIAGABIAHADIgBACgAgJg0IABgBIAAgCIgCgLIgBAAIgCAAIgBADIgCABIgBgFIAIgCIAIgBIABAEIgBAAIgBgCIgDAAIgCACIADALQAAABAAAAQAAAAAAAAQABABAAAAQAAAAABAAIAAABIgHABgAjNg4IgGgCIAAgCIAJgEIAHgEIADADIgEAEIgDAFIgDAAIgDAAgAC6g5IgEgCQgEADgEgBQgGgBgBgEQAAgBAAgBQAAAAAAgBQAAAAgBAAQAAAAAAAAIgFACIgCgBQAAgBAAgBQAAAAAAgBQABAAAAAAQAAAAAAAAIAEgBIACgBIACgBIAEABIAJAAIABADQAAABABABQAAAAAAABQABAAAAABQAAAAABAAQAHAEAEgBQABAAABAAQAAAAAAAAQAAAAABAAQAAAAgBABIgBABIgHABgACsg+QABAAAAABQABAAAAAAQABAAAAAAQABAAABAAQAAAAABAAQAAgBABAAQAAgBAAgBQAAAAgBgBIgCgCIAAADIgBABIgBAAIgDgDQAAABAAAAQAAABAAAAQABABAAAAQAAAAAAABgAgBg6QAAgBAAAAQAAgBAAAAQABAAAAAAQAAAAAAAAQAAAAAAAAQAAAAABAAQAAAAAAABQAAAAAAAAQAAAAAAABQAAAAAAAAQAAAAAAAAQAAAAgBAAIgBAAgADrg7IAAgCIAOACIAKgGIAIAAIAAACQgHgBgCABIgIAFgADZhAIALgKQAEgBADABQAHABAAgEQABgIABgBIAHgDIABABIgDABQgEACgBACQAAAJgCABIgFABIgGABIgIAGIALgDIAKAAIADgEQACgEABAAIAIgCQACABACADIgGgBQgBAAAAAAQgBAAAAABQAAAAgBAAQAAABgBAAQgCACgBADQAAAEgDAAIgQAAIgLAEgACCg+IABgEIACgBIAEABQAAAAABAAQAAAAAAABQABAAAAAAQAAABAAAAIgEACIgDABQAAAAgBAAQAAAAAAAAQgBgBAAAAQAAAAAAAAg");
	this.shape_24.setTransform(-21.6211,-17.0473,0.5226,0.5226);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AgwBnIAAgDIAZgPIAAiqIgZgOIAAgDIBhAAIgBADIgYAOIAACqIAYAPIABADg");
	this.shape_25.setTransform(10.6652,-16.4887,0.5226,0.5226);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAVBnIAAgDIAagPIAAhRIhcgBIAABSIAYAPIABADIhiAAIAAgDIAZgPIAAiqIgZgOIAAgDIBiAAIgBADIgYAOIAABOIBcgBIAAhNIgagOIAAgDIBiAAIAAADIgZAOIAACqIAZAPIAAADg");
	this.shape_26.setTransform(-59.5912,-16.4887,0.5226,0.5226);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("Ag1BnIAAgDIAfgPIAAixQgJAAgJACQgJADgFAFIgnAoIgDgBIAEg7IC3AAIAGA7IgDABIgngoQgGgFgJgDIgPgCIAACxIAfAPIAAADg");
	this.shape_27.setTransform(2.6687,-16.4887,0.5226,0.5226);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#FFFFFF").s().p("Ag0BnIAAgDIAegPIAAixIAAAAQgJAAgIACQgJADgGAFIgnAoIgDgBIAFg7IC2AAIAGA7IgDABIgngoQgGgFgJgDIgPgCIAAAAIAACxIAfAPIAAADg");
	this.shape_28.setTransform(-71.2854,-16.4887,0.5226,0.5226);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1},{t:this.shape}]}).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.logo_2, new cjs.Rectangle(-118.6,-24.2,254.2,44), null);


(lib.CTA = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// FlashAICB
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#4DAAA2").s().p("EgrVBRJQighBh+iRQi0jLgDkNQgGlfEVjyMBF9g9OMgqGgk2I7F3sQhrhdhChYQhPhqglh1QhDjVA6jHQA0izBvh+QBxh/CshFQENhsEbBtQCBAyB2BnMAsDAmkIKtJbQDfDDG/GEIEwEOQC4CjB7BoQBoBYBEBKQBVBdA1BiQBkC1AUDfQAeFUi4ErQg7BfhoBkQgVAVioCTMghQAdGMgoYAjXQjRC3juAVQgnAEgmAAQiSAAiAg1g");
	this.shape.setTransform(113.1695,10.0389,0.0138,0.0138);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(1));

	// Layer_1
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#1D1D1B").s().p("AgQAfQgIgEgFgJQgEgIAAgKQAAgJAEgIQAFgIAIgEQAIgFAJAAQAQAAAJAJQAIAKAAAQIAAAFIgyAAQACAHAFAEQAFAEAHABQAFgBAFgCQAFgCADgDIAJAKQgFAFgHADQgIADgJAAQgJAAgIgEgAATgEQgBgIgEgFQgFgEgIAAQgGAAgFAEQgFAFgBAIIAjAAIAAAAg");
	this.shape_1.setTransform(99.025,10.5);

	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1D1D1B").s().p("AgTAjIAAhEIAQAAIAAANQADgHAGgDQAGgEAIAAIAAAQQgKAAgHAFQgFAGgBAJIAAAhg");
	this.shape_2.setTransform(93.05,10.475);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#1D1D1B").s().p("AgSAfQgIgEgFgJQgEgIgBgKQABgJAEgJQAFgHAIgEQAJgFAJAAQALAAAIAFQAIAEAFAHQAEAJAAAJQAAAKgEAIQgFAJgIAEQgIAEgLAAQgJAAgJgEgAgNgOQgFAGAAAIQAAAJAFAHQAFAFAIAAQAJAAAFgFQAGgHgBgJQABgIgGgGQgFgFgJAAQgIAAgFAFg");
	this.shape_3.setTransform(86,10.5);

	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1D1D1B").s().p("AApAjIAAglQAAgIgEgEQgEgEgHAAQgIAAgFAGQgFAFAAAIIAAAiIgQAAIAAglQAAgIgEgEQgEgEgGAAQgJAAgEAGQgFAFAAAIIAAAiIgRAAIAAhEIARAAIAAANQAHgOARAAQAJAAAGAFQAFAEADAIQAGgRAUAAQALAAAHAHQAHAHAAANIAAAqg");
	this.shape_4.setTransform(75.425,10.475);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#1D1D1B").s().p("AgHAmQgGgFAAgLIAAghIgKAAIAAgMIAKAAIAAgTIAQAAIAAATIATAAIAAAMIgTAAIAAAeQAAAFABACQACACAEAAQAEAAAGgDIAEANQgJAFgJAAQgIAAgFgFg");
	this.shape_5.setTransform(62.875,9.75);

	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D1D1B").s().p("AgZAcQgHgHAAgNIAAgqIARAAIAAAmQAAAHAEAEQAEAEAHAAQAHAAAFgGQAEgFAAgIIAAgiIARAAIAABEIgRAAIAAgNQgHAOgQAAQgLAAgHgHg");
	this.shape_6.setTransform(55.8,10.525);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1B").s().p("AgSAfQgIgEgFgJQgFgIAAgKQAAgJAFgJQAFgHAIgEQAJgFAJAAQALAAAIAFQAIAEAFAHQAFAJAAAJQAAAKgFAIQgFAJgIAEQgIAEgLAAQgJAAgJgEgAgNgOQgGAGAAAIQAAAJAGAHQAFAFAIAAQAJAAAFgFQAGgHAAgJQAAgIgGgGQgFgFgJAAQgIAAgFAFg");
	this.shape_7.setTransform(47.7,10.5);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1B").s().p("AgTAsQgIgFgFgIQgDgIAAgKQAAgLADgHQAFgIAHgEQAIgEAJAAQAHAAAGADQAGADADAGIAAgmIASAAIAABeIgSAAIAAgLQgDAGgGADQgFADgIAAQgJAAgHgEgAgNgBQgGAFABAJQgBAJAGAGQAGAGAHAAQAIAAAGgGQAFgGAAgJQAAgJgFgFQgGgGgIAAQgHAAgGAGg");
	this.shape_8.setTransform(35.85,9.225);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1B").s().p("AARAjIAAglQgBgIgEgEQgEgEgGAAQgIAAgFAGQgFAFAAAIIAAAiIgRAAIAAhEIARAAIAAANQAIgOAQAAQAMAAAHAHQAGAHAAANIAAAqg");
	this.shape_9.setTransform(27.65,10.475);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1B").s().p("AgHAxIAAhEIAPAAIAABEgAgGgfQgDgDAAgEQAAgFADgCQADgDADAAQAEAAADADQADACAAAFQAAAEgDADQgDADgEAAQgDAAgDgDg");
	this.shape_10.setTransform(21.425,9.025);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1B").s().p("AgeAtIAAhZIA9AAIAAAPIgsAAIAAAYIAoAAIAAAPIgoAAIAAAjg");
	this.shape_11.setTransform(16.275,9.45);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6},{t:this.shape_5},{t:this.shape_4},{t:this.shape_3},{t:this.shape_2},{t:this.shape_1}]}).wait(1));

	// Layer_2
	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#FFFFFF").s().p("An4CWQg+AAgsgsQgsgsAAg+QAAg9AsgsQAsgsA+AAIPxAAQA+AAAsAsQAsAsAAA9QAAA+gsAsQgsAsg+AAg");
	this.shape_12.setTransform(66,10);

	this.timeline.addTween(cjs.Tween.get(this.shape_12).wait(1));

	this._renderFirstFrame();

}).prototype = getMCSymbolPrototype(lib.CTA, new cjs.Rectangle(0.5,-5,131,30), null);


(lib.angelman = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// wings3
	this.shape = new cjs.Shape();
	this.shape.graphics.f("#1D1D1C").s().p("AGlOKQgGgZAFgMQAWgrgNgTQgLgQgvgKQkMg3jig4QhCgRhEgvQgNgJgIgbQgJgbAHgJQAYgdgOgKQgXgHgMgGQj7h5h7hBQgMgGgIgVQgHgTABgRQABgIATgJQATgJAPAAQApgBA4ADIBhAEIAoADQgTgSgKgHQhxhXg+hEQhUhdgkhrQglhsAng3QAng2BwADQAFAAAJgNQAIgMgCgFQg5iVApiHQAoiICChcQA0glAkAOQAfALAlA7QBbCTA8BWQBXB+BSBcQBPBYBzBiQBAA2CSByQAqAiBQAoQBjA0AcARQARALANAWQAMAVADAVQACAOgLAWIgUAlIgPggQgKgTgJgKIgpgrQgZgXgXgJQiGg0iDhjQhihLiCiBQiqirhBhMQh8iRhAiMQgghHgPgCQgRgDgvA/Qg9BSgSAeQgpBCgJA2QgGAlAiA9IA6BnIAYAtIgZAOQgOAJgKABQhIAHg1gHQgvgFgQAXQgOAUAOAoQAmBvBTBjQBDBPBuBWQAYATAvAVQA8AbAPAJQAKAFALAOIASAYIgaASQgQAKgNACQgOAEgWgBIgmgCIgBAGIjagYQgGgBgJADIgQAFIAKALQAGAGAFACIGMCQQAHACASADQAQACAIAEQAMAHAQAMIAbAWIgeAXQgSANgNAHQgPAHgXAHIgnAMIAnAVQAYAMARAEIEgBCQC0AoBsAaQAbAGAXANQAcAPAEAPQAEAPgQAbIgdAvQgJAPgQAPIgzAuIgMgqg");
	this.shape.setTransform(35.2413,-31.6559,0.1115,0.1115);

	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#FFFFFF").s().p("AIbNEQgBAAAAAAQgBAAAAgBQAAAAAAAAQAAgBAAAAQgNghk7hHQkjhCgyAAQgZAAgUgjIgPgjIB4g8Qi1gLifhPQhog1hWhNIGQAAQjeiPisi3QhZhegbg2QgUgnAKgaQAQgsBOgTQBLgSBvALQhJg4gbhUQgYhGAOhGQAUg3AfgvQAvhHBEgtQAmgaAugQQAtC5BpCHQArA4BIA4QBoBRBQBNQBQBNBGBVQAoAwAyAeQAKAFCDA6QBUAlA3A7QAjAlAZArQihJagbAAIAAAAg");
	this.shape_1.setTransform(35.1599,-32.2101,0.1117,0.1117);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_1},{t:this.shape}]},11).wait(11));

	// FlashAICB
	this.shape_2 = new cjs.Shape();
	this.shape_2.graphics.f("#1D1D1C").s().p("AFZJaQgIgOAEgXQAIg1gVgwQgRglgqgwQiJibg3hNQhhiJgniCQgTg/gOhhQgPhugJg5QhICugRA8QgmCGAQBzQACARADA0QACA6g2AIQguAHgCAtIgKDYQgBAhgDAKQgHAUgZgBQgLAAgOgTQgNgRgFgRQgPg6AHhJQAFgqAShXQAJgoAUgWQAXgZAogGIgEh0QgChFAJguQAbiQAlhdQAwh9BQhWQAvgzAiAeQALAKAFAXQAFAWgDASQgbCqAeCPQAfCbBjB/QAuA8DCDyQBLBegVByQgCAOgOAOQgOAPgMABIgEAAQgSAAgIgPg");
	this.shape_2.setTransform(39.3231,-37.3354,0.1144,0.1145);

	this.shape_3 = new cjs.Shape();
	this.shape_3.graphics.f("#FFFFFF").s().p("AldGkQgtiaA3hCQAKgLBAgwQAygmAQgrQAKgcgHgiQgMg4gBgpQgBhBAQhCQALguAihdQAahIAdg5QAghBANAEQAFACACARQACAMABAnQACA2gCAaIAAAwQABBAAJBYQAGA9ArA+QAbAmBJBJQBOBQAlAvQA+BRAhBXQAqBwgCCAg");
	this.shape_3.setTransform(38.95,-36.8,0.1145,0.1146,0,0,0,-0.4,0.1);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[]}).to({state:[{t:this.shape_3},{t:this.shape_2}]},11).wait(11));

	// wing1
	this.shape_4 = new cjs.Shape();
	this.shape_4.graphics.f("#1D1D1C").s().p("AEdXOQgJgPACgaIAAgFIAHgtQAEgbgIgJQgaghhFgcQhdgngygcQhKgqgxg1Qgzg4hDhQIhyiKQgHgJgGgPIgIgaQgSg7AOgdQAPgeA9gYIg+g6QglghgagTQizh/g/ilQgXg5gBhAQAAguAegTQAfgSAqAWQANAGARAPIAdAYIB+BnIAJgJIhVieQhSiSglhUQg6iDgSh1QgRhtAMieQAFg8AkgQQAjgRA3AdQAOAIAiAOIgHgyQgEgbgFgRQgrh2AYiEQAShjBBiJQASgmAigtIA/hNQAJgKASgJIAigNQAsgQAVAMQAVAMAIAvIAdCvQARBpAQBFQAxDQA4CYQBHC8BjCVQCSDbDwF8QCCDNhlD+QgTAvgKArQgGAXAEAOQAFATAXAKQAHAEAFAQIAJAdIgcANQgSAHgJgCQglgJgUgXQgWgZAFgjQALheAahBQBWjYhsisQgshHhRh6QhbiIgjg3QgSgdg1haQgshMgegrQiPjJhPkyQgahlggiXIg2j+IgKgiIgrAnQgYAWgJARQg+BvgbBPQgkBrAIBjQAEAvAUBIIAfB2QAEAOAAAXIAAAlIgkADQgVACgNgDQgagGglgLIhBgVQgRA8ACBFQACA5AQBIQAXBkAtBqQAlBZA7BqIBNCKQAvBOA1AuQAXAUgRAlQgRAkgiAEQgjAFgXgOQg0ghizh5IgZgTIAGAgQADAPADAIQA1CMCSB1QBfBMB3BvQALAKAHATQAIAUgFAJQgLAWgwAMQgNAEgVgBIgjgCIgOAPIAnA+QAYAlATAWQBIBSAYAaQA3A8AvApQAfAbA3AeIBbAzQCOBUAtAdQA2AjgtArQgGAFgCASQgEAUgEAGQgPAXgIAJQgPARgMABIgEAAQgTAAgJgQg");
	this.shape_4.setTransform(37.0883,-35.4199,0.0994,0.0993);

	this.shape_5 = new cjs.Shape();
	this.shape_5.graphics.f("#FFFFFF").s().p("AEGVLQhehrjaidQhihGgqgkQhDg6geg0QgohEAUggQAMgWAmgIQAcgHAoAIQAgAIAEgHQAEgGgIgQQiRhQhzhkQiPh6gahTQgehcAdhnQFVDsAVgbQAIgJgegoQhth4hMiLQhyjOgejjQgViZAUiaICqA8QgnhvgJh3QgOjHBOirQA1h1BbhdQBuAogUCWQgQB0A5DIQAkB6BwEuQAbBKAlBGQAWAqAvBRQBPCJBeBzQAoAyBlBwQBFBNAYArQAiA8gEBEQgDArgSA1QgKAegWA7QgmBsAfBXQAQAwAiAqIkEIwQgfgsgngug");
	this.shape_5.setTransform(37.1553,-35.662,0.0994,0.0994);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_5},{t:this.shape_4}]}).to({state:[]},11).wait(11));

	// ANGELMAN
	this.shape_6 = new cjs.Shape();
	this.shape_6.graphics.f("#1D1D1C").s().p("AgiAUQgMgSABgLQACgXAQgMQASgMAZALIAJABIAJgBQACALAIAVQAFASgEAJQgGALgTAKQgWAKgKAGIgWgfg");
	this.shape_6.setTransform(56.3453,-45.7545,0.1099,0.1099);

	this.shape_7 = new cjs.Shape();
	this.shape_7.graphics.f("#1D1D1C").s().p("AgEArQgMgCgOgOQgQgSgIgIQAHgHAOgUQAMgQAKAAQAKgBARANIAnAdIgjAfQgQANgHAAIgBAAg");
	this.shape_7.setTransform(62.3878,-45.5401,0.1099,0.1099);

	this.shape_8 = new cjs.Shape();
	this.shape_8.graphics.f("#1D1D1C").s().p("AgVA8QglgKgYgKQgggOgIgfQgIggAXgZQAIgIAPgEQAPgEANACQAUADAdAIIAwANIAKACQBNAHgDA9QgBAigbANQgPAHgrAFIg8gRg");
	this.shape_8.setTransform(59.1028,-36.0229,0.1099,0.1099);

	this.shape_9 = new cjs.Shape();
	this.shape_9.graphics.f("#1D1D1C").s().p("AgxBaQgrgNgjgfQgSgRgqgaQgugbATgsQALgYAUgIQAUgHAYAKQAeANAXAXQAqAtAyALQAwAJA7gSQASgGATgBQAUgBAQAFQALAEAMAOQAKAOACANQABALgKAPQgKAPgKAEQggAJgsAKIg6ALIgIAAQg6AAgpgNg");
	this.shape_9.setTransform(59.0042,-38.079,0.1099,0.1099);

	this.shape_10 = new cjs.Shape();
	this.shape_10.graphics.f("#1D1D1C").s().p("AhMDEQgWgMACgVQAAgFALgkIAliAIAliBQALgkAUgTQAIgHAPgDQAPgCALAEQAIADAIANIANAWIg1CgQgeBdgWA/QgKAZgOAMQgLAIgNAAQgKAAgLgFg");
	this.shape_10.setTransform(80.8984,2.3289,0.1099,0.1099);

	this.shape_11 = new cjs.Shape();
	this.shape_11.graphics.f("#1D1D1C").s().p("AhFBAQgpgMgbgLQgagLgKgVQgMgWAOgaQANgYAWABQALABAgAMQBBAYAjgBQA3AAAoguQAHgIAQgCQAQgDAKAEQALAFAJAOQAKAPgCAHQgNAigHAMQgOAagQAKQgXAOgmAKIhDASIhGgUg");
	this.shape_11.setTransform(83.5979,20.2544,0.1099,0.1099);

	this.shape_12 = new cjs.Shape();
	this.shape_12.graphics.f("#1D1D1C").s().p("AgtBLQhZgpg2hGQgKgNgEgVQgEgWAFgPQAHgVAXADQAYADASAXQAuA7BLAgQA0AWBcARQAPAEAfAEQAXAIgBAcQgBAdgYALQgPAHgpAFQhtgZg7gbg");
	this.shape_12.setTransform(79.9333,17.6259,0.1099,0.1099);

	this.shape_13 = new cjs.Shape();
	this.shape_13.graphics.f("#1D1D1C").s().p("AhyCzQgcgGgNgLQgTgOAEgaQAEgbAXgHQAOgEAmAEQA3APAkhIQAlhGAghdQAKgeAJgLQANgRAZAEQAbAEAMAVQAKATgFAcQgeCjhyBsQgbAagnAEIgNABQgbAAgigJg");
	this.shape_13.setTransform(88.4122,17.0469,0.1099,0.1099);

	this.shape_14 = new cjs.Shape();
	this.shape_14.graphics.f("#1D1D1C").s().p("ABADwQgOgEgFgHQghgsgPgWQgagngMggQgSgvgShGIgdh5QgHgZAFgJQAIgNAOgSIAZgeIAeAXQARAOAGAMQAIAOAEAcQAHAjADAJIBODrQAEALAPBDIgKAUQgHAMgHACIgIABQgHAAgIgCg");
	this.shape_14.setTransform(85.2054,-0.5253,0.1099,0.1099);

	this.shape_15 = new cjs.Shape();
	this.shape_15.graphics.f("#1D1D1C").s().p("AABGHQg+gXgxAAQg4AAgzAeQgVANgLgBIgjAAQgUgCgJgIQgGgGABgTQABgSAFgPQAKgYAfgrQA9hQgFhRQAAgJgKgKQgLgLgJgCQgfgDgOgEQgXgGgCgbQgBgdAWgNQAQgIAhgCQAEAAAJgFIgIhlQgFg6ACgmQADhFAsgyQAsgwBLgWQBJgWBHASQBIATAkAzQAXAfAEA0QABAJgMAOQgMAOgLACQgKACgPgJQgOgKgFgKQgeg8grgTQgrgThCATQhBASgZAnQgaAnALBDQAEAUAFArQAGAkAPAOQAMALAkgEIA+gHIAngEQAjAAAKADQAWAHADAbQACAagUAMQgOAIgeAEIhhAMQgcAEgMAPQgMAPgDAeQgCAfgJAtIgPBFIB0AcQBFARAvAJQBfAUA8g2QARgQAHAAQANABATAEIAfAGIgFAfQgDASgHAIQg+BBhSANQgUADgVAAQg4AAg/gXg");
	this.shape_15.setTransform(83.9375,9.8421,0.1099,0.1099);

	this.shape_16 = new cjs.Shape();
	this.shape_16.graphics.f("#FFFFFF").s().p("AggCCQgsgMgWgpQgOgYgMg5QgJgoALghQAMgiAfgVQANgJAXAAQAUgBATAFQAQAFAXAOIAlAXIAAgBQAdAJAMAaQAHAPAFAlQAOBmgkAgQgUASgmAAQggAAgtgNgAAKhdQgPALgCAYQgBALAMATIAVAeQAKgFAXgLQATgKAGgLQAFgIgGgUQgHgVgDgKIgJABIgJgBQgMgGgLAAQgLAAgKAHg");
	this.shape_16.setTransform(55.9207,-45.2079,0.1099,0.1099);

	this.shape_17 = new cjs.Shape();
	this.shape_17.graphics.f("#FFFFFF").s().p("AgYCFQgtgHgXgmQgig2gQhUQgHgpAPgRQAPgRAsgFIAxgEQBhACArAuQArAugPBRQgHAmgUAVQgUAUgkAHQglAIgZAAQgMAAgJgCgAAdhxQgJABgNAQQgNAUgHAIQAJAHAPASQAOAPALACQAJABAQgPIAkgfIgngdQgRgNgLAAIgBAAg");
	this.shape_17.setTransform(61.9343,-44.7649,0.1099,0.1099);

	this.shape_18 = new cjs.Shape();
	this.shape_18.graphics.f("#FFFFFF").s().p("AABEBQgFhPg3gkQgsgehRgFIgHgrQgEgYgIgMQgQgVhZAWQhYAWgDAaQgCAOAKAWIASAlIASgDIgpBNIgug8QgbgjgOgZQgNgXgLghIgRg7QgCgHAEgJQADgJAFgHQAdgoAWgRQAggaAogBQANAAATgKIBVgpQAygZAfgWQAigYAsgBIBQAGQA4AEBMgEICFgLQASgBAIACQALADALANQAQASAiAbQAnAfANANQAgAeA0A/QAIAKAGAbIAwDrIgFAFIgVglQgNgXgEgQQgIgcgsgsQgtgsgagDQgagDgPASQgPATAHAbQADALAHAPIAOAeQhbAAglAPQg9AYgLBLg");
	this.shape_18.setTransform(58.0412,-48.6156,0.1099,0.1099);

	this.shape_19 = new cjs.Shape();
	this.shape_19.graphics.f("#FFFFFF").s().p("ACJL4QiggohdgrQiDg9hShlQgyg+giglQg+hEgQhpQgEgUgIipQgKimgYhuQghiThIhvQgXgjAFg1QAMg9AAgeQAAgEAGgHQAGgGADAAIA6ANQAgAHAYAKQAMAFAEArIAFBhQADA8AEAlQABALAMAQIAVAaQAIgGASgLQAPgKAFgKQAVgvABgrQABh2gIhvQgCglAagIQAPgEAlgGIAMA0IANAvQAqCFB0ANQBRAIA+gEQArgEASgdQARgdAEhGQACgoAXgPQAXgQAmAOQAMAFATALIA5FxIgxgEQgagCgQACQgNACgRALIgdATQAGAJAMAXQALATAKACQBKASBEgEQAbgBALgWQAKgSgDgeIgUijIgGg2QBnAtBQgQQBWgRBFhaIAIBkQAFA2gBAkIAACnQgBBggKBGQgaCuhnBqQgtAwgYAXQgpAmgoARQgIAEgIALIgNATIgMAUQgHAMgHADQhFAggUBJQgLAqgFBdIgDAiQgCAVgDAOQgFAagSALQgLAHgPAAQgIAAgKgDgABdAhQgQAEgHAIQgXAZAHAgQAIAgAhAOQAYAKAkAKIA+ARQArgFAPgHQAagNACgiQACg+hNgHIgKgCIgxgNQgcgIgVgDIgJAAQgJAAgJACgAgOizQgVAIgKAYQgUAsAuAcQApAaATARQAiAfArAMQAsAOBBgBIA5gLQAsgKAggIQAKgEAKgPQAKgPgBgLQgBgNgLgOQgLgPgMgEQgPgFgVABQgSABgSAGQg8ATgwgKQgzgLgpgtQgXgXgegNQgPgGgMAAQgIAAgIADg");
	this.shape_19.setTransform(57.1534,-37.2095,0.1099,0.1099);

	this.shape_20 = new cjs.Shape();
	this.shape_20.graphics.f("#FFFFFF").s().p("AgaAoIA1hZIgKA2QgHAfgSAPg");
	this.shape_20.setTransform(85.1335,-13.4879,0.1099,0.1099);

	this.shape_21 = new cjs.Shape();
	this.shape_21.graphics.f("#FFFFFF").s().p("AhuAPIDZgpIAEAUQgpAahBAEQhLAAglADg");
	this.shape_21.setTransform(83.1304,-6.5499,0.1099,0.1099);

	this.shape_22 = new cjs.Shape();
	this.shape_22.graphics.f("#FFFFFF").s().p("Ag5iiQAegTAQAOQALAIARAcQAsA2gDBTIgGBHQgEAsACAbQAAADgFAGIgOARg");
	this.shape_22.setTransform(81.7686,-14.5848,0.1099,0.1099);

	this.shape_23 = new cjs.Shape();
	this.shape_23.graphics.f("#FFFFFF").s().p("AhGCTQgIgIAAgGIgJhoQgEg7ADgsQACgVASgZQATgZATgFQAbgIAYANQAbAOAKAhQADAIAKAMIAUAXIglAfQgVASgJAOQgOAXgPAnIgcA/QgDAHgHAGQgIAGgHACIgBAAQgEAAgHgHg");
	this.shape_23.setTransform(84.3167,-14.6887,0.1099,0.1099);

	this.shape_24 = new cjs.Shape();
	this.shape_24.graphics.f("#FFFFFF").s().p("AkLEDIgBgSQAAgKgEgGQgggpgKhLQgOhqgFgOQgBgGAGgLQAGgKAIgIQAIgJAOgKIAYgSQA0gnAbgpQAggxAFg7QABgJAOgPIAcgdIAMAnQAFASAFALIAnBVQAWAyAVAiQANAYAfAAQAKAAAtgIQB5gWBPgHQAIAAANAQQAOAQAAAMQAIB+gEBlQgCAsgkAXQgUAMgzAMQg2ANhJALIh/AQQgtAGhDAGIh4ALg");
	this.shape_24.setTransform(81.639,-10.8171,0.1099,0.1099);

	this.shape_25 = new cjs.Shape();
	this.shape_25.graphics.f("#FFFFFF").s().p("AkqY/QgdgCgNgTQgMgQgDgjQgEgngRhLQgRhOgFglQgLhggKjEQgBgdAAg9QAAg7gCgfQgBgWgIgiIgYhxIgZhvIgLgpQgGgZADgQQAukUBZjrQBAilBRjsICKmTIBBi8QAmhuAYhPQARg4AXheQAchzAKgjQACgLAKgMQAJgNAJgBQBUgKDegXIAfAAIghBtQgTA/gLAqIguC9QgcBzgVBIQgqCPgaBRQgnB8glBhQglBfhhDjQhWDNgsB1QhACugVDFQgFAyAPBCQAKApAZBLQA8CsAnBpQA3CYA0B5QAYA3gHBEQgEAogPBOQgBADgOAEQgNAFgGgDQg/gjgZALQgaAMgQBHIgMAYIgWggQgNgSgLgHQgagSgMgHQgXgMgOAEQgQAEgRAWQgGAHgUAfQgGAKAAAcQgEAUgWAAIgEAAg");
	this.shape_25.setTransform(41.9035,49.719,0.1099,0.1099);

	this.shape_26 = new cjs.Shape();
	this.shape_26.graphics.f("#FFFFFF").s().p("AAAZ0QgSgWgJgRQgcgygigDQghgDgjAuIgqA2IgVgqQgdg6g/AcIgeARQgoAYgdgMQghgOACg2QAHk9iVk1QgRgjgOgwQgHgZgOg+QgIglANgjQALgeAeggQCSidAojIQAHgkATgxIAhhTQCGlkBBi0QA/iwBbkOIBAi9QAlhuAUhRQAThHARhqQATh4AKg7IANg9IGxBfIg7EYQgkCogdBxQgQA8gjBVIg9COIk/L/Ig2CEQgfBMgeAzQgkA/ggBzQgnCIgSAtIgsBeQg8CCA9CDQASApA5B0QAwBiAaA8QAtBqA3CuQAFASgBAbIgDAuIgXAIIgdglg");
	this.shape_26.setTransform(29.5848,49.9736,0.1099,0.1099);

	this.shape_27 = new cjs.Shape();
	this.shape_27.graphics.f("#FFFFFF").s().p("AiUSnQj2g0iPi8IhAhSQglgxgXglQhFhwgfiNQgah5gCiqQAWm4DbkpQAjgwBBhMQBLhaAaghQARgWAYgmIAng9QAfgvAThAQANguAKhJQAEgiAPgOQAQgPAlgBQAoAAA+gMIBlgTQAKgBAOAFQANAFAEAHIBoDfQBBCKApBTQAWArArBIQAyBSASAgIDPGHIAFAJQADAGgBADQgLA7AeBLIAyB+QApCMABCgQAACEgbCqQgUB2hRBTQg8A+h7BAQiKBIixAEQg5ABhSAHIiKAMIgOAAQgNAAgIgBgAixPrQgPAaAMAXQALAVAaALQAaALApAMIBIAUIBCgSQAmgKAWgOQARgKANgaQAIgNAMgiQADgHgKgPQgKgOgKgFQgKgEgQADQgRACgGAIQgoAug3AAQgjABhBgYQgggMgLgBIgCAAQgVAAgMAXgAEfNHQgWAHgFAbQgDAaASAOQANALAcAGQAsALAfgDQAngEAcgaQByhsAdikQAFgcgKgTQgLgVgbgEQgZgEgOARQgIALgLAeQggBdglBHQglBIg3gPIgegCQgOAAgIACgAodK3QgFAQAEAVQAEAVAKANQA2BHBZApQA8AbBtAZQApgFAPgGQAYgMABgcQABgdgXgIQgfgEgPgDQhcgSg1gWQhLghgug6QgSgYgYgDIgEAAQgUAAgGASgAAZHmQBXAgBJgMQBSgNA+hBQAHgHADgSIAFgfIgfgHQgTgEgNAAQgHgBgRARQg8A1hfgTQgvgKhFgQIh0gcIAPhGQAJgsACggQADgeAMgOQAMgQAcgDIBhgNQAegDAOgJQAUgMgCgaQgDgbgWgHQgKgDgjAAIgoADIg9AIQgkAEgMgMQgPgOgGgjQgFgqgEgUQgLhDAagnQAZgnBBgTQBCgTArATQArATAeA8QAFALAOAJQAPAJAKgBQALgCAMgOQAMgOgBgKQgEg0gXgeQgkg0hIgSQhIgThIAWQhLAWgsAxQgsAygDBEQgCAnAFA6IAIBjQgJAFgEABQghABgQAKQgWAMABAeQACAaAXAHQAOAEAfACQAJADALAKQAKALAAAJQAFBRg9BQQgfAqgKAZQgFAPgBARQgBAUAGAFQAJAIAUACIAjABQALAAAVgMQAzgeA4AAIADgBQAwAAA8AXgAjQsUQgQADgIAHQgVATgLAkIgkCBIglCBQgLAkgBAFQgBAVAWAMQAZAMATgPQAPgMAJgZQAXg/AehdIA1ihIgMgWQgIgNgJgDQgHgDgJAAIgJABgAA1wjQgOASgIANQgGAJAHAZIAeB5QARBHASAvQAMAgAbAnQAPAWAhAsQAFAHAPAEQAOAEAJgDQAHgCAGgMIALgUQgQhDgDgLIhOjsQgDgJgHgjQgFgcgIgOQgHgMgRgOIgegXIgYAeg");
	this.shape_27.setTransform(83.669,8.7961,0.1099,0.1099);

	this.shape_28 = new cjs.Shape();
	this.shape_28.graphics.f("#1D1D1C").s().p("AwfS5QgIgoAfgmQAXgbAcgtIAwhLQAshCApguQAyg3A4gkIBfhAQA4gkArgUQAqgUA6gQQAggKBHgQQAVgFAGgLQADgHAAgWQAHlzihknQgcg0AAg7QgBg4Aag7QADgJgCgOQgDgOgGgDQgdgPgKggQgFgPgDgqQgDgpABg9IABhrIAkABIAXAHIAWhAQAOglALgYQAxhhAiglQCAiGCrhDQASgHAigIQAmgIAQgGQAngOAJgGQAYgPAGgeQABgJAUgKQAPgHAUgFQAogJAnAFQAnAFBNAQQBEALAygKQAGgCAIAEQAJAEADAFQAQAcAkAHQAUAFApAGQAzAQAVAMQAkAWARApQAKAWAhAgQAlAkALARQATAeAUAsIAjBMIAQAxQAKAdAMAOQAdAgAIAuQAEATADBCQABAsAVAsQAUAqgPAlQgPAmgqAHIAOCjQAIBhAABCQABB4gCBFQgEBogMBUQgTB+hLBqQhDBfhyBTQhAAvgeAxQgkA9AIBJQADAYgCAfIgIA2QgLBHhGApQhFAphIgVIh/glQhIgXgygZQiAhChZhYQgtgtgyhDQgTgahBhfQgRgZgRgIQgTgIgYAIQhJAZgjANQg/AXgoAZQh1BJh+B0QgcAZgeAtQgRAZghA1QgUAegbAtIgtBMQgtgZgHgpgAlqlBQgGAHAAAEQAAAegLA9QgGA1AXAjQBIBvAiCSQAYBuAJCnQAJCpADAUQARBpA+BEQAhAlAyA+QBRBlCEA9QBcArCiAoQAaAHARgLQASgLAGgaQADgOABgVIADgiQAFhdAMgqQAThJBFggQAHgDAHgMIANgUIANgTQAIgLAHgEQApgRApgmQAYgXAtgwQBnhqAZivQAKhGAChgIAAimQAAgkgEg2IgIhkQhFBahXARQhPAQhngtIAFA2IAUCiQAEAegKASQgLAWgcABQhEAEhJgSQgKgCgLgTQgMgXgHgJIAdgTQASgLAMgCQAQgCAaACIAyAEIg5lwQgUgLgMgFQglgOgYAQQgXAPgCAoQgDBGgRAdQgSAdgsAEQg+AEhSgIQh0gNgpiFIgMgvIgNg0QgkAGgQAEQgaAIADAlQAIBvgCB2QAAArgWAvQgEAKgPAKQgSALgIAGIgVgaQgNgQgBgLQgEglgCg8IgFhhQgEgrgNgFQgXgKghgHIg5gNIgBAAQgDAAgGAGgAKAnUQgtAFgOAQQgQASAIApQAQBVAhA2QAYAmAsAHQAfAFA2gLQAjgHAUgVQAVgVAGglQAPhTgqgtQgsgvhhgBgAB9oIQgXAAgNAJQggAVgLAiQgLAhAIAoQANA6ANAYQAWApAtAMQBjAcAkghQAlgggOhnQgFglgIgPQgMgagdgJIABABIgmgXQgWgOgRgFQgQgEgRAAIgGAAgACdqUQAJAMAEAYIAHArQBRAFAsAeQA2AkAGBPICGAAQAMhLA8gYQAmgPBbAAIgOgeQgIgPgCgLQgIgbAPgTQAPgSAbADQAaADAtAsQArAsAIAcQAFAQAMAXIAVAlIAFgFIgvjsQgHgbgIgKQgzg/gggeQgOgNgmgfQgigbgRgSQgLgNgKgDQgIgCgTABIiFALQhLAEg6gEIhQgGQgrABgiAYQgfAWgyAZIhVApQgSAKgOAAQgoABggAaQgWARgcAoQgGAHgDAJQgDAJABAHIASA8QALAhANAXQAOAZAaAjIAvA8IAnhNIgQADIgSglQgLgWACgOQADgaBYgWQAtgLAaAAQAZAAAIAKg");
	this.shape_28.setTransform(54.0675,-41.0449,0.1099,0.1099);

	this.shape_29 = new cjs.Shape();
	this.shape_29.graphics.f("#1D1D1C").s().p("EgoHBG8QgOgKgVgSIghgdQhNA0grAAQgrAAglg1Ig/AFQglADgZgBQg1gEgigmQghglAAg3QABlTiPkkQg+iBADh/QADhTA5g2QA4g1AohIQAig/AbhUQARg3AfhSQAjhaARguICTmSQCVmgAghfIBPjoQAqiDAbhnQAThLAOhkIAUizQABgKgUgQQgTgPgTgGQgWgJgjgGIhBgLIAYhLQAOgsAGgeIA+k2QAnjHAXhwQAhibAyjhIBTl8IAri9QAahyAOhNQAGgggBgwIgDhTQgBiHAgisQAGgiA6kNQAgiWCdrDICFpRIA3jzQAgiNAdhlQAHgZAcgdQAkggAQgQQAFgFAPABIAcADIgCAYQgCAMgDAIQgzCPgsDFIhHFbQggCig2DwIhaGSIhgGsQg3D4glC1QgSBaAGCUQAFBhgaCBQgPBKgkCTQhKFkiZLIQggCXg9EvQgEAUAEAKQAEAMATAJQCVBIB+AmQCWAtCNAEIFGAMQC9AFCJgJQDsgQCDgWQDJgiCbhHQAZgMAJgOQAIgNgBgaIgNndQgIkSgBjJQgGr0AJoLQACijA2jhQAVhZAnh1IBFjKQAFgNAQgRQAWgWAEgGQAVgegEgNQhUkAhIinQhijhh1irQgxhIhThzIiGi7QgcgogDgIQgMgeAbgWQAbgXAbAPQAPAKAZAgQDBD9BuCvQCYDzBSDkQAVA6AvByQApBnARBHQASBRAnBoQAWA9AwB3QAuB7CBBwQALAJAVAEQAIACAeAEQBGAIBwAHQAYACAZgIIFDhuQC9hBCEgyQBOgdCEg+QCVhFA8gZQAxgUBEgTIB4geQAKgDAQAHIAdANIATAJQALAFACgCQAIgHAGgKQAGgLgBgIQgNhUgShSQhNlJhPlKIgGgQIgIgUIguAQQgaAKgPALQgsAfhPA8QhUBAgmAbQghAYgzAhIhWA2IhGAwQgpAcgeAQQgqAXhCAgIhtA1IhuA4IgwAYQgcANgWAHQghAGgQAFQgcAHgRATQgRARgVgHQgUgGgNgXQgMgVgVg4IiKl8QhTjig9iXQiJlWjNkaIh/iwQhKhlg+hCQgogshCgrQglgYhUgvQgWgLgmgCQgtABgWgBQgJAAgcAEQgYAEgMgEQgPgEgPgNQgPgOgDgNQgDgKAOgSQAOgSAMgCQBSgTBBADQBNADBCAiQCDBEBvBwQBgBgBbCLIBqChQA9BdAlBHQA2BnBJCXIB6EAIAYAvQAYheAIgpQArjCARhhQAdingFiAQgBglgLgfQgJgZACgOQADgTAVgLQAYgLAVAGQAVAGALAWQARAhADAwQAICFgYCjQgOBggrDDIgaCKQAsAIAiAkQAUAVAiAvIBTBqQAzBCAiAnQAWAYAmAcIBAAvIBkBJQAbgTA1gpQAwgkAjgRQA0gZBBguIBshQQA2gmBohSQBehEBUgVQAGgBAKgFIAVgKQjchIkPANQggABgTgLQgTgLgOgaIhujRQhCh7gyhUQhciai4kLQgXgvgNgXQgXgpgmgLQgEgBgHgVQg3iUh6iEQgKgLgDgYQgEgXAHgKQAQgUAXACQAWADAQAVQB/CeAxBGQCTDQBhCaICuERQBhCfA2CAIANAbQAUAtAcATQAfAUA2AAQDfgEDfBHQAdAJAugPQAigLAlAYQAlAYAFAnQADATACAsICHhzIgKgsQgGgegDgWQgEgjAPgXQAQgXAjgFQBXgNAXAAQA9ADApAsQBGgtBGAPQA8AMBDA4QAHAHAOAEIAXAIQBDAZgHBDQgDAdAMAPQARAWgBAWQgBAUgQAXIgfAtQgZAsgIAcQgLAoAJAuQAOBBAABVQAAA5gHBgQgCAXgXAfIgqAyQgHAKgTAKIgoAXIAyAwQAbAaAUARQAVARAEASQAFATgLAYQgGANgCAPQgCARAFALQCHErBICTQAUAoAoBAQAvBLAPAbQBLCGCBDyQAOAaALAsIAyDBQAcBxAPBRQA3EphiFFQgYBOhDBBQgxAwhaA2QhFAphVAmQhPAihwAMIjEANIhXAGQgzAEgkABQgxACgxgMQkGg/iZjSQhChWgggtQg4hOgag/QialnBemYQAgiMAXhHQAmhyA1hRQAshDBAhSIBziQQC6joAgkIIACgKQACgHgCgCQgphHBCg6IgMgOIhJASQgqALgeAKQgEACgCAQQgBAPACAMQAKA+AXB8QAIAqgFAbQgEAYgQALQgRAMgVgKQhMglhXAGQhGAFhYAiQhFAaiGA/QiGA+hFAaQiAAxjHBFIlJBzQhLAbghAGQg9AKg1gTQgSgHghACQgtACgIAAQhJgFgwgXQg5gcgig7QgPgbgngxQgngwgQgcQgTgjgUg1IgihcIgqhuIgQgCQgOAughBaQgbBRgMA5QgjCmgPBRQgYCKgJBvQgIBhAECYIAFD5IgFHWQgEEgABC0QABCXAIDYIAOFuQABAjAKAIQAKAIAbgKQApgQAeAKQAIADAFAVQAGAVgFAKQgJATgPAQQgRARgQAHQgaAKguAKQg2ALgSAGIiVAzQhZAfg9AKQg6AJgaAfQgXAagMA6QgrDEgXBfQgmCigmB/QgoCIg4CgQgoB0hCCxQghBWhGCnQhHCqggBUQg7CegJBwQgEAuAOA8QAJApAWBBQBdEHB5EyQAWA3ADAvQAEA1gRAzQgGAVgHArQgMBAgeAZQgeAZg/gBIgdAAQgoBRgkAHQglAHhbg2QgmA3glALQgmALhLgXQg4gRgXggQgVgegEhAQgFhBgYhRQgahdgIh+IgGjdIAAgyQADhMgUhjIgoirQgIgjABg0IAEhYQAAgfALhIIAGgsQAEgZAGgSICGltQBSjeAxiQQBZkBCsoaQAPgvARhGIAch6ImdAAQgOA+gYB6QgXBtgUBIQgyC3gXBOQgrCRgqBwQg8CchhDqIiiGFQgzB8hiD6IhACkQgmBfgdBEQgmBXAnBWQAUAtA/CAQA0BtAcBCQA7CJAlCRQAOAxgWBTQgPA4g6ASQgTAGgSAAQglAAgggYgEgpCBDpQAiADAcAyQAJARASAWIAeAlIAXgHIADgvQABgbgFgRQg4ivgthqQgag7gwhjQg5h0gSgpQg9iDA8iBIAshfQASgsAniJQAghzAkg/QAegzAghMIA2iDIE/sBIA9iOQAjhUAQg9QAdhxAkioIA7kYImxhfIgNA9QgKA7gTB4QgRBqgTBIQgUBQglBuIhAC9QhcEOg/CwQhBC0iGFlIghBUQgTAxgHAjQgoDIiSCdQgeAhgLAeQgNAiAIAlQAOA/AHAYQAOAxARAjQCVE0gHE9QgCA3AhANQAdAMAogYIAegRQA/gcAdA7IAVApIAqg2QAhgrAgAAIADAAgAzpScQgIABgKANQgJAMgDALQgJAjgcBzQgXBegRA4QgZBPgmBuIhBC8IiKGTQhSDsg/ClQhZDsguEUQgDAQAGAZIALApIAYBvIAZBxQAIAiABAWQACAfAAA7QgBA9ACAdQAKDEALBgQAFAlARBOQAQBLAFAnQADAjAMAQQANATAdACQAaACAEgWQAAgcAGgKQAUgfAGgHQARgWAQgEQAOgEAXAMQAMAHAaASQALAHAMASIAXAgIAMgYQAQhHAagMQAZgLBAAjQAGADANgFQAOgEAAgDQAQhOAEgoQAHhEgYg3Qg0h5g4iYQgnhpg8isQgZhLgKgpQgPhCAFgyQAVjFBAiuQArh2BYjNQBhjjAlhfQAlhhAnh8QAahRAqiPQAVhIAchzIAui9QALgqATg/IAhhtIgfAAQjfAXhUAKgEAmhgh4IhmASQg+AMgoABQglAAgQAQQgPANgEAiQgKBJgNAvQgTA/gfAwIgnA9QgYAlgRAWQgaAhhLBaQhBBNgjAwQjbEogWG5QACCrAaB4QAeCOBGBwQAXAkAlAxIBABTQCPC7D2A0QALACAYgBICLgMQBSgHA5gBQCxgECKhIQB7hBA8g8QBRhTAUh2QAbiqAAiEQgBiggpiNIgyh+QgehLALg7QABgEgDgFIgFgKIjPmHQgSgggyhSQgrhHgWgrQgphThBiLIhojeQgEgIgNgFQgLgDgIAAIgFAAgEAivgk1IAEAMQAlgDBLAAQBCgEApgbIgEgVgEAgNgvxQgOAPgBAJQgFA7ggAxQgbApg0AnIgYASQgOAKgIAJQgIAIgGAKQgGALABAGQAFAQAOBqQAKBKAgAqQAEAFAAAKIABASIAFBCIB4gLQBDgGAtgGICAgQQBJgLA2gNQAzgMAUgMQAkgWACgsQAEhmgIh/QAAgMgOgQQgNgQgIABQhPAGh5AWQgtAJgKAAQgfgBgOgYQgVghgWgyIgnhWQgFgLgFgSIgMgngEAF1gu4QgOALgKAFQgUAJgCAOQgBAKAIAUICjGwQAEAMAHALQAIANAEgBIBPgIQAugFAegNQAbgMAkgeQAogjAVgRImTmzIgXATgEAhpgzCIBZFQIAOgRQAFgGAAgDQgCgbAEgrIAGhHQADhVgsg1QgSgdgLgIQgHgFgJAAQgNAAgRALgEAm6guUIASALQATgPAHgfIAKg3gEAlsgzAQgTAFgTAZQgTAZgBAVQgEAsAEA8IAJBoQABAGAHAIQAIAIAEgBQAIgCAHgGQAHgGAEgHIAbg/QARgnANgXQAKgPAVgSIAkgfIgTgXQgLgMgCgIQgKghgcgOQgPgIgQAAQgKAAgKADg");
	this.shape_29.setTransform(57.4684,19.5346,0.1099,0.1099);

	this.shape_30 = new cjs.Shape();
	this.shape_30.graphics.f("#FFFFFF").s().p("AroiVIB4AoIKJkOIH+lUID6OrQiEgLiAAVQicAZiYBMQikBfhNAsQknCkltBCIhkAUg");
	this.shape_30.setTransform(70.1,-5.6,0.11,0.11,0,0,0,-0.2,-0.3);

	this.shape_31 = new cjs.Shape();
	this.shape_31.graphics.f("#FFFFFF").s().p("EgVYAurQj8gcjLgxQjWg0hmg+IGr+OIgvkoMAJOglfQAlioBHizQCClEC2ipQBFhABghFQAygjAjgWQCPhaCdg8IDmGHIHcC4IC3ivINIS6IJiCWInqFKIloCqQg/gjhNhCQibiFhLicIiWhuIiCBuICqKUIglMuImzjSIhioWIi0EOIiBLFMgAeAh6IAGAXQABAegXAdQhIBfkaA/QijAkj5ACIgXAAQjdAAjzgbg");
	this.shape_31.setTransform(53.4607,-0.9038,0.11,0.11);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_31},{t:this.shape_30},{t:this.shape_29},{t:this.shape_28},{t:this.shape_27},{t:this.shape_26},{t:this.shape_25},{t:this.shape_24},{t:this.shape_23},{t:this.shape_22},{t:this.shape_21},{t:this.shape_20},{t:this.shape_19},{t:this.shape_18},{t:this.shape_17},{t:this.shape_16},{t:this.shape_15},{t:this.shape_14},{t:this.shape_13},{t:this.shape_12},{t:this.shape_11},{t:this.shape_10},{t:this.shape_9},{t:this.shape_8},{t:this.shape_7},{t:this.shape_6}]}).wait(22));

	// wing2
	this.shape_32 = new cjs.Shape();
	this.shape_32.graphics.f("#1D1D1C").s().p("AEdXOQgJgPACgaIAAgFIAHgtQAEgbgIgJQgaghhFgcQhdgngygcQhKgqgxg1Qgzg4hDhQIhyiKQgHgJgGgPIgIgaQgSg7AOgdQAPgeA9gYIg+g6QglghgagTQizh/g/ilQgXg5gBhAQAAguAegTQAfgSAqAWQANAGARAPIAdAYIB+BnIAJgJIhVieQhSiSglhUQg6iDgSh1QgRhtAMieQAFg8AkgQQAjgRA3AdQAOAIAiAOIgHgyQgEgbgFgRQgrh2AYiEQAShjBBiJQASgmAigtIA/hNQAJgKASgJIAigNQAsgQAVAMQAVAMAIAvIAdCvQARBpAQBFQAxDQA4CYQBHC8BjCVQCSDbDwF8QCCDNhlD+QgTAvgKArQgGAXAEAOQAFATAXAKQAHAEAFAQIAJAdIgcANQgSAHgJgCQglgJgUgXQgWgZAFgjQALheAahBQBWjYhsisQgshHhRh6QhbiIgjg3QgSgdg1haQgshMgegrQiPjJhPkyQgahlggiXIg2j+IgKgiIgrAnQgYAWgJARQg+BvgbBPQgkBrAIBjQAEAvAUBIIAfB2QAEAOAAAXIAAAlIgkADQgVACgNgDQgagGglgLIhBgVQgRA8ACBFQACA5AQBIQAXBkAtBqQAlBZA7BqIBNCKQAvBOA1AuQAXAUgRAlQgRAkgiAEQgjAFgXgOQg0ghizh5IgZgTIAGAgQADAPADAIQA1CMCSB1QBfBMB3BvQALAKAHATQAIAUgFAJQgLAWgwAMQgNAEgVgBIgjgCIgOAPIAnA+QAYAlATAWQBIBSAYAaQA3A8AvApQAfAbA3AeIBbAzQCOBUAtAdQA2AjgtArQgGAFgCASQgEAUgEAGQgPAXgIAJQgPARgMABIgEAAQgTAAgJgQg");
	this.shape_32.setTransform(39.1151,-35.7959,0.0799,0.0799);

	this.shape_33 = new cjs.Shape();
	this.shape_33.graphics.f("#FFFFFF").s().p("AEGVLQhehrjaidQhihGgqgkQhDg6geg0QgohEAUggQAMgWAmgIQAcgHAoAIQAgAIAEgHQAEgGgIgQQiRhQhzhkQiPh6gahTQgehcAdhnQFVDsAVgbQAIgJgegoQhth4hMiLQhyjOgejjQgViZAUiaICqA8QgnhvgJh3QgOjHBOirQA1h1BbhdQBuAogUCWQgQB0A5DIQAkB6BwEuQAbBKAlBGQAWAqAvBRQBPCJBeBzQAoAyBlBwQBFBNAYArQAiA8gEBEQgDArgSA1QgKAegWA7QgmBsAfBXQAQAwAiAqIkEIwQgfgsgngug");
	this.shape_33.setTransform(39.1698,-35.9887,0.0799,0.0799);

	this.timeline.addTween(cjs.Tween.get({}).to({state:[{t:this.shape_33},{t:this.shape_32}]}).to({state:[]},11).wait(11));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(21.4,-55,72.19999999999999,124.7);


// stage content:
(lib._970x90 = function(mode,startPosition,loop) {
	this.initialize(mode,startPosition,loop,{});

	// timeline functions:
	this.frame_465 = function() {
		if(!this.alreadyExecuted){
		
		this.alreadyExecuted=true;
		
		this.loopNum=1;
		
		} else {
		
		this.loopNum++;
		
		if(this.loopNum==3){
		
		this.stop();
		
		}
		
		}
	}

	// actions tween:
	this.timeline.addTween(cjs.Tween.get(this).wait(465).call(this.frame_465).wait(15));

	// FlashAICB
	this.instance = new lib.logo_2();
	this.instance.setTransform(133.3,47.95,1,1,0,0,0,-0.4,0);

	this.timeline.addTween(cjs.Tween.get(this.instance).wait(480));

	// 1px border
	this.shape = new cjs.Shape();
	this.shape.graphics.f().s("#000000").ss(1,0,0,3).p("EhLxgHBMCXjAAAIAAODMiXjAAAg");
	this.shape.setTransform(485,44.9988);

	this.timeline.addTween(cjs.Tween.get(this.shape).wait(480));

	// CTA
	this.instance_1 = new lib.CTA();
	this.instance_1.setTransform(881.7,51.2,1.0999,1.0999,0,0,0,65.2,15.2);
	this.instance_1.alpha = 0;
	this.instance_1._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_1).wait(325).to({_off:false},0).to({alpha:1},25).wait(130));

	// endframe text
	this.instance_2 = new lib.text3();
	this.instance_2.setTransform(528.1,41.1);
	this.instance_2.alpha = 0;
	this.instance_2._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_2).wait(325).to({_off:false},0).to({alpha:1},25).wait(130));

	// lifesavings
	this.instance_3 = new lib.text2();
	this.instance_3.setTransform(485,44.2);
	this.instance_3.alpha = 0;
	this.instance_3._off = true;

	this.timeline.addTween(cjs.Tween.get(this.instance_3).wait(145).to({_off:false},0).to({alpha:1},25).wait(130).to({alpha:0},25).wait(155));

	// youcanttakeitwithyou
	this.instance_4 = new lib.youcanttakeitwithyou();
	this.instance_4.setTransform(526.5,47);

	this.timeline.addTween(cjs.Tween.get(this.instance_4).wait(120).to({alpha:0},25).wait(335));

	// angel
	this.instance_5 = new lib.angelman("synched",0);
	this.instance_5.setTransform(702.65,181.65,1,1,0,0,0,9.5,7.4);

	this.timeline.addTween(cjs.Tween.get(this.instance_5).to({x:782.65,y:69.65,startPosition:16},60,cjs.Ease.cubicOut).to({y:71.65,startPosition:10},60,cjs.Ease.cubicOut).to({y:79.65,startPosition:5},61).to({y:71.65,startPosition:20},59,cjs.Ease.cubicOut).to({y:79.65,startPosition:15},61,cjs.Ease.cubicOut).to({y:71.65,alpha:0,startPosition:9},24,cjs.Ease.cubicOut).wait(155));

	// BG
	this.shape_1 = new cjs.Shape();
	this.shape_1.graphics.f("#00AEA2").s().p("EhLxAHCIAAuDMCXjAAAIAAODg");
	this.shape_1.setTransform(485,45);

	this.timeline.addTween(cjs.Tween.get(this.shape_1).wait(480));

	this._renderFirstFrame();

}).prototype = p = new cjs.MovieClip();
p.nominalBounds = new cjs.Rectangle(484,44,487,200);
// library properties:
lib.properties = {
	id: 'EAB6D9DC621C40E5A0F8A641AFD3DA1C',
	width: 970,
	height: 90,
	fps: 60,
	color: "#00AEA2",
	opacity: 1.00,
	manifest: [],
	preloads: []
};



// bootstrap callback support:

(lib.Stage = function(canvas) {
	createjs.Stage.call(this, canvas);
}).prototype = p = new createjs.StageGL();

p.setAutoPlay = function(autoPlay) {
	this.tickEnabled = autoPlay;
}
p.play = function() { this.tickEnabled = true; this.getChildAt(0).gotoAndPlay(this.getTimelinePosition()) }
p.stop = function(ms) { if(ms) this.seek(ms); this.tickEnabled = false; }
p.seek = function(ms) { this.tickEnabled = true; this.getChildAt(0).gotoAndStop(lib.properties.fps * ms / 1000); }
p.getDuration = function() { return this.getChildAt(0).totalFrames / lib.properties.fps * 1000; }

p.getTimelinePosition = function() { return this.getChildAt(0).currentFrame / lib.properties.fps * 1000; }

an.bootcompsLoaded = an.bootcompsLoaded || [];
if(!an.bootstrapListeners) {
	an.bootstrapListeners=[];
}

an.bootstrapCallback=function(fnCallback) {
	an.bootstrapListeners.push(fnCallback);
	if(an.bootcompsLoaded.length > 0) {
		for(var i=0; i<an.bootcompsLoaded.length; ++i) {
			fnCallback(an.bootcompsLoaded[i]);
		}
	}
};

an.compositions = an.compositions || {};
an.compositions['EAB6D9DC621C40E5A0F8A641AFD3DA1C'] = {
	getStage: function() { return exportRoot.stage; },
	getLibrary: function() { return lib; },
	getSpriteSheet: function() { return ss; },
	getImages: function() { return img; }
};

an.compositionLoaded = function(id) {
	an.bootcompsLoaded.push(id);
	for(var j=0; j<an.bootstrapListeners.length; j++) {
		an.bootstrapListeners[j](id);
	}
}

an.getComposition = function(id) {
	return an.compositions[id];
}


an.makeResponsive = function(isResp, respDim, isScale, scaleType, domContainers) {		
	var lastW, lastH, lastS=1;		
	window.addEventListener('resize', resizeCanvas);		
	resizeCanvas();		
	function resizeCanvas() {			
		var w = lib.properties.width, h = lib.properties.height;			
		var iw = window.innerWidth, ih=window.innerHeight;			
		var pRatio = window.devicePixelRatio || 1, xRatio=iw/w, yRatio=ih/h, sRatio=1;			
		if(isResp) {                
			if((respDim=='width'&&lastW==iw) || (respDim=='height'&&lastH==ih)) {                    
				sRatio = lastS;                
			}				
			else if(!isScale) {					
				if(iw<w || ih<h)						
					sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==1) {					
				sRatio = Math.min(xRatio, yRatio);				
			}				
			else if(scaleType==2) {					
				sRatio = Math.max(xRatio, yRatio);				
			}			
		}			
		domContainers[0].width = w * pRatio * sRatio;			
		domContainers[0].height = h * pRatio * sRatio;			
		domContainers.forEach(function(container) {				
			container.style.width = w * sRatio + 'px';				
			container.style.height = h * sRatio + 'px';			
		});			
		stage.scaleX = pRatio*sRatio;			
		stage.scaleY = pRatio*sRatio;			
		lastW = iw; lastH = ih; lastS = sRatio;            
		stage.tickOnUpdate = false;            
		stage.update();            
		stage.tickOnUpdate = true;		
	}
}


})(createjs = createjs||{}, AdobeAn = AdobeAn||{});
var createjs, AdobeAn;